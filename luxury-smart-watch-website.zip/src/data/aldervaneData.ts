export interface MaterialOption {
  id: string;
  name: string;
  subtitle: string;
  colorHex: string;
  secondaryHex?: string;
  metalness?: number;
  roughness?: number;
  clearcoat?: number;
  priceDelta: number;
}

export interface WatchConfig {
  caseId: 'steel' | 'rosegold' | 'titanium';
  bezelId: 'forest' | 'midnight' | 'ivory';
  dialId: 'ivory' | 'forest' | 'slate';
  strapId: 'cognac' | 'alligator' | 'suede';
  complicationId: 'pulse' | 'courier' | 'night' | 'navigator' | 'reserve';
  engravingText: string;
  engravingStyle: 'roman' | 'script';
  editionNumber: number;
}

export const CASE_OPTIONS: Record<WatchConfig['caseId'], MaterialOption> = {
  steel: {
    id: 'steel',
    name: '904L Laurentian Steel',
    subtitle: 'Hand-satin flanks with mirror-beveled lug chamfers',
    colorHex: '#D8D8D4',
    secondaryHex: '#C9A96A',
    metalness: 0.94,
    roughness: 0.24,
    priceDelta: 0,
  },
  rosegold: {
    id: 'rosegold',
    name: '18k Valais Rose Gold',
    subtitle: 'Warm sovereign alloy smelted in our Geneva foundry',
    colorHex: '#D8A586',
    secondaryHex: '#E5C185',
    metalness: 0.96,
    roughness: 0.2,
    priceDelta: 6800,
  },
  titanium: {
    id: 'titanium',
    name: 'Blackened Grade-5 Titanium',
    subtitle: 'DLC-hardened anthracite finish with champagne indices',
    colorHex: '#3A3E42',
    secondaryHex: '#C9A96A',
    metalness: 0.88,
    roughness: 0.3,
    priceDelta: 2400,
  },
};

export const BEZEL_OPTIONS: Record<WatchConfig['bezelId'], MaterialOption> = {
  forest: {
    id: 'forest',
    name: 'Racing Green Ceramic',
    subtitle: 'Sintered ZrO2 diamond-polished for 48 hours',
    colorHex: '#1F3A32',
    roughness: 0.08,
    clearcoat: 1.0,
    priceDelta: 0,
  },
  midnight: {
    id: 'midnight',
    name: 'Midnight Obsidian Ceramic',
    subtitle: 'Deep abyssal ceramic with gold-filled cardinal engravings',
    colorHex: '#14202B',
    roughness: 0.07,
    clearcoat: 1.0,
    priceDelta: 450,
  },
  ivory: {
    id: 'ivory',
    name: 'Warm Ivory Vitreous Enamel',
    subtitle: 'Kiln-fired at 820°C over a fluted gold substrate',
    colorHex: '#EAE2D1',
    roughness: 0.12,
    clearcoat: 0.95,
    priceDelta: 1200,
  },
};

export const DIAL_OPTIONS: Record<WatchConfig['dialId'], MaterialOption> = {
  ivory: {
    id: 'ivory',
    name: 'Grand Feu Coquille d’Œuf',
    subtitle: 'Hand-guilloché Clous de Paris under translucent enamel',
    colorHex: '#F4EFE6',
    secondaryHex: '#1A1A18',
    priceDelta: 0,
  },
  forest: {
    id: 'forest',
    name: 'Geneva Pine Guilloché',
    subtitle: 'Sunray engine-turned brass lacquered in deep spruce',
    colorHex: '#1B332B',
    secondaryHex: '#F4EFE6',
    priceDelta: 600,
  },
  slate: {
    id: 'slate',
    name: 'Ardoise du Léman',
    subtitle: 'Velvet storm-slate dial with champagne railway track',
    colorHex: '#252E38',
    secondaryHex: '#F4EFE6',
    priceDelta: 600,
  },
};

export const STRAP_OPTIONS: Record<WatchConfig['strapId'], MaterialOption> = {
  cognac: {
    id: 'cognac',
    name: 'Barenia Cognac Calfskin',
    subtitle: 'Full-grain saddle leather with ecru linen hand-stitching',
    colorHex: '#6E3F26',
    secondaryHex: '#DECBB1',
    roughness: 0.58,
    priceDelta: 0,
  },
  alligator: {
    id: 'alligator',
    name: 'Noir Matte Alligator',
    subtitle: 'Square-scale hornback lined in supple chamois calf',
    colorHex: '#1B1B1D',
    secondaryHex: '#8C7A5B',
    roughness: 0.42,
    priceDelta: 950,
  },
  suede: {
    id: 'suede',
    name: 'Alpine Moss Nubuck',
    subtitle: 'Water-repellent brushed suede with champagne stitching',
    colorHex: '#283F36',
    secondaryHex: '#C9A96A',
    roughness: 0.78,
    priceDelta: 350,
  },
};

export interface ComplicationItem {
  id: WatchConfig['complicationId'];
  roman: string;
  name: string;
  modernEquivalent: string;
  tagline: string;
  description: string;
  atelierNote: string;
  dialLabel: string;
  dialReading: string;
  dialSubtext: string;
  priceDelta: number;
}

export const COMPLICATIONS: ComplicationItem[] = [
  {
    id: 'pulse',
    roman: 'I',
    name: 'The Pulse Complication',
    modernEquivalent: 'Optical Cardiac & Autonomic Telemetry',
    tagline: 'A physician’s pocket chronometer, reborn in sapphire.',
    description:
      'Flush within the exhibition caseback lies an array of sapphire-lensed optical interferometers. Rather than pestering its bearer with clinical alarms, the Heritage S1 translates arterial cadence and autonomic equilibrium into a serene retrograde needle at six o’clock.',
    atelierNote:
      'Calibrated against historical 19th-century doctor’s pulsometers at the Hôpital Général de Genève.',
    dialLabel: 'PULSATIONS • PAR MINUTE',
    dialReading: '62 BPM',
    dialSubtext: 'REPOS SOUVERAIN',
    priceDelta: 0,
  },
  {
    id: 'courier',
    roman: 'II',
    name: 'The Discreet Courier',
    modernEquivalent: 'Sovereign Haptic Correspondence Filter',
    tagline: 'Never a glowing screen at dinner. Only a private tap on the wrist.',
    description:
      'An 18-karat gold eccentric mass within Calibre AV-01 delivers unmistakable, silent mechanical taps directly to the radius bone. Entrust up to five inner-circle correspondents with distinct rhythmic cadences—two soft taps for family, a triple cadence for your estate office.',
    atelierNote:
      'Zero blue light emission. The dial remains a tranquil enamel face while you remain unreachable to the trivial.',
    dialLabel: 'COURRIER PRIVÉ • ACTIF',
    dialReading: 'II TAPS',
    dialSubtext: 'CERCLE INTIME',
    priceDelta: 450,
  },
  {
    id: 'night',
    roman: 'III',
    name: 'The Night Watch',
    modernEquivalent: 'Circadian Architecture & Nocturnal Recovery',
    tagline: 'Measuring repose whether worn in slumber or resting on walnut.',
    description:
      'Worn through the night, micro-ballistocardiography charts deep restorative stillness and respiratory harmony. Placed upon its leather valet tray beside your bed, an ambient acoustic-barometric sensor quietly logs the quality of your chamber’s rest until dawn.',
    atelierNote:
      'At seven in the morning, the sub-dial briefly indicates your Readiness Index before returning to small seconds.',
    dialLabel: 'VEILLE NOCTURNE • VIII H',
    dialReading: '94 / 100',
    dialSubtext: 'SOMMEIL PROFOND',
    priceDelta: 300,
  },
  {
    id: 'navigator',
    roman: 'IV',
    name: 'The Navigator’s Register',
    modernEquivalent: 'Dual-Frequency Celestial & GNSS Wayfinding',
    tagline: 'Lose the trail in the Engadin; never lose your bearing home.',
    description:
      'Depress the four o’clock pusher to drop a sovereign waypoint—an anchorage in Portofino, a shooting box in Perthshire, or a refuge above Zermatt. Upon request, the blued sub-dial hand locks onto the true azimuth and distance in nautical miles or paces.',
    atelierNote:
      'Ceramic bezel conceals a quad-helical antenna with zero compromise to Faraday cage magnetism shielding.',
    dialLabel: 'CAP VRAI • AZIMUT',
    dialReading: '312° NW',
    dialSubtext: '1.4 MILLES NAUT.',
    priceDelta: 750,
  },
  {
    id: 'reserve',
    roman: 'V',
    name: 'The 14-Day Reserve',
    modernEquivalent: 'Twin-Barrel Kinetic & Photovoltaic Autonomy',
    tagline: 'Measured in fortnights, not nightly charging cables.',
    description:
      'Microscopic apertures laser-drilled along the railway minute track harvest ambient daylight, supplemented by a tungsten micro-rotor that winds a solid-state silicon cell. Fourteen days of full biometric and courier telemetry; sixty days of pure chronometric timekeeping.',
    atelierNote:
      'Accompanied by an heirloom burl-walnut winding plinth that replenishes the reserve wirelessly in forty minutes.',
    dialLabel: 'RÉSERVE DE MARCHE',
    dialReading: 'XIV JOURS',
    dialSubtext: 'AUTONOMIE PLEINE',
    priceDelta: 0,
  },
];

export interface HotspotInfo {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  position: [number, number, number];
  cameraPos: [number, number, number];
  cameraTarget: [number, number, number];
}

export const WATCH_HOTSPOTS: HotspotInfo[] = [
  {
    id: 'crown',
    number: '01',
    title: 'Fluted Tactile Crown & Courier Pushers',
    subtitle: '24-Tooth Genève Knurling with Optical Encoder',
    description:
      'Rotating the screw-down crown advances mechanical hands via a magnetic clutch while scrolling the micro-enamel complication register with weighted detents.',
    position: [2.15, 0.15, 0.1],
    cameraPos: [4.2, 1.3, 2.4],
    cameraTarget: [1.3, 0.05, 0.0],
  },
  {
    id: 'bezel',
    number: '02',
    title: 'Sintered Ceramic & Fluted Gold Ring',
    subtitle: '1,850 Vickers Hardness • Hidden GNSS Ring',
    description:
      'Fired at 1,500°C and polished with diamond paste to a mirror lustre. Beneath its non-conductive ceramic body sits our invisible dual-band satellite loop.',
    position: [-1.45, 1.25, 0.42],
    cameraPos: [-3.4, 2.5, 3.3],
    cameraTarget: [-0.8, 0.7, 0.2],
  },
  {
    id: 'dial',
    number: '03',
    title: 'Grand Feu & E-Ink Sapphire Aperture',
    subtitle: 'Bistable Electrophoretic Pigment in Enamel',
    description:
      'At six o’clock sits a recessed sapphire window bonded to titanium-dioxide and carbon micro-capsules—indistinguishable from wet ink on cotton paper, consuming power only when figures change.',
    position: [0.0, -0.78, 0.48],
    cameraPos: [0.0, -0.5, 4.1],
    cameraTarget: [0.0, -0.55, 0.2],
  },
  {
    id: 'caseback',
    number: '04',
    title: 'Calibre AV-01 & Biometric Sapphire',
    subtitle: 'Hand-Beveled Bridges • Optical Pulse Array',
    description:
      'Through the rear sapphire crystal, observe the 4Hz free-sprung balance wheel beating alongside the flush optical pulse prism and your bespoke lapidary engraving.',
    position: [0.65, -0.65, -0.52],
    cameraPos: [2.2, -1.2, -4.6],
    cameraTarget: [0.0, 0.0, -0.2],
  },
];

export interface StoryChapter {
  roman: string;
  eyebrow: string;
  title: string;
  body: string;
  footnote: string;
  metricLabel: string;
  metricValue: string;
  cameraPos: [number, number, number];
  watchRot: [number, number, number];
}

export const PINNED_CHAPTERS: StoryChapter[] = [
  {
    roman: 'I',
    eyebrow: 'THE SILENT ARCHITECTURE',
    title: 'Forged to outlive every silicon cycle.',
    body: 'Most modern instruments are born obsolete within twenty-four months. The Heritage S1 separates eternal horology from modular intelligence: its 904L steel and 18-karat gold chassis houses a replaceable telemetry core that our Geneva watchmakers service alongside the mechanical gear train for decades.',
    footnote: 'Guaranteed serviceability by Maison Aldervane until at least the year 2100.',
    metricLabel: 'CASE PROPORTION',
    metricValue: '39.5 mm × 10.4 mm',
    cameraPos: [0, 0.2, 5.4],
    watchRot: [0.18, -0.35, 0.05],
  },
  {
    roman: 'II',
    eyebrow: 'THE GRAND FEU DECEPTION',
    title: 'An enamel face that never glows in the dark.',
    body: 'We refused to place an emissive glass television upon a gentleman’s wrist. Instead, twelve coats of hand-ground vitreous enamel frame a bistable micro-pigment aperture at six o’clock. Under candlelight or Alpine sun, it reads with the calm legibility of an 1840 marine deck watch.',
    footnote: 'Zero nits of artificial backlight; illuminated at dusk solely by Swiss Super-LumiNova Grade X1.',
    metricLabel: 'DIAL LEGIBILITY',
    metricValue: '180° Paper-Ink Contrast',
    cameraPos: [0.2, -0.3, 4.1],
    watchRot: [0.05, 0.12, 0.0],
  },
  {
    roman: 'III',
    eyebrow: 'THE TACTILE TELEGRAPH',
    title: 'Governed by brass fingers, not swipes.',
    body: 'Fingerprints belong on crystal stemware, never on a watch glass. Every complication is summoned through the 24-flute winding crown and twin rectangular pushers—yielding the crisp, mechanical snap of a column-wheel chronograph.',
    footnote: 'Column-wheel tactile feedback rated to 500,000 actuations.',
    metricLabel: 'ACTUATION FORCE',
    metricValue: '4.2 Newtons • Column Wheel',
    cameraPos: [3.6, 0.5, 3.2],
    watchRot: [0.15, -0.95, 0.08],
  },
  {
    roman: 'IV',
    eyebrow: 'THE EXHIBITION HEART',
    title: 'Where Côte de Genève meets silent telemetry.',
    body: 'Turn the timepiece over to witness our compact between centuries: hand-chamfered German silver bridges and a beating hairspring share the same sapphire stage as a flush optical pulse sensor ring, encircled by your family’s engraved motto.',
    footnote: 'Individually regulated in six positions to -1 / +2 seconds per day.',
    metricLabel: 'OSCILLATION FREQUENCY',
    metricValue: '28,800 vph (4 Hz)',
    cameraPos: [0.4, 0.3, -5.0],
    watchRot: [0.1, 3.14, -0.05],
  },
];

export interface TimelineEra {
  year: string;
  eraTitle: string;
  location: string;
  headline: string;
  narrative: string;
  artifactName: string;
  illustrationType: 'escapement' | 'sextant' | 'polar' | 'manifesto' | 'calibre';
}

export const HERITAGE_TIMELINE: TimelineEra[] = [
  {
    year: '1794',
    eraTitle: 'The Cabinet on the Rhône',
    location: '14 Quai des Bergues, Geneva',
    headline: 'Henri-Auguste Aldervane establishes his fifth-floor cabinotier workshop.',
    narrative:
      'Working exclusively by north-facing window light above the Rhône, Henri-Auguste signs his first duplex pocket chronometer—No. 0001—introducing a temperature-compensated bimetallic balance that halves daily drift during Alpine crossings.',
    artifactName: 'Reference No. 0001 • Duplex Repeating Pocket Watch',
    illustrationType: 'escapement',
  },
  {
    year: '1848',
    eraTitle: 'The Royal Admiralty Commission',
    location: 'Greenwich & Geneva',
    headline: 'Sixty-two days at sea with zero terrestrial sightlines.',
    narrative:
      'Commissioned for H.M. Hydrographic Office, the Aldervane Marine Gimbal Chronometer achieves the highest trial score at the Royal Observatory Greenwich, establishing the House motto: "Patience is the only true precision."',
    artifactName: 'Admiralty Deck Box No. 114 • Mahogany & Brass',
    illustrationType: 'sextant',
  },
  {
    year: '1911',
    eraTitle: 'The Polar Meridian Expedition',
    location: '78° South, Ross Ice Shelf',
    headline: 'Formulated with whale-oil-free dry ruby lubrication at -42°C.',
    narrative:
      'Strapped over reindeer-skin gauntlets during the winter sledging journey, the Aldervane Expedition Sledge Watch varied by less than four-tenths of a second across ninety polar nights.',
    artifactName: 'Calibre Polaire 19 • Enamel Trench Chronometer',
    illustrationType: 'polar',
  },
  {
    year: '1969',
    eraTitle: 'The Parchment Refusal',
    location: 'Rue du Rhône, Geneva',
    headline: 'While thirty Swiss houses surrendered to disposable quartz, Aldervane locked its doors.',
    narrative:
      'Fourth-generation patriarch Édouard Aldervane published a three-sentence letter to collectors: "A watch that must be discarded when its circuit ages is an insult to one’s grandchildren. We shall wait until intelligence can be housed with the dignity of gold."',
    artifactName: 'The 1969 Vow • Archival Folio VII',
    illustrationType: 'manifesto',
  },
  {
    year: 'TODAY',
    eraTitle: 'The Heritage S1 & Calibre AV-01',
    location: 'Geneva Atelier',
    headline: 'Seven generations of patience. One quiet revolution.',
    narrative:
      'Fifty-seven years after Édouard’s letter, the seventh generation unveils Calibre AV-01: a free-sprung mechanical chronometer married to a serviceable solid-state biometric and courier core, beneath an unblemished Grand Feu enamel dial.',
    artifactName: 'The Aldervane Heritage S1 • Limited to 1,794 Pieces Annually',
    illustrationType: 'calibre',
  },
];

export interface SpecCategory {
  id: string;
  roman: string;
  title: string;
  items: { label: string; value: string }[];
}

export const SPECIFICATIONS: SpecCategory[] = [
  {
    id: 'case',
    roman: 'I',
    title: 'Case & Horological Architecture',
    items: [
      { label: 'Diameter', value: '39.5 mm (excluding crown)' },
      { label: 'Total Thickness', value: '10.4 mm (including domed sapphire crystal)' },
      { label: 'Lug-to-Lug Span', value: '46.8 mm with downward-curved ergonomic profile' },
      { label: 'Case Metallurgy', value: '904L Laurentian Steel, 18k Valais Rose Gold, or Grade-5 DLC Titanium' },
      { label: 'Bezel Construction', value: '120-flute bezel ring with sintered ZrO2 ceramic or Grand Feu insert' },
      { label: 'Water Resistance', value: '10 ATM / 100 Meters (1,000 hours pressure tested in Lake Geneva)' },
    ],
  },
  {
    id: 'calibre',
    roman: 'II',
    title: 'Calibre AV-01 Hybrid Movement',
    items: [
      { label: 'Calibre Designation', value: 'Manufacture Calibre AV-01 (Mechanical + Modular Co-Processor)' },
      { label: 'Mechanical Escapement', value: 'Swiss lever with silicon impulse pallet & free-sprung balance' },
      { label: 'Frequency', value: '28,800 vibrations per hour (4 Hz) • 39 Functional Ruby Jewels' },
      { label: 'Chronometric Precision', value: '-1 / +2 seconds per day (Observatory Certified)' },
      { label: 'Finishing', value: 'Hand-beveled anglage, Côte de Genève rayonnantes, black-polished screws' },
      { label: 'Service Architecture', value: 'Hot-swappable biometric stator cassette during routine 7-year oiling' },
    ],
  },
  {
    id: 'complications',
    roman: 'III',
    title: 'Silent Complications & Telemetry',
    items: [
      { label: 'The Pulse Complication', value: 'Dual-wavelength green/infrared PPG through flush rear sapphire' },
      { label: 'The Discreet Courier', value: '18k gold linear resonant actuator; custom rhythmic tap cadences' },
      { label: 'The Night Watch', value: 'Tri-axial micro-ballistocardiography + barometric sleep stage ledger' },
      { label: 'The Navigator’s Register', value: 'L1/L5 GNSS + temperature-compensated magnetic azimuth lock' },
      { label: 'The 14-Day Reserve', value: '14 days full telemetry; 60 days chronometric reserve; solar + kinetic' },
      { label: 'Companion Ledger', value: 'Encrypted end-to-end Geneva Vault application (iOS & bespoke leather tablet)' },
    ],
  },
  {
    id: 'dial-strap',
    roman: 'IV',
    title: 'Dial, Crystal & Habillage',
    items: [
      { label: 'Crystal', value: 'Box-domed synthetic sapphire (IOR 1.77) with 7-layer internal AR coating' },
      { label: 'Dial Craft', value: 'Engine-turned guilloché brass with kiln-fired enamel & applied 18k indices' },
      { label: 'Aperture Display', value: '300 DPI bistable electrophoretic sapphire window at 6 o’clock' },
      { label: 'Hands', value: 'Heat-blued or solid 18k champagne gold Breguet-pomme hands' },
      { label: 'Strap Width & Clasp', value: '20 mm tapering to 16 mm; curved quick-release spring bars & Ardillon buckle' },
    ],
  },
];

export interface PressQuote {
  publication: string;
  city: string;
  quote: string;
  author: string;
  issue: string;
}

export const PRESS_QUOTES: PressQuote[] = [
  {
    publication: 'La Revue des Montres',
    city: 'Genève',
    quote:
      '“For the first time in half a century, a connected instrument deserves to sit in the same safe as a Patek ref. 2526. You do not charge the Heritage S1; you commune with it.”',
    author: 'Jean-Luc de la Salle, Chief Horological Critic',
    issue: 'Autumn Monograph, Vol. CXII',
  },
  {
    publication: 'The Burlington Horological Gazette',
    city: 'London',
    quote:
      '“The Discreet Courier complication alone justifies the seven-year wait. Two almost imperceptible taps against the wrist cuff during an opera at Glyndebourne—and never a vulgar glowing rectangle in sight.”',
    author: 'Lord Alistair Vance-Sterling',
    issue: 'Quarterly Collector’s Review',
  },
  {
    publication: 'Chronométrie & Patrimoine',
    city: 'Zürich & Paris',
    quote:
      '“By housing the optical sensor inside a hand-engraved sapphire exhibition back and rendering data in real electrophoretic pigment, Maison Aldervane has solved the paradox of mortal silicon and immortal gold.”',
    author: 'Dr. Clara Vonlanthen, Curator of Mechanical Arts',
    issue: 'Special Salon Issue',
  },
  {
    publication: 'The Sovereign Ledger',
    city: 'New York & Tokyo',
    quote:
      '“Look closely at the six o’clock aperture under a 10x loupe and you still swear it was painted by a monastic miniaturist. It is the ultimate stealth wealth instrument.”',
    author: 'Kenjiro Takahashi',
    issue: 'Winter Craftsmanship Dossier',
  },
];

export const BOUTIQUE_SALONS = [
  {
    city: 'GENEVA',
    title: 'Maison Mère & Historical Cabinet',
    address: '14 Quai des Bergues, 1201 Genève',
    hours: 'By Private Invitation • Mon–Sat',
    coordinates: '46°12′22″N 06°08′44″E',
  },
  {
    city: 'LONDON',
    title: 'Mayfair Townhouse Salon',
    address: '94 Mount Street, Mayfair, W1K 2SZ',
    hours: 'By Appointment • Tue–Sat',
    coordinates: '51°30′34″N 00°09′05″W',
  },
  {
    city: 'NEW YORK',
    title: 'The Carlyle Drawing Room',
    address: '781 Madison Avenue, Upper East Side',
    hours: 'By Private Appointment',
    coordinates: '40°46′18″N 73°57′52″W',
  },
  {
    city: 'TOKYO',
    title: 'Ginza Namiki-dori Sanctuary',
    address: '6-7-18 Ginza, Chuo-ku, Tokyo',
    hours: 'By Private Invitation',
    coordinates: '35°40′14″N 139°45′46″E',
  },
];

export const BASE_PRICE_CHF = 18400;
