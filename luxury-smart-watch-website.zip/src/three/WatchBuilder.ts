import * as THREE from 'three';
import {
  CASE_OPTIONS,
  BEZEL_OPTIONS,
  STRAP_OPTIONS,
  COMPLICATIONS,
  WatchConfig,
} from '../data/aldervaneData';

export interface WatchRig {
  root: THREE.Group;
  strata: {
    crystalGroup: THREE.Group;
    bezelHandsGroup: THREE.Group;
    dialGroup: THREE.Group;
    caseStrapGroup: THREE.Group;
    movementGroup: THREE.Group;
    casebackGroup: THREE.Group;
  };
  hands: {
    hourHand: THREE.Group;
    minuteHand: THREE.Group;
    secondHand: THREE.Group;
    subDialHand: THREE.Group;
    reserveHand: THREE.Group;
  };
  movementParts: {
    balanceWheel: THREE.Group;
    gearOne: THREE.Mesh;
    gearTwo: THREE.Mesh;
  };
  materials: {
    caseMat: THREE.MeshPhysicalMaterial;
    goldAccentMat: THREE.MeshPhysicalMaterial;
    bezelCeramicMat: THREE.MeshPhysicalMaterial;
    crystalMat: THREE.MeshPhysicalMaterial;
    dialMat: THREE.MeshPhysicalMaterial;
    strapMat: THREE.MeshPhysicalMaterial;
    stitchMat: THREE.MeshStandardMaterial;
    casebackRimMat: THREE.MeshPhysicalMaterial;
  };
  updateConfig: (config: WatchConfig) => void;
  updateClockAndPhysics: (elapsedSeconds: number, explodeProgress: number) => void;
  dispose: () => void;
}

// Generate procedural brushed metal roughness/bump map
function createBrushedMetalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#888888';
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 2600; i++) {
    const y = Math.random() * 512;
    const len = 35 + Math.random() * 140;
    const x = Math.random() * 512;
    const shade = Math.floor(110 + Math.random() * 55);
    ctx.strokeStyle = `rgb(${shade},${shade},${shade})`;
    ctx.lineWidth = 0.6 + Math.random() * 1.1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + len, y + (Math.random() - 0.5) * 1.2);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  return tex;
}

// Generate procedural leather grain bump/normal texture
function createLeatherTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#7c7c7c';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle organic pebble cells
  for (let i = 0; i < 3800; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 1.2 + Math.random() * 2.8;
    const v = Math.floor(105 + Math.random() * 45);
    ctx.fillStyle = `rgb(${v},${v},${v})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 6);
  return tex;
}

// Render the Grand Feu Enamel & Guilloche Dial with live E-Ink Sub-dial
function drawDialCanvas(canvas: HTMLCanvasElement, config: WatchConfig) {
  const ctx = canvas.getContext('2d')!;
  const size = canvas.width;
  const cx = size / 2;
  const cy = size / 2;
  const radius = size * 0.46;

  const comp = COMPLICATIONS.find((c) => c.id === config.complicationId) || COMPLICATIONS[0];
  const isDarkDial = config.dialId !== 'ivory';

  ctx.clearRect(0, 0, size, size);

  // Base Enamel Fill
  const bgGrad = ctx.createRadialGradient(cx, cy, size * 0.04, cx, cy, size * 0.5);
  if (config.dialId === 'ivory') {
    bgGrad.addColorStop(0, '#F7F3EA');
    bgGrad.addColorStop(0.75, '#EFE8D8');
    bgGrad.addColorStop(1, '#DFD5C0');
  } else if (config.dialId === 'forest') {
    bgGrad.addColorStop(0, '#234239');
    bgGrad.addColorStop(0.75, '#193029');
    bgGrad.addColorStop(1, '#10201B');
  } else {
    bgGrad.addColorStop(0, '#2F3A46');
    bgGrad.addColorStop(0.75, '#212932');
    bgGrad.addColorStop(1, '#151B22');
  }
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, size, size);

  // Engine-Turned Sunray & Clous de Paris Guilloché in Center Medallion
  ctx.save();
  ctx.strokeStyle = isDarkDial ? 'rgba(201, 169, 106, 0.08)' : 'rgba(26, 26, 24, 0.055)';
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 180; i++) {
    const angle = (i / 180) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * (radius * 0.12), cy + Math.sin(angle) * (radius * 0.12));
    ctx.lineTo(cx + Math.cos(angle) * (radius * 0.72), cy + Math.sin(angle) * (radius * 0.72));
    ctx.stroke();
  }

  // Concentric Guilloché Rings
  for (let r = radius * 0.18; r < radius * 0.72; r += radius * 0.025) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  const inkColor = isDarkDial ? '#F4EFE6' : '#1A1A18';
  const goldColor = '#C9A96A';

  // Outer Chemin de Fer (Railway Minute Track)
  ctx.strokeStyle = isDarkDial ? 'rgba(201, 169, 106, 0.7)' : 'rgba(26, 26, 24, 0.75)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, radius * 0.95, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(cx, cy, radius * 0.905, 0, Math.PI * 2);
  ctx.stroke();

  // 60 Minute & 300 1/5th-Second Ticks
  for (let i = 0; i < 60; i++) {
    const angle = (i / 60) * Math.PI * 2 - Math.PI / 2;
    const isHour = i % 5 === 0;
    const innerR = isHour ? radius * 0.895 : radius * 0.905;
    const outerR = radius * 0.95;

    ctx.strokeStyle = isHour ? goldColor : inkColor;
    ctx.lineWidth = isHour ? 3.2 : 1.5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * innerR, cy + Math.sin(angle) * innerR);
    ctx.lineTo(cx + Math.cos(angle) * outerR, cy + Math.sin(angle) * outerR);
    ctx.stroke();
  }

  // Inner Medallion Ring
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, radius * 0.72, 0, Math.PI * 2);
  ctx.stroke();

  // Roman Numerals around chapter ring
  const romans = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];
  ctx.fillStyle = inkColor;
  ctx.font = `500 ${Math.round(size * 0.048)}px "Cormorant Garamond", Georgia, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  romans.forEach((numeral, idx) => {
    if (idx === 6) return; // 6 o'clock occupied by hybrid complication sub-dial
    const angle = (idx / 12) * Math.PI * 2 - Math.PI / 2;
    const r = radius * 0.81;
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle + Math.PI / 2);
    ctx.fillText(numeral, 0, 0);
    ctx.restore();
  });

  // 12 o'clock Power Reserve Retrograde Sector ("RÉSERVE XIV JOURS")
  const resY = cy - radius * 0.34;
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.arc(cx, resY, radius * 0.2, Math.PI * 1.18, Math.PI * 1.82);
  ctx.stroke();

  ctx.fillStyle = goldColor;
  ctx.font = `500 ${Math.round(size * 0.017)}px "Jost", sans-serif`;
  ctx.fillText('RÉSERVE XIV JOURS', cx, resY - radius * 0.23);

  // Maison Aldervane Signature Cartouche
  ctx.fillStyle = inkColor;
  ctx.font = `600 ${Math.round(size * 0.032)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillText('MAISON ALDERVANE', cx, cy - radius * 0.18);

  ctx.fillStyle = goldColor;
  ctx.font = `400 ${Math.round(size * 0.018)}px "Jost", sans-serif`;
  ctx.fillText('GENÈVE • 1794', cx, cy - radius * 0.11);

  ctx.fillStyle = isDarkDial ? 'rgba(244,239,230,0.65)' : 'rgba(26,26,24,0.65)';
  ctx.font = `italic ${Math.round(size * 0.018)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillText('Chronomètre Souverain S1', cx, cy - radius * 0.05);

  // 6 o'clock Hybrid E-Ink Sapphire Aperture & Small Seconds Sub-Dial
  const subY = cy + radius * 0.45;
  const subR = radius * 0.27;

  // Recessed Enamel/E-ink well
  ctx.fillStyle = isDarkDial ? '#111920' : '#E7DEC9';
  ctx.beginPath();
  ctx.arc(cx, subY, subR, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(cx, subY, subR, 0, Math.PI * 2);
  ctx.stroke();

  // Sub-dial ticks
  for (let i = 0; i < 30; i++) {
    const a = (i / 30) * Math.PI * 2;
    ctx.strokeStyle = i % 5 === 0 ? goldColor : inkColor;
    ctx.lineWidth = i % 5 === 0 ? 2 : 1;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * (subR * 0.86), subY + Math.sin(a) * (subR * 0.86));
    ctx.lineTo(cx + Math.cos(a) * (subR * 0.96), subY + Math.sin(a) * (subR * 0.96));
    ctx.stroke();
  }

  // Bistable E-Ink Paper Aperture Window inside the sub-dial
  const pillW = subR * 1.38;
  const pillH = subR * 0.72;
  ctx.fillStyle = isDarkDial ? '#19242D' : '#F4EFE6';
  ctx.strokeStyle = goldColor;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.roundRect(cx - pillW / 2, subY - pillH / 2, pillW, pillH, 8);
  ctx.fill();
  ctx.stroke();

  // Live Complication Readout inside Aperture
  ctx.fillStyle = goldColor;
  ctx.font = `500 ${Math.round(size * 0.0145)}px "Jost", sans-serif`;
  ctx.fillText(comp.dialLabel, cx, subY - pillH * 0.25);

  ctx.fillStyle = inkColor;
  ctx.font = `600 ${Math.round(size * 0.032)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillText(comp.dialReading, cx, subY + pillH * 0.04);

  ctx.fillStyle = isDarkDial ? 'rgba(201,169,106,0.85)' : 'rgba(90,42,46,0.9)';
  ctx.font = `500 ${Math.round(size * 0.013)}px "Jost", sans-serif`;
  ctx.fillText(comp.dialSubtext, cx, subY + pillH * 0.31);

  // Swiss Footer
  ctx.fillStyle = goldColor;
  ctx.font = `400 ${Math.round(size * 0.014)}px "Jost", sans-serif`;
  ctx.fillText('SWISS MADE • CALIBRE AV-01', cx, cy + radius * 0.88);
}

// Render the Exhibition Caseback Engraving Ring
function drawCasebackEngravingCanvas(canvas: HTMLCanvasElement, config: WatchConfig) {
  const ctx = canvas.getContext('2d')!;
  const size = canvas.width;
  const cx = size / 2;
  const cy = size / 2;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, size, size);

  // Circular brushed rings
  ctx.strokeStyle = '#686868';
  ctx.lineWidth = 2;
  for (let r = size * 0.34; r < size * 0.48; r += 3) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  const drawCircularText = (
    text: string,
    radius: number,
    startAngle: number,
    font: string,
    invert = false
  ) => {
    ctx.save();
    ctx.font = font;
    ctx.fillStyle = '#181818';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const chars = text.split('');
    const angleStep = (invert ? -1 : 1) * 0.052;
    const totalSpan = (chars.length - 1) * angleStep;
    let currentAngle = startAngle - totalSpan / 2;

    chars.forEach((ch) => {
      const x = cx + Math.cos(currentAngle) * radius;
      const y = cy + Math.sin(currentAngle) * radius;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(currentAngle + (invert ? -Math.PI / 2 : Math.PI / 2));
      ctx.fillText(ch, 0, 0);
      ctx.restore();
      currentAngle += angleStep;
    });
    ctx.restore();
  };

  const userInscription =
    config.engravingText.trim().length > 0
      ? config.engravingText.trim().toUpperCase()
      : 'TIME, INHERITED • GENÈVE';

  const fontSpec =
    config.engravingStyle === 'script'
      ? `italic 600 30px "Cormorant Garamond", Georgia, serif`
      : `600 26px "Cormorant Garamond", Georgia, serif`;

  drawCircularText(userInscription, size * 0.41, -Math.PI / 2, fontSpec, false);

  const serialStr = `MAISON ALDERVANE • NO. ${String(config.editionNumber).padStart(4, '0')} / 1794 • 10 ATM`;
  drawCircularText(
    serialStr,
    size * 0.41,
    Math.PI / 2,
    `500 21px "Jost", sans-serif`,
    true
  );
}

export function createProceduralWatch(initialConfig: WatchConfig): WatchRig {
  const root = new THREE.Group();

  // 6 Horological Strata Groups for Exploded View
  const crystalGroup = new THREE.Group();
  const bezelHandsGroup = new THREE.Group();
  const dialGroup = new THREE.Group();
  const caseStrapGroup = new THREE.Group();
  const movementGroup = new THREE.Group();
  const casebackGroup = new THREE.Group();

  root.add(
    crystalGroup,
    bezelHandsGroup,
    dialGroup,
    caseStrapGroup,
    movementGroup,
    casebackGroup
  );

  // Procedural Maps
  const brushedMap = createBrushedMetalTexture();
  const leatherMap = createLeatherTexture();

  const dialCanvas = document.createElement('canvas');
  dialCanvas.width = 1024;
  dialCanvas.height = 1024;
  drawDialCanvas(dialCanvas, initialConfig);
  const dialTexture = new THREE.CanvasTexture(dialCanvas);
  dialTexture.anisotropy = 8;

  const casebackCanvas = document.createElement('canvas');
  casebackCanvas.width = 1024;
  casebackCanvas.height = 1024;
  drawCasebackEngravingCanvas(casebackCanvas, initialConfig);
  const casebackTexture = new THREE.CanvasTexture(casebackCanvas);

  // Materials
  const caseOpt = CASE_OPTIONS[initialConfig.caseId];
  const bezelOpt = BEZEL_OPTIONS[initialConfig.bezelId];
  const strapOpt = STRAP_OPTIONS[initialConfig.strapId];

  const caseMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(caseOpt.colorHex),
    metalness: caseOpt.metalness ?? 0.94,
    roughness: caseOpt.roughness ?? 0.24,
    roughnessMap: brushedMap,
    bumpMap: brushedMap,
    bumpScale: 0.004,
    clearcoat: 0.25,
    clearcoatRoughness: 0.15,
    reflectivity: 1.0,
  });

  const goldAccentMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#C9A96A'),
    metalness: 0.95,
    roughness: 0.18,
    clearcoat: 0.35,
  });

  const bluedSteelMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#1A385A'),
    metalness: 0.92,
    roughness: 0.14,
    clearcoat: 0.6,
  });

  const bezelCeramicMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(bezelOpt.colorHex),
    metalness: 0.12,
    roughness: bezelOpt.roughness ?? 0.08,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
    reflectivity: 1.0,
  });

  const crystalMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#ffffff'),
    transparent: true,
    opacity: 0.26,
    transmission: 0.92,
    ior: 1.77,
    roughness: 0.03,
    thickness: 0.35,
    specularIntensity: 1.0,
    envMapIntensity: 1.8,
  });

  const dialMat = new THREE.MeshPhysicalMaterial({
    map: dialTexture,
    roughness: 0.26,
    metalness: 0.08,
    clearcoat: 0.45,
    clearcoatRoughness: 0.2,
  });

  const strapMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(strapOpt.colorHex),
    roughness: strapOpt.roughness ?? 0.58,
    metalness: 0.04,
    bumpMap: leatherMap,
    bumpScale: 0.018,
    clearcoat: 0.08,
  });

  const stitchMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(strapOpt.secondaryHex || '#DECBB1'),
    roughness: 0.65,
  });

  const casebackRimMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(caseOpt.colorHex),
    metalness: 0.92,
    roughness: 0.26,
    bumpMap: casebackTexture,
    bumpScale: 0.015,
    map: casebackTexture,
  });

  // =========================================================
  // 1. CASE & LUGS & CROWN (caseStrapGroup)
  // =========================================================
  const lathePoints = [
    new THREE.Vector2(1.72, -0.32),
    new THREE.Vector2(1.94, -0.26),
    new THREE.Vector2(2.02, -0.12),
    new THREE.Vector2(2.04, 0.06),
    new THREE.Vector2(1.98, 0.22),
    new THREE.Vector2(1.84, 0.3),
    new THREE.Vector2(1.68, 0.3),
    new THREE.Vector2(1.68, -0.32),
  ];
  const caseGeo = new THREE.LatheGeometry(lathePoints, 96);
  caseGeo.rotateX(Math.PI / 2);
  const caseMesh = new THREE.Mesh(caseGeo, caseMat);
  caseStrapGroup.add(caseMesh);

  // Champagne side recessed architectural band
  const sideRingGeo = new THREE.CylinderGeometry(2.045, 2.045, 0.06, 96, 1, true);
  sideRingGeo.rotateX(Math.PI / 2);
  const sideRingMesh = new THREE.Mesh(sideRingGeo, goldAccentMat);
  caseStrapGroup.add(sideRingMesh);

  // Sculpted Curved Lugs (4 positions)
  const lugPositions = [
    { x: -1.08, y: 1.92, rotZ: 0.14, flipY: 1 },
    { x: 1.08, y: 1.92, rotZ: -0.14, flipY: 1 },
    { x: -1.08, y: -1.92, rotZ: -0.14, flipY: -1 },
    { x: 1.08, y: -1.92, rotZ: 0.14, flipY: -1 },
  ];

  lugPositions.forEach((lp) => {
    const lugGroup = new THREE.Group();
    const lugBodyGeo = new THREE.BoxGeometry(0.34, 0.92, 0.38);
    const lugBody = new THREE.Mesh(lugBodyGeo, caseMat);
    lugBody.position.set(0, 0, -0.06);
    lugBody.rotation.x = lp.flipY * -0.24;
    lugGroup.add(lugBody);

    // Polished gold chamfer strip on top of lug
    const chamferGeo = new THREE.BoxGeometry(0.35, 0.88, 0.04);
    const chamfer = new THREE.Mesh(chamferGeo, goldAccentMat);
    chamfer.position.set(0, 0, 0.13);
    chamfer.rotation.x = lp.flipY * -0.24;
    lugGroup.add(chamfer);

    lugGroup.position.set(lp.x, lp.y, 0);
    lugGroup.rotation.z = lp.rotZ;
    caseStrapGroup.add(lugGroup);
  });

  // 3 o'clock Fluted Crown with Embossed Finial
  const crownGroup = new THREE.Group();
  const crownStemGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.25, 24);
  crownStemGeo.rotateZ(Math.PI / 2);
  const crownStem = new THREE.Mesh(crownStemGeo, caseMat);
  crownStem.position.x = 2.02;
  crownGroup.add(crownStem);

  const crownBodyGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.24, 32);
  crownBodyGeo.rotateZ(Math.PI / 2);
  const crownBody = new THREE.Mesh(crownBodyGeo, goldAccentMat);
  crownBody.position.x = 2.18;
  crownGroup.add(crownBody);

  // 24 Knurled Crown Ridges
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    const ridgeGeo = new THREE.BoxGeometry(0.22, 0.025, 0.025);
    const ridge = new THREE.Mesh(ridgeGeo, caseMat);
    ridge.position.set(2.18, Math.cos(a) * 0.28, Math.sin(a) * 0.28);
    ridge.rotation.x = a;
    crownGroup.add(ridge);
  }

  // Rectangular Chronograph / Courier Pushers at 2 & 4 o'clock
  [0.52, -0.52].forEach((angle) => {
    const pusherGroup = new THREE.Group();
    const pBaseGeo = new THREE.BoxGeometry(0.18, 0.36, 0.16);
    const pBase = new THREE.Mesh(pBaseGeo, caseMat);
    pBase.position.x = 2.04;
    pusherGroup.add(pBase);

    const pCapGeo = new THREE.BoxGeometry(0.12, 0.42, 0.19);
    const pCap = new THREE.Mesh(pCapGeo, goldAccentMat);
    pCap.position.x = 2.14;
    pusherGroup.add(pCap);

    pusherGroup.rotation.z = angle;
    crownGroup.add(pusherGroup);
  });
  caseStrapGroup.add(crownGroup);

  // =========================================================
  // 2. LEATHER STRAP, STITCHING & BUCKLE (caseStrapGroup)
  // =========================================================
  const buildStrapHalf = (isTop: boolean) => {
    const dir = isTop ? 1 : -1;
    const strapHalf = new THREE.Group();

    const segments = 12;
    for (let i = 0; i < segments; i++) {
      const t = i / segments;
      const width = 1.72 - t * 0.28; // Taper from 20mm to 16mm
      const segLen = 0.26;
      const yPos = dir * (2.05 + i * 0.235);
      const zDrop = -Math.pow(t, 1.65) * 0.95 - 0.05;
      const pitch = dir * (-0.12 - t * 0.42);

      const segGeo = new THREE.BoxGeometry(width, segLen, 0.14 - t * 0.03);
      const segMesh = new THREE.Mesh(segGeo, strapMat);
      segMesh.position.set(0, yPos, zDrop);
      segMesh.rotation.x = pitch;
      strapHalf.add(segMesh);

      // Contrast Saddle Stitches on left and right edges
      if (i < segments - 1) {
        [-1, 1].forEach((side) => {
          const stitchGeo = new THREE.BoxGeometry(0.032, 0.13, 0.155 - t * 0.03);
          const stitch = new THREE.Mesh(stitchGeo, stitchMat);
          stitch.position.set(side * (width * 0.43), yPos, zDrop);
          stitch.rotation.x = pitch;
          strapHalf.add(stitch);
        });
      }
    }

    // Keeper Loops on bottom strap, Ardillon Tang Buckle on top strap
    if (!isTop) {
      [-2.75, -3.35].forEach((ky, idx) => {
        const keeperGeo = new THREE.TorusGeometry(0.82 - idx * 0.04, 0.065, 12, 32);
        keeperGeo.scale(1.0, 0.26, 0.35);
        const keeper = new THREE.Mesh(keeperGeo, strapMat);
        keeper.position.set(0, ky, -0.25 - idx * 0.18);
        keeper.rotation.x = 0.25;
        strapHalf.add(keeper);
      });
    } else {
      const buckleGroup = new THREE.Group();
      const buckleFrameGeo = new THREE.TorusGeometry(0.74, 0.06, 16, 36);
      buckleFrameGeo.scale(1.0, 0.45, 0.3);
      const buckleFrame = new THREE.Mesh(buckleFrameGeo, goldAccentMat);
      buckleGroup.add(buckleFrame);

      const tangPinGeo = new THREE.CylinderGeometry(0.03, 0.02, 0.65, 12);
      const tangPin = new THREE.Mesh(tangPinGeo, goldAccentMat);
      tangPin.position.set(0, 0.1, 0.04);
      buckleGroup.add(tangPin);

      buckleGroup.position.set(0, 4.75, -0.98);
      buckleGroup.rotation.x = -0.52;
      strapHalf.add(buckleGroup);
    }

    return strapHalf;
  };

  caseStrapGroup.add(buildStrapHalf(true));
  caseStrapGroup.add(buildStrapHalf(false));

  // =========================================================
  // 3. BEZEL & REAL-TIME HANDS (bezelHandsGroup)
  // =========================================================
  // Ceramic Bezel Insert Torus
  const ceramicTorusGeo = new THREE.TorusGeometry(1.78, 0.13, 32, 96);
  ceramicTorusGeo.scale(1, 1, 0.48);
  const ceramicBezel = new THREE.Mesh(ceramicTorusGeo, bezelCeramicMat);
  ceramicBezel.position.z = 0.31;
  bezelHandsGroup.add(ceramicBezel);

  // Outer 96-Flute Knurled Bezel Skirt
  for (let i = 0; i < 96; i++) {
    const a = (i / 96) * Math.PI * 2;
    const fluteGeo = new THREE.BoxGeometry(0.035, 0.06, 0.11);
    const flute = new THREE.Mesh(fluteGeo, goldAccentMat);
    flute.position.set(Math.cos(a) * 1.91, Math.sin(a) * 1.91, 0.28);
    flute.rotation.z = a;
    bezelHandsGroup.add(flute);
  }

  // 12 Engraved Gold Cardinal Pips on Bezel
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const pipGeo =
      i === 3 // 12 o'clock triangle pip
        ? new THREE.ConeGeometry(0.055, 0.1, 3)
        : new THREE.BoxGeometry(0.025, 0.08, 0.02);
    const pip = new THREE.Mesh(pipGeo, goldAccentMat);
    pip.position.set(Math.cos(a) * 1.78, Math.sin(a) * 1.78, 0.365);
    pip.rotation.z = a + Math.PI / 2;
    bezelHandsGroup.add(pip);
  }

  // Sculpted Watch Hands (Hour, Minute, Second, Sub-Dial, Power Reserve)
  const hourHand = new THREE.Group();
  const hBladeGeo = new THREE.ConeGeometry(0.065, 0.98, 4);
  hBladeGeo.scale(1, 1, 0.25);
  hBladeGeo.translate(0, 0.38, 0);
  const hBlade = new THREE.Mesh(hBladeGeo, goldAccentMat);
  // Breguet Moon Tip
  const hPommeGeo = new THREE.TorusGeometry(0.065, 0.018, 12, 24);
  hPommeGeo.translate(0, 0.68, 0);
  const hPomme = new THREE.Mesh(hPommeGeo, goldAccentMat);
  hourHand.add(hBlade, hPomme);
  hourHand.position.z = 0.27;

  const minuteHand = new THREE.Group();
  const mBladeGeo = new THREE.ConeGeometry(0.05, 1.38, 4);
  mBladeGeo.scale(1, 1, 0.22);
  mBladeGeo.translate(0, 0.54, 0);
  const mBlade = new THREE.Mesh(mBladeGeo, goldAccentMat);
  const mPommeGeo = new THREE.TorusGeometry(0.052, 0.015, 12, 24);
  mPommeGeo.translate(0, 0.96, 0);
  const mPomme = new THREE.Mesh(mPommeGeo, goldAccentMat);
  minuteHand.add(mBlade, mPomme);
  minuteHand.position.z = 0.295;

  const secondHand = new THREE.Group();
  const sNeedleGeo = new THREE.BoxGeometry(0.018, 1.72, 0.012);
  sNeedleGeo.translate(0, 0.52, 0);
  const sNeedle = new THREE.Mesh(sNeedleGeo, bluedSteelMat);
  const sCounterGeo = new THREE.TorusGeometry(0.048, 0.012, 10, 24);
  sCounterGeo.translate(0, -0.28, 0);
  const sCounter = new THREE.Mesh(sCounterGeo, bluedSteelMat);
  const centerPinionGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.06, 24);
  centerPinionGeo.rotateX(Math.PI / 2);
  const centerPinion = new THREE.Mesh(centerPinionGeo, goldAccentMat);
  secondHand.add(sNeedle, sCounter, centerPinion);
  secondHand.position.z = 0.32;

  // 6 o'clock Sub-dial Hand
  const subDialHand = new THREE.Group();
  const subNeedleGeo = new THREE.ConeGeometry(0.022, 0.36, 4);
  subNeedleGeo.translate(0, 0.14, 0);
  const subNeedle = new THREE.Mesh(subNeedleGeo, bluedSteelMat);
  subDialHand.add(subNeedle);
  subDialHand.position.set(0, -0.74, 0.245);

  // 12 o'clock Reserve Retrograde Hand
  const reserveHand = new THREE.Group();
  const resNeedleGeo = new THREE.ConeGeometry(0.02, 0.28, 4);
  resNeedleGeo.translate(0, 0.12, 0);
  const resNeedle = new THREE.Mesh(resNeedleGeo, goldAccentMat);
  reserveHand.add(resNeedle);
  reserveHand.position.set(0, 0.56, 0.245);
  reserveHand.rotation.z = -0.42;

  bezelHandsGroup.add(hourHand, minuteHand, secondHand, subDialHand, reserveHand);

  // =========================================================
  // 4. GRAND FEU DIAL & APPLIED INDICES (dialGroup)
  // =========================================================
  const dialDiscGeo = new THREE.CylinderGeometry(1.68, 1.68, 0.05, 96);
  dialDiscGeo.rotateX(Math.PI / 2);
  const dialDisc = new THREE.Mesh(dialDiscGeo, dialMat);
  dialDisc.position.z = 0.2;
  dialGroup.add(dialDisc);

  // 12 Applied 3D Gold Faceted Hour Indices
  for (let i = 0; i < 12; i++) {
    if (i === 6) continue; // Sub-dial at 6
    const a = (i / 12) * Math.PI * 2;
    const markerGeo = new THREE.BoxGeometry(0.042, 0.14, 0.032);
    const marker = new THREE.Mesh(markerGeo, goldAccentMat);
    const r = 1.48;
    marker.position.set(Math.cos(a) * r, Math.sin(a) * r, 0.235);
    marker.rotation.z = a + Math.PI / 2;
    dialGroup.add(marker);
  }

  // Applied Gold Bezel Frame around 6 o'clock Complication Sub-dial
  const subRingGeo = new THREE.TorusGeometry(0.44, 0.018, 16, 48);
  const subRing = new THREE.Mesh(subRingGeo, goldAccentMat);
  subRing.position.set(0, -0.74, 0.23);
  dialGroup.add(subRing);

  // =========================================================
  // 5. DOMED SAPPHIRE CRYSTAL (crystalGroup)
  // =========================================================
  const crystalDomeGeo = new THREE.SphereGeometry(
    2.45,
    64,
    32,
    0,
    Math.PI * 2,
    0,
    0.72
  );
  crystalDomeGeo.scale(1, 1, 0.28);
  crystalDomeGeo.rotateX(Math.PI / 2);
  const crystalMesh = new THREE.Mesh(crystalDomeGeo, crystalMat);
  crystalMesh.position.z = -0.22;
  crystalGroup.add(crystalMesh);

  // =========================================================
  // 6. INTERNAL CALIBRE AV-01 MOVEMENT (movementGroup)
  // =========================================================
  const mainplateMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#B7B3A8'),
    metalness: 0.88,
    roughness: 0.28,
    roughnessMap: brushedMap,
  });

  const rubyMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#9E1B32'),
    metalness: 0.1,
    roughness: 0.08,
    transmission: 0.65,
    ior: 1.76,
  });

  const mainplateGeo = new THREE.CylinderGeometry(1.56, 1.56, 0.18, 64);
  mainplateGeo.rotateX(Math.PI / 2);
  const mainplate = new THREE.Mesh(mainplateGeo, mainplateMat);
  mainplate.position.z = -0.02;
  movementGroup.add(mainplate);

  // Sculpted Geneva Bridge Plates
  const bridgeGeo = new THREE.CylinderGeometry(1.42, 1.42, 0.08, 48, 1, false, 0.3, 4.2);
  bridgeGeo.rotateX(Math.PI / 2);
  const bridge = new THREE.Mesh(bridgeGeo, mainplateMat);
  bridge.position.z = -0.12;
  movementGroup.add(bridge);

  // Golden Oscillating Balance Wheel & Cock at 6 o'clock
  const balanceWheel = new THREE.Group();
  const balRimGeo = new THREE.TorusGeometry(0.36, 0.032, 16, 48);
  const balRim = new THREE.Mesh(balRimGeo, goldAccentMat);
  const balSpoke1 = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.028, 0.02), goldAccentMat);
  const balSpoke2 = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.7, 0.02), goldAccentMat);
  const balJewel = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 16), rubyMat);
  balJewel.rotateX(Math.PI / 2);
  balanceWheel.add(balRim, balSpoke1, balSpoke2, balJewel);
  balanceWheel.position.set(0.0, -0.78, -0.15);
  movementGroup.add(balanceWheel);

  // Meshing Gear Train Wheels
  const createToothedGear = (radius: number, teeth: number) => {
    const g = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, 0.04, teeth).rotateX(Math.PI / 2),
      goldAccentMat
    );
    return g;
  };
  const gearOne = createToothedGear(0.38, 28);
  gearOne.position.set(-0.48, 0.25, -0.14);
  const gearTwo = createToothedGear(0.28, 22);
  gearTwo.position.set(0.45, 0.35, -0.14);
  movementGroup.add(gearOne, gearTwo);

  // Ruby Chatons & Blued Screws on Bridges
  const jewelCoords = [
    [-0.48, 0.25],
    [0.45, 0.35],
    [0, 0],
    [-0.75, -0.25],
    [0.72, -0.22],
    [0, 0.78],
  ];
  jewelCoords.forEach(([jx, jy], idx) => {
    const jMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.055, 0.055, 0.03, 18).rotateX(Math.PI / 2),
      idx % 2 === 0 ? rubyMat : bluedSteelMat
    );
    jMesh.position.set(jx, jy, -0.165);
    movementGroup.add(jMesh);
  });

  // Biometric Optical Pulse Sensor & Solid-State 14-Day Reserve Toroid
  const sensorRingGeo = new THREE.TorusGeometry(0.98, 0.06, 16, 64);
  const sensorRingMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#1F3A32'),
    metalness: 0.4,
    roughness: 0.15,
    clearcoat: 1.0,
  });
  const sensorRing = new THREE.Mesh(sensorRingGeo, sensorRingMat);
  sensorRing.position.z = -0.15;
  movementGroup.add(sensorRing);

  // =========================================================
  // 7. EXHIBITION CASEBACK WITH LIVE ENGRAVING (casebackGroup)
  // =========================================================
  const backRimGeo = new THREE.RingGeometry(1.08, 1.76, 64);
  const backRim = new THREE.Mesh(backRimGeo, casebackRimMat);
  backRim.rotation.y = Math.PI;
  backRim.position.z = -0.33;
  casebackGroup.add(backRim);

  const backSkirtGeo = new THREE.CylinderGeometry(1.76, 1.66, 0.08, 12);
  backSkirtGeo.rotateX(Math.PI / 2);
  const backSkirt = new THREE.Mesh(backSkirtGeo, caseMat);
  backSkirt.position.z = -0.29;
  casebackGroup.add(backSkirt);

  const backCrystalGeo = new THREE.CircleGeometry(1.08, 64);
  const backCrystal = new THREE.Mesh(backCrystalGeo, crystalMat);
  backCrystal.rotation.y = Math.PI;
  backCrystal.position.z = -0.325;
  casebackGroup.add(backCrystal);

  // =========================================================
  // LIVE CONFIGURATION & PHYSICS UPDATERS
  // =========================================================
  const updateConfig = (nextConfig: WatchConfig) => {
    const cOpt = CASE_OPTIONS[nextConfig.caseId];
    const bOpt = BEZEL_OPTIONS[nextConfig.bezelId];
    const sOpt = STRAP_OPTIONS[nextConfig.strapId];

    caseMat.color.set(cOpt.colorHex);
    caseMat.metalness = cOpt.metalness ?? 0.94;
    caseMat.roughness = cOpt.roughness ?? 0.24;

    casebackRimMat.color.set(cOpt.colorHex);

    bezelCeramicMat.color.set(bOpt.colorHex);
    bezelCeramicMat.roughness = bOpt.roughness ?? 0.08;

    strapMat.color.set(sOpt.colorHex);
    strapMat.roughness = sOpt.roughness ?? 0.58;
    stitchMat.color.set(sOpt.secondaryHex || '#DECBB1');

    drawDialCanvas(dialCanvas, nextConfig);
    dialTexture.needsUpdate = true;

    drawCasebackEngravingCanvas(casebackCanvas, nextConfig);
    casebackTexture.needsUpdate = true;
  };

  const updateClockAndPhysics = (elapsedSeconds: number, explodeProgress: number) => {
    // 1. Real Current Time on Watch Hands
    const now = new Date();
    const ms = now.getMilliseconds();
    const secs = now.getSeconds() + ms / 1000;
    const mins = now.getMinutes() + secs / 60;
    const hrs = (now.getHours() % 12) + mins / 60;

    // Quantize sweeping second hand to 8Hz (28,800 vph) mechanical beat
    const quantizedSecs = Math.floor(secs * 8) / 8;

    secondHand.rotation.z = -(quantizedSecs / 60) * Math.PI * 2;
    minuteHand.rotation.z = -(mins / 60) * Math.PI * 2;
    hourHand.rotation.z = -(hrs / 12) * Math.PI * 2;
    subDialHand.rotation.z = -(secs / 30) * Math.PI * 2;

    // 2. Calibre AV-01 Escapement & Balance Wheel Oscillation (4Hz)
    balanceWheel.rotation.z = Math.sin(elapsedSeconds * Math.PI * 8) * 0.65;
    gearOne.rotation.z = elapsedSeconds * 0.45;
    gearTwo.rotation.z = -elapsedSeconds * 0.62;

    // 3. Exploded View Z-Axis Separation
    const e = explodeProgress;
    crystalGroup.position.z = THREE.MathUtils.lerp(crystalGroup.position.z, e * 1.65, 0.1);
    bezelHandsGroup.position.z = THREE.MathUtils.lerp(bezelHandsGroup.position.z, e * 0.95, 0.1);
    dialGroup.position.z = THREE.MathUtils.lerp(dialGroup.position.z, e * 0.35, 0.1);
    caseStrapGroup.position.z = THREE.MathUtils.lerp(caseStrapGroup.position.z, 0, 0.1);
    movementGroup.position.z = THREE.MathUtils.lerp(movementGroup.position.z, -e * 0.68, 0.1);
    casebackGroup.position.z = THREE.MathUtils.lerp(casebackGroup.position.z, -e * 1.45, 0.1);
  };

  const dispose = () => {
    brushedMap.dispose();
    leatherMap.dispose();
    dialTexture.dispose();
    casebackTexture.dispose();
  };

  return {
    root,
    strata: {
      crystalGroup,
      bezelHandsGroup,
      dialGroup,
      caseStrapGroup,
      movementGroup,
      casebackGroup,
    },
    hands: {
      hourHand,
      minuteHand,
      secondHand,
      subDialHand,
      reserveHand,
    },
    movementParts: {
      balanceWheel,
      gearOne,
      gearTwo,
    },
    materials: {
      caseMat,
      goldAccentMat,
      bezelCeramicMat,
      crystalMat,
      dialMat,
      strapMat,
      stitchMat,
      casebackRimMat,
    },
    updateConfig,
    updateClockAndPhysics,
    dispose,
  };
}
