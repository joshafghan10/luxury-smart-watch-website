class HorologicalSoundEngine {
  private ctx: AudioContext | null = null;
  private isEnabled = false;
  private tickInterval: number | null = null;
  private roomGain: GainNode | null = null;
  private step = 0;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public toggle(enable?: boolean): boolean {
    const next = typeof enable === 'boolean' ? enable : !this.isEnabled;
    this.isEnabled = next;
    if (this.isEnabled) {
      this.startAmbientAndTick();
      this.playCrownClick(1.1);
    } else {
      this.stopAmbientAndTick();
    }
    return this.isEnabled;
  }

  public getEnabled(): boolean {
    return this.isEnabled;
  }

  private startAmbientAndTick() {
    const ctx = this.ensureContext();
    if (!ctx) return;

    // Subtle candlelit room tone
    if (!this.roomGain) {
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 0.08;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 190;

      const gain = ctx.createGain();
      gain.gain.value = 0.015;

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      whiteNoise.start(0);
      this.roomGain = gain;
    } else {
      this.roomGain.gain.setTargetAtTime(0.015, ctx.currentTime, 0.2);
    }

    if (this.tickInterval) window.clearInterval(this.tickInterval);
    // 4Hz / half-beat gentle mechanical escapement pulse
    this.tickInterval = window.setInterval(() => {
      if (this.isEnabled && !document.hidden) {
        this.playEscapementTick();
      }
    }, 500);
  }

  private stopAmbientAndTick() {
    if (this.tickInterval) {
      window.clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
    if (this.roomGain && this.ctx) {
      this.roomGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.15);
    }
  }

  public playEscapementTick() {
    if (!this.isEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    this.step = (this.step + 1) % 2;

    // Impulse + locking jewel resonance
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(this.step === 0 ? 3400 : 3850, now);
    osc.frequency.exponentialRampToValueAtTime(900, now + 0.012);

    filter.type = 'bandpass';
    filter.frequency.value = 3200;
    filter.Q.value = 6.0;

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(this.step === 0 ? 0.022 : 0.016, now + 0.0015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.018);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.02);
  }

  public playCrownClick(pitchMultiplier = 1.0) {
    if (!this.isEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1450 * pitchMultiplier, now);
    osc.frequency.exponentialRampToValueAtTime(360 * pitchMultiplier, now + 0.028);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.06, now + 0.002);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.032);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.035);
  }

  public playCourierCadence(taps: number[] = [0, 180]) {
    // Allow playing courier demo even if ambient tick is off when explicitly clicked, or respect sound engine
    const ctx = this.ensureContext();
    if (!ctx) return;

    taps.forEach((delayMs) => {
      const start = ctx.currentTime + delayMs / 1000;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Low, weighted gold-rotor thump
      osc.type = 'sine';
      osc.frequency.setValueAtTime(145, start);
      osc.frequency.exponentialRampToValueAtTime(58, start + 0.065);

      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.14, start + 0.006);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(start);
      osc.stop(start + 0.085);
    });
  }
}

export const soundEngine = new HorologicalSoundEngine();
