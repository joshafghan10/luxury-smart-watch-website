import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import {
  PINNED_CHAPTERS,
  WatchConfig,
} from './data/aldervaneData';
import { AldervaneCrest, OrnamentalDivider } from './components/CrestSvg';
import { TurntableWatchMini } from './components/TurntableWatchMini';
import { AtelierWatchViewer } from './components/AtelierWatchViewer';
import { ComplicationsSection } from './components/ComplicationsSection';
import { CraftsmanshipSection } from './components/CraftsmanshipSection';
import { HeritageTimeline } from './components/HeritageTimeline';
import { ConfiguratorSection } from './components/ConfiguratorSection';
import { SpecsAndPressSection } from './components/SpecsAndPressSection';
import { soundEngine } from './utils/soundEngine';

gsap.registerPlugin(ScrollTrigger);

const MANIFESTO_TEXT =
  'For two hundred and thirty-two years our cabinotiers on the Quai des Bergues have held a single conviction: an instrument worn against the pulse should never clamor for your gaze. When silicon arrived to measure the heart and summon the courier, we refused to house it behind a glowing pane of disposable glass. Instead, we taught gold, vitreous enamel, and a free-sprung balance wheel to speak in whispers.';

export function App() {
  // Curtain Loader state
  const [loaderProgress, setLoaderProgress] = useState(0);
  const [loaderDismissed, setLoaderDismissed] = useState(false);

  // Global Theme & Audio State
  const [isEveningMode, setIsEveningMode] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);

  // Navigation hide-on-scroll-down / show-on-scroll-up + overall scroll progress
  const [navHidden, setNavHidden] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  // Hero scroll-expand progress (0 -> 1)
  const [heroExpand, setHeroExpand] = useState(0);
  const heroSectionRef = useRef<HTMLElement>(null);

  // Manifesto word highlight progress (0 -> 1)
  const [manifestoProgress, setManifestoProgress] = useState(0.25);
  const manifestoRef = useRef<HTMLElement>(null);

  // Pinned 3D Storytelling active chapter (0 -> 3)
  const [activeStoryChapter, setActiveStoryChapter] = useState(0);
  const chapterRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Custom Champagne Ring Cursor
  const cursorRingRef = useRef<HTMLDivElement>(null);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const [cursorExpanded, setCursorExpanded] = useState(false);

  // Shared Bespoke Watch Configuration across 3D Viewer, Configurator & Appointment Form
  const [watchConfig, setWatchConfig] = useState<WatchConfig>({
    caseId: 'steel',
    bezelId: 'forest',
    dialId: 'ivory',
    strapId: 'cognac',
    complicationId: 'pulse',
    engravingText: 'H.A. • TIME, INHERITED',
    engravingStyle: 'roman',
    editionNumber: 142,
  });

  // 1. Intro Curtain Loader Animation
  useEffect(() => {
    let current = 0;
    const interval = window.setInterval(() => {
      current += 9;
      if (current >= 100) {
        setLoaderProgress(100);
        window.clearInterval(interval);
        window.setTimeout(() => {
          setLoaderDismissed(true);
        }, 420);
      } else {
        setLoaderProgress(current);
      }
    }, 38);
    return () => window.clearInterval(interval);
  }, []);

  // 2. Day / Evening Mode Root Class Sync
  useEffect(() => {
    const html = document.documentElement;
    if (isEveningMode) {
      html.classList.add('evening-mode');
    } else {
      html.classList.remove('evening-mode');
    }
  }, [isEveningMode]);

  // 3. Lenis Smooth Scroll & Scroll Progress / Nav Visibility
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches;

    let lenis: Lenis | null = null;
    if (!prefersReducedMotion) {
      lenis = new Lenis({
        duration: 1.15,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
      });

      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add((time) => {
        lenis?.raf(time * 1000);
      });
      gsap.ticker.lagSmoothing(0);
    }

    let lastScrollY = window.scrollY;
    const handleScroll = () => {
      const y = window.scrollY;
      const maxScroll = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight
      );
      setScrollProgress(Math.min(1, Math.max(0, y / maxScroll)));

      if (y > 160 && y > lastScrollY + 6) {
        setNavHidden(true);
      } else if (y < lastScrollY - 6 || y <= 160) {
        setNavHidden(false);
      }
      lastScrollY = y;

      // Calculate Hero Expand Progress based on hero section scroll
      if (heroSectionRef.current) {
        const rect = heroSectionRef.current.getBoundingClientRect();
        const total = Math.max(1, heroSectionRef.current.offsetHeight - window.innerHeight);
        const scrolled = -rect.top;
        const p = Math.min(1, Math.max(0, scrolled / total));
        setHeroExpand(p);
      }

      // Calculate Manifesto Word Highlight Progress
      if (manifestoRef.current) {
        const rect = manifestoRef.current.getBoundingClientRect();
        const winH = window.innerHeight;
        const p = (winH * 0.82 - rect.top) / (rect.height + winH * 0.35);
        setManifestoProgress(Math.min(1, Math.max(0.08, p)));
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (lenis) {
        lenis.destroy();
      }
    };
  }, []);

  // 4. IntersectionObserver for Pinned 3D Storytelling Chapters
  useEffect(() => {
    const observers: IntersectionObserver[] = [];
    chapterRefs.current.forEach((el, index) => {
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setActiveStoryChapter(index);
          }
        },
        { threshold: 0.45 }
      );
      obs.observe(el);
      observers.push(obs);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);

  // 5. Custom Champagne Ring Cursor
  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      if (cursorRingRef.current && cursorDotRef.current) {
        cursorRingRef.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`;
        cursorDotRef.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`;
      }
      const target = e.target as HTMLElement | null;
      const isInteractive = !!target?.closest('button, a, input, select, textarea, [role="button"]');
      setCursorExpanded(isInteractive);
    };

    window.addEventListener('mousemove', moveCursor, { passive: true });
    return () => window.removeEventListener('mousemove', moveCursor);
  }, []);

  const manifestoWords = MANIFESTO_TEXT.split(' ');
  const activeChapterObj = PINNED_CHAPTERS[activeStoryChapter] || PINNED_CHAPTERS[0];

  // Interpolated Hero Watch Rotation & Scale driven by scroll
  const heroWatchRotation: [number, number, number] = [
    0.22 - heroExpand * 0.14,
    -0.55 + heroExpand * 0.48,
    0.06 - heroExpand * 0.06,
  ];
  const heroWatchScale = 0.86 + heroExpand * 0.24;

  const scrollToSection = (id: string) => {
    soundEngine.playCrownClick(1.0);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen selection:bg-[#C9A96A]/30">
      {/* =========================================================
          PAPER-GRAIN NOISE OVERLAY (3.5% OPACITY)
         ========================================================= */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-40 opacity-[0.035]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* =========================================================
          CUSTOM CHAMPAGNE RING CURSOR (DESKTOP)
         ========================================================= */}
      <div
        ref={cursorRingRef}
        aria-hidden="true"
        className="pointer-events-none fixed top-0 left-0 z-50 hidden lg:block -translate-x-1/2 -translate-y-1/2 transition-transform duration-150 ease-out"
      >
        <div
          className={`rounded-full border border-[#C9A96A] transition-all duration-300 ${
            cursorExpanded
              ? 'w-12 h-12 bg-[#C9A96A]/15 -ml-6 -mt-6'
              : 'w-7 h-7 bg-transparent -ml-3.5 -mt-3.5'
          }`}
        />
      </div>
      <div
        ref={cursorDotRef}
        aria-hidden="true"
        className="pointer-events-none fixed top-0 left-0 z-50 hidden lg:block w-1.5 h-1.5 -ml-[3px] -mt-[3px] rounded-full bg-[#C9A96A]"
      />

      {/* =========================================================
          1. INTRO CURTAIN LOADER
         ========================================================= */}
      {!loaderDismissed && (
        <div
          className={`fixed inset-0 z-50 bg-[#14202B] text-[#F4EFE6] flex flex-col items-center justify-center px-6 transition-transform duration-1000 ease-[cubic-bezier(0.76,0,0.24,1)] ${
            loaderProgress >= 100 ? '-translate-y-full' : 'translate-y-0'
          }`}
        >
          <AldervaneCrest size={96} className="mb-6" />
          <p className="label-eyebrow text-[#C9A96A] mb-2">
            MAISON ALDERVANE • GENÈVE
          </p>
          <p className="font-display italic text-xl text-[#F4EFE6]/80 mb-6">
            Time, inherited.
          </p>
          <div className="w-60 h-[1px] bg-[#C9A96A]/25 overflow-hidden mb-3">
            <div
              className="h-full bg-[#C9A96A] transition-all duration-150"
              style={{ width: `${loaderProgress}%` }}
            />
          </div>
          <span className="font-display text-xs tracking-[0.28em] text-[#C9A96A]">
            NO. {String(Math.round((loaderProgress / 100) * 1794)).padStart(4, '0')} / 1794
          </span>
        </div>
      )}

      {/* =========================================================
          TOP SCROLL PROGRESS HAIRLINE & FLOATING HOROLOGICAL DIAL
         ========================================================= */}
      <div className="fixed top-0 left-0 right-0 h-[2px] z-50 bg-transparent pointer-events-none">
        <div
          className="h-full bg-[#C9A96A] transition-all duration-150"
          style={{ width: `${scrollProgress * 100}%` }}
        />
      </div>

      <div
        aria-hidden="true"
        className="fixed bottom-6 right-6 z-30 hidden sm:flex items-center gap-2.5 bg-[#14202B]/90 border border-[#C9A96A]/45 px-3.5 py-2 text-[#F4EFE6] backdrop-blur-md shadow-xl"
      >
        <svg viewBox="0 0 36 36" className="w-7 h-7 -rotate-90">
          <circle
            cx="18"
            cy="18"
            r="14"
            fill="none"
            stroke="rgba(201,169,106,0.25)"
            strokeWidth="2"
          />
          <circle
            cx="18"
            cy="18"
            r="14"
            fill="none"
            stroke="#C9A96A"
            strokeWidth="2"
            strokeDasharray={88}
            strokeDashoffset={88 - 88 * scrollProgress}
          />
        </svg>
        <div className="text-[10px] tracking-[0.2em] uppercase">
          <div className="text-[#C9A96A]">RESERVE</div>
          <div>{Math.round(scrollProgress * 100)}% READ</div>
        </div>
      </div>

      {/* =========================================================
          2. NAVIGATION HEADER (HIDE ON SCROLL DOWN, SHOW ON UP)
         ========================================================= */}
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          navHidden ? '-translate-y-full' : 'translate-y-0'
        }`}
      >
        <div className="border-b border-[#C9A96A]/25 bg-[var(--bg-elevated)] backdrop-blur-md">
          <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-12 h-20 flex items-center justify-between gap-4">
            {/* Brand Monogram & Name */}
            <a
              href="#top"
              className="flex items-center gap-3 group focus:outline-none"
            >
              <AldervaneCrest size={44} />
              <div>
                <span className="block font-display text-lg sm:text-xl tracking-[0.14em] uppercase leading-none">
                  Maison Aldervane
                </span>
                <span className="block text-[9px] tracking-[0.28em] uppercase text-[#C9A96A] mt-1">
                  Genève • 1794
                </span>
              </div>
            </a>

            {/* Primary Navigation Links */}
            <nav
              aria-label="Primary Navigation"
              className="hidden xl:flex items-center gap-8 text-xs uppercase tracking-[0.22em]"
            >
              <button
                type="button"
                onClick={() => scrollToSection('heritage')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                Heritage
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('atelier-viewer')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                The Watch (3D)
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('complications')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                Complications
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('atelier')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                Atelier
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('configurator')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                Commission
              </button>
              <button
                type="button"
                onClick={() => scrollToSection('private-viewing')}
                className="hover:text-[#C9A96A] transition-colors cursor-pointer"
              >
                Private Viewing
              </button>
            </nav>

            {/* Right Controls: Serial Counter, Sound Toggle, Day/Evening Toggle */}
            <div className="flex items-center gap-2.5 sm:gap-3">
              {/* Engraved Serial Counter Badge */}
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 border border-[#C9A96A]/35 text-[10px] tracking-[0.2em] uppercase">
                <span className="text-[#C9A96A]">No.</span>
                <span className="font-display text-sm">
                  {String(watchConfig.editionNumber).padStart(4, '0')} / 1794
                </span>
              </div>

              {/* Opt-in Sound Design Toggle (Off by default) */}
              <button
                type="button"
                onClick={() => {
                  const next = soundEngine.toggle();
                  setSoundEnabled(next);
                }}
                aria-pressed={soundEnabled}
                title="Toggle mechanical escapement tick and atelier room tone"
                className={`px-3 py-1.5 border text-[10px] uppercase tracking-[0.18em] flex items-center gap-2 transition-colors cursor-pointer ${
                  soundEnabled
                    ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                    : 'border-[#C9A96A]/40 hover:border-[#C9A96A]'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    soundEnabled ? 'bg-[#C9A96A] animate-ping' : 'bg-[#C9A96A]/50'
                  }`}
                />
                <span>{soundEnabled ? 'Calibre Audio: On' : 'Audio: Mute'}</span>
              </button>

              {/* Day / Evening Mode Toggle */}
              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.1);
                  setIsEveningMode((prev) => !prev);
                }}
                aria-pressed={isEveningMode}
                className="px-3 py-1.5 border border-[#C9A96A]/40 hover:border-[#C9A96A] text-[10px] uppercase tracking-[0.18em] transition-colors cursor-pointer"
              >
                {isEveningMode ? '☀ Day Salon' : '☾ Evening Study'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* =========================================================
          3. SCROLL-EXPAND HERO (PORTRAIT WINDOW -> FULL VIEWPORT)
         ========================================================= */}
      <section
        id="top"
        ref={heroSectionRef}
        className="relative h-[200vh]"
      >
        <div
          className="sticky top-0 h-screen w-full overflow-hidden flex flex-col items-center justify-center transition-colors duration-700"
          style={{
            backgroundColor:
              heroExpand > 0.35
                ? '#1F3A32'
                : isEveningMode
                ? '#14202B'
                : '#F4EFE6',
            color: heroExpand > 0.35 || isEveningMode ? '#F4EFE6' : '#1A1A18',
          }}
        >
          {/* Top Archival Subtitle */}
          <div className="relative z-20 text-center px-6 pt-16 mb-4">
            <div className="inline-flex items-center gap-3 text-xs tracking-[0.26em] uppercase text-[#C9A96A] mb-2">
              <span>I</span>
              <span className="w-6 h-[1px] bg-[#C9A96A]" />
              <span>14 QUAI DES BERGUES • GENÈVE</span>
            </div>
            <h1 className="heading-hero">
              Time, inherited.
            </h1>
            <p className="font-display italic text-xl sm:text-2xl md:text-3xl text-[#C9A96A] mt-2">
              Seven generations of patience. One quiet revolution.
            </p>
          </div>

          {/* Expanding Gilded Portrait Frame containing the 3D Watch */}
          <div
            className="relative z-10 flex items-center justify-center transition-all duration-200 ease-out border border-[#C9A96A] bg-[#14202B] shadow-2xl overflow-hidden"
            style={{
              width: `${Math.min(100, 56 + heroExpand * 44)}vw`,
              height: `${Math.min(68, 44 + heroExpand * 24)}vh`,
              maxWidth: heroExpand > 0.85 ? '100vw' : '1160px',
            }}
          >
            {/* Inner Champagne Hairline Frame */}
            <div className="pointer-events-none absolute inset-3 border border-[#C9A96A]/35 z-20" />

            {/* Live 3D Watch Turntable driven by Scroll */}
            <div className="w-full h-full">
              <TurntableWatchMini
                config={watchConfig}
                targetRotation={heroWatchRotation}
                targetCameraPos={[0, 0.1, 4.9 - heroExpand * 0.65]}
                scale={heroWatchScale}
              />
            </div>

            {/* Corner Archival Captions inside the expanding frame */}
            <div className="pointer-events-none absolute bottom-5 left-6 z-20 hidden sm:block text-left">
              <span className="block text-[10px] tracking-[0.24em] uppercase text-[#C9A96A]">
                THE ALDERVANE HERITAGE S1
              </span>
              <span className="font-display text-lg text-[#F4EFE6]">
                Calibre AV-01 • Mechanical & Sapphire Biometric Chronometer
              </span>
            </div>

            <div className="absolute bottom-5 right-6 z-20 flex items-center gap-3">
              <button
                type="button"
                onClick={() => scrollToSection('atelier-viewer')}
                className="wax-seal-btn px-5 py-2.5 text-[10px] uppercase tracking-[0.22em] text-[#F4EFE6] border border-[#C9A96A]/65 cursor-pointer"
              >
                Enter 3D Observatory →
              </button>
            </div>
          </div>

          {/* Bottom Scroll Prompt */}
          <div className="relative z-20 mt-5 flex items-center gap-4 text-[10px] tracking-[0.24em] uppercase text-[#C9A96A]">
            <span>Scroll to Expand the Salon Aperture</span>
            <span>({Math.round(heroExpand * 100)}%)</span>
          </div>
        </div>
      </section>

      {/* =========================================================
          4. BRAND MANIFESTO (WORD-BY-WORD SCROLL HIGHLIGHT)
         ========================================================= */}
      <section
        ref={manifestoRef}
        className="py-28 lg:py-40 px-6 md:px-12 max-w-[1180px] mx-auto"
      >
        <div className="flex flex-col items-center text-center mb-12">
          <OrnamentalDivider roman="II" className="mb-4" />
          <span className="label-eyebrow text-[#C9A96A]">
            LETTER FROM THE SEVENTH GENERATION • GENEVA
          </span>
        </div>

        <p className="font-display text-2xl sm:text-4xl md:text-[2.75rem] leading-[1.32] font-light text-center">
          {manifestoWords.map((word, index) => {
            const wordThreshold = index / manifestoWords.length;
            const isLit = manifestoProgress >= wordThreshold;
            return (
              <span
                key={index}
                className="inline-block mr-[0.28em] transition-opacity duration-300"
                style={{
                  opacity: isLit ? 1 : 0.24,
                  color:
                    word === 'whispers.' || word === 'gold,' || word === 'enamel,'
                      ? '#C9A96A'
                      : undefined,
                }}
              >
                {word}
              </span>
            );
          })}
        </p>

        <div className="mt-14 flex flex-col items-center justify-center text-center">
          <div className="font-display italic text-2xl text-[#C9A96A]">
            Henri-Laurent Aldervane
          </div>
          <div className="text-[11px] uppercase tracking-[0.24em] opacity-65 mt-1">
            Master Cabinotier • 14 Quai des Bergues
          </div>
        </div>
      </section>

      {/* =========================================================
          5. HEADLINE FEATURE: REAL-TIME WEBGL / THREE.JS 3D VIEWER
         ========================================================= */}
      <AtelierWatchViewer
        config={watchConfig}
        onChangeConfig={setWatchConfig}
        isEveningMode={isEveningMode}
      />

      {/* =========================================================
          6. PINNED 3D STORYTELLING (CAMERA-SYNCED CHAPTERS)
         ========================================================= */}
      <section className="relative py-24 lg:py-36 px-6 md:px-12 max-w-[1440px] mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <OrnamentalDivider roman="IV" className="mb-4" />
          <p className="label-eyebrow text-[#C9A96A] mb-3">
            ANATOMY OF RESTRAINT • FOUR HOROLOGICAL CHAPTERS
          </p>
          <h2 className="heading-section">
            A dialogue between 1794 and tomorrow.
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Pinned 3D Watch Stage that moves camera to Crown, Dial, Bezel, Caseback */}
          <div className="lg:col-span-6 lg:sticky lg:top-28 border border-[#C9A96A]/40 bg-[#14202B] text-[#F4EFE6] p-6 sm:p-8">
            <div className="flex items-center justify-between border-b border-[#C9A96A]/25 pb-3 mb-4">
              <span className="label-eyebrow text-[#C9A96A]">
                CHAPTER {activeChapterObj.roman} • {activeChapterObj.eyebrow}
              </span>
              <span className="font-display text-base text-[#F4EFE6]/80">
                {activeChapterObj.metricValue}
              </span>
            </div>

            <div className="h-[380px] sm:h-[440px] w-full relative">
              <TurntableWatchMini
                config={watchConfig}
                targetRotation={activeChapterObj.watchRot}
                targetCameraPos={activeChapterObj.cameraPos}
                scale={1.08}
              />
            </div>

            {/* Chapter Quick Selector Pills */}
            <div className="pt-4 border-t border-[#C9A96A]/25 flex items-center justify-between gap-2">
              {PINNED_CHAPTERS.map((chap, idx) => (
                <button
                  key={chap.roman}
                  type="button"
                  onClick={() => {
                    soundEngine.playCrownClick(1.05);
                    setActiveStoryChapter(idx);
                    chapterRefs.current[idx]?.scrollIntoView({
                      behavior: 'smooth',
                      block: 'center',
                    });
                  }}
                  className={`flex-1 py-2 border text-[10px] uppercase tracking-[0.2em] transition-colors cursor-pointer ${
                    activeStoryChapter === idx
                      ? 'border-[#C9A96A] bg-[#C9A96A] text-[#14202B] font-medium'
                      : 'border-[#C9A96A]/30 text-[#F4EFE6]/70 hover:border-[#C9A96A]'
                  }`}
                >
                  Ch. {chap.roman}
                </button>
              ))}
            </div>
          </div>

          {/* Scrolling Literary Chapters */}
          <div className="lg:col-span-6 space-y-24 lg:py-12">
            {PINNED_CHAPTERS.map((chap, index) => {
              const isCurrent = activeStoryChapter === index;
              return (
                <div
                  key={chap.roman}
                  ref={(el) => {
                    chapterRefs.current[index] = el;
                  }}
                  onClick={() => setActiveStoryChapter(index)}
                  className={`p-8 sm:p-10 border transition-all duration-700 cursor-pointer ${
                    isCurrent
                      ? 'border-[#C9A96A] bg-[var(--card-surface)] shadow-xl'
                      : 'border-[#C9A96A]/25 opacity-60 hover:opacity-90'
                  }`}
                >
                  <div className="flex items-center gap-3 text-[#C9A96A] mb-3">
                    <span className="font-display text-2xl">{chap.roman}.</span>
                    <span className="label-eyebrow">{chap.eyebrow}</span>
                  </div>
                  <h3 className="heading-chapter mb-4">{chap.title}</h3>
                  <p className="text-base leading-relaxed opacity-80 font-light mb-6">
                    {chap.body}
                  </p>
                  <div className="pt-4 border-t border-[#C9A96A]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <span className="italic font-display text-base text-[#C9A96A]">
                      {chap.footnote}
                    </span>
                    <span className="uppercase tracking-[0.18em] opacity-70">
                      {chap.metricLabel}: {chap.metricValue}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          7. COMPLICATIONS (EXPANDING HORIZONTAL CARDS)
         ========================================================= */}
      <ComplicationsSection
        activeComplication={watchConfig.complicationId}
        onSelectComplication={(complicationId) =>
          setWatchConfig((prev) => ({ ...prev, complicationId }))
        }
      />

      {/* =========================================================
          8. MATERIALS, CRAFTSMANSHIP, GEAR TRAIN & WRIST PRESENCE
         ========================================================= */}
      <CraftsmanshipSection />

      {/* =========================================================
          9. HERITAGE TIMELINE (1794 -> TODAY HORIZONTAL SCROLL)
         ========================================================= */}
      <HeritageTimeline />

      {/* =========================================================
          10. LIVE DIAL CONFIGURATOR & CASEBACK ENGRAVING
         ========================================================= */}
      <ConfiguratorSection
        config={watchConfig}
        onChangeConfig={setWatchConfig}
        onProceedToViewing={() => scrollToSection('private-viewing')}
      />

      {/* =========================================================
          11–14. SPECIFICATIONS, PRESS, PRIVATE VIEWING & FOOTER
         ========================================================= */}
      <SpecsAndPressSection config={watchConfig} />
    </div>
  );
}

export default App;
