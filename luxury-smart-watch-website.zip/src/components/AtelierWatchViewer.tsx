import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { createProceduralWatch, WatchRig } from '../three/WatchBuilder';
import {
  CASE_OPTIONS,
  BEZEL_OPTIONS,
  DIAL_OPTIONS,
  STRAP_OPTIONS,
  COMPLICATIONS,
  WATCH_HOTSPOTS,
  HotspotInfo,
  WatchConfig,
} from '../data/aldervaneData';
import { soundEngine } from '../utils/soundEngine';

interface AtelierWatchViewerProps {
  config: WatchConfig;
  onChangeConfig: (updater: (prev: WatchConfig) => WatchConfig) => void;
  isEveningMode: boolean;
}

interface ProjectedHotspot {
  id: string;
  x: number;
  y: number;
  visible: boolean;
}

const EXPLODED_STRATA_LABELS = [
  { roman: 'I', name: 'Box-Domed Sapphire Crystal', detail: 'IOR 1.77 • 7-Layer Internal AR', yPct: 16 },
  { roman: 'II', name: 'Sintered Ceramic Bezel & Breguet Hands', detail: '120-Flute Gold Ring • Real-Time Sweep', yPct: 29 },
  { roman: 'III', name: 'Grand Feu Enamel & E-Ink Aperture', detail: 'Hand-Guilloché Clous de Paris', yPct: 43 },
  { roman: 'IV', name: '904L Case & Hand-Stitched Strap', detail: 'Mirror-Beveled Lugs • 10 ATM', yPct: 57 },
  { roman: 'V', name: 'Manufacture Calibre AV-01 & Reserve Cell', detail: '28,800 vph Free-Sprung • 14-Day Autonomy', yPct: 71 },
  { roman: 'VI', name: 'Engraved Sapphire Exhibition Caseback', detail: 'Flush Optical Pulse Interferometer', yPct: 84 },
];

export const AtelierWatchViewer: React.FC<AtelierWatchViewerProps> = ({
  config,
  onChangeConfig,
  isEveningMode,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const watchRigRef = useRef<WatchRig | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const keyLightRef = useRef<THREE.SpotLight | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const rimLightRef = useRef<THREE.DirectionalLight | null>(null);

  const [webglSupported, setWebglSupported] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const [lightAngle, setLightAngle] = useState(42);
  const [isExploded, setIsExploded] = useState(false);
  const [isMacroMode, setIsMacroMode] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<HotspotInfo | null>(null);
  const [projectedHotspots, setProjectedHotspots] = useState<ProjectedHotspot[]>([]);
  const [loupePos, setLoupePos] = useState<{ x: number; y: number; active: boolean }>({
    x: 50,
    y: 50,
    active: false,
  });
  const [currentTimeStr, setCurrentTimeStr] = useState('');

  // Target camera animation refs
  const desiredCamPos = useRef<THREE.Vector3 | null>(null);
  const desiredTarget = useRef<THREE.Vector3 | null>(null);
  const explodeTargetRef = useRef(0);

  useEffect(() => {
    explodeTargetRef.current = isExploded ? 1 : 0;
    if (isExploded) {
      // Angle camera slightly sideways to admire the separated horological strata
      desiredCamPos.current = new THREE.Vector3(3.8, 1.4, 3.6);
      desiredTarget.current = new THREE.Vector3(0, 0, 0);
    }
  }, [isExploded]);

  useEffect(() => {
    if (isMacroMode) {
      desiredCamPos.current = new THREE.Vector3(0.35, -0.35, 2.55);
      desiredTarget.current = new THREE.Vector3(0.0, -0.25, 0.2);
    } else if (!activeHotspot && !isExploded) {
      desiredCamPos.current = new THREE.Vector3(0.0, 0.15, 5.1);
      desiredTarget.current = new THREE.Vector3(0, 0, 0);
    }
  }, [isMacroMode, activeHotspot, isExploded]);

  // Live digital reference clock to confirm real-time sync
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
    };
    updateClock();
    const timer = window.setInterval(updateClock, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Sync config updates into Three.js procedural rig
  useEffect(() => {
    if (watchRigRef.current) {
      watchRigRef.current.updateConfig(config);
    }
  }, [config]);

  // Sync Light Study slider angle
  useEffect(() => {
    if (!keyLightRef.current) return;
    const rad = (lightAngle * Math.PI) / 180;
    const radius = 6.5;
    keyLightRef.current.position.set(
      Math.cos(rad) * radius,
      2.6 + Math.sin(rad * 2) * 0.8,
      Math.sin(rad) * radius
    );
  }, [lightAngle]);

  // Sync Day / Evening mode lighting temperature
  useEffect(() => {
    if (!keyLightRef.current || !ambientLightRef.current || !rimLightRef.current) return;
    if (isEveningMode) {
      keyLightRef.current.color.set('#FFD89B'); // Warm candlelit tungsten
      keyLightRef.current.intensity = 42;
      ambientLightRef.current.color.set('#243447');
      rimLightRef.current.color.set('#C9A96A');
    } else {
      keyLightRef.current.color.set('#FFF9EE'); // Crisp Geneva morning light
      keyLightRef.current.intensity = 52;
      ambientLightRef.current.color.set('#F4EFE6');
      rimLightRef.current.color.set('#E6D2B5');
    }
  }, [isEveningMode]);

  // Initialize Three.js WebGL Scene
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglSupported(false);
      return;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();

    // Studio HDR Environment via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;

    const camera = new THREE.PerspectiveCamera(
      36,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0.0, 0.15, 5.1);
    cameraRef.current = camera;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 2.1;
    controls.maxDistance = 8.2;
    controls.maxPolarAngle = Math.PI * 0.85;
    controls.minPolarAngle = Math.PI * 0.15;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.45;
    controlsRef.current = controls;

    let idleTimeout: number | null = null;
    const onControlStart = () => {
      controls.autoRotate = false;
      desiredCamPos.current = null;
      desiredTarget.current = null;
      if (idleTimeout) window.clearTimeout(idleTimeout);
    };
    const onControlEnd = () => {
      if (idleTimeout) window.clearTimeout(idleTimeout);
      idleTimeout = window.setTimeout(() => {
        if (!activeHotspot && !isMacroMode) {
          controls.autoRotate = true;
        }
      }, 4500);
    };
    controls.addEventListener('start', onControlStart);
    controls.addEventListener('end', onControlEnd);

    // Three-point Studio Lighting + Rotatable Key Light
    const ambientLight = new THREE.AmbientLight('#F4EFE6', 0.65);
    scene.add(ambientLight);
    ambientLightRef.current = ambientLight;

    const keyLight = new THREE.SpotLight('#FFF9EE', 52);
    keyLight.position.set(4.5, 3.2, 4.5);
    keyLight.angle = Math.PI / 3;
    keyLight.penumbra = 0.85;
    scene.add(keyLight);
    keyLightRef.current = keyLight;

    const fillLight = new THREE.DirectionalLight('#D6E0E8', 1.4);
    fillLight.position.set(-5, -2, 3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight('#C9A96A', 2.2);
    rimLight.position.set(0, 5, -5);
    scene.add(rimLight);
    rimLightRef.current = rimLight;

    // Subtle Horological Exhibition Plinth Shadow Ring beneath watch
    const plinthGeo = new THREE.RingGeometry(2.35, 2.38, 96);
    const plinthMat = new THREE.MeshBasicMaterial({
      color: '#C9A96A',
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.25,
    });
    const plinthRing = new THREE.Mesh(plinthGeo, plinthMat);
    plinthRing.rotation.x = Math.PI / 2;
    plinthRing.position.y = -3.65;
    scene.add(plinthRing);

    // Build Procedural Watch
    const watchRig = createProceduralWatch(config);
    watchRig.root.rotation.set(0.12, -0.28, 0.0);
    scene.add(watchRig.root);
    watchRigRef.current = watchRig;

    setIsLoaded(true);

    // Pause rendering when off-screen for 60fps efficiency
    let isVisible = true;
    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
      },
      { threshold: 0.05 }
    );
    observer.observe(container);

    const clock = new THREE.Clock();
    let currentExplode = 0;
    let rafId = 0;
    let frameCounter = 0;

    const animate = () => {
      rafId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const elapsed = clock.getElapsedTime();
      currentExplode = THREE.MathUtils.lerp(currentExplode, explodeTargetRef.current, 0.08);
      watchRig.updateClockAndPhysics(elapsed, currentExplode);

      // Smooth camera fly-to transitions
      if (desiredCamPos.current && desiredTarget.current) {
        camera.position.lerp(desiredCamPos.current, 0.075);
        controls.target.lerp(desiredTarget.current, 0.085);
        if (camera.position.distanceTo(desiredCamPos.current) < 0.04) {
          desiredCamPos.current = null;
          desiredTarget.current = null;
        }
      }

      controls.update();
      renderer.render(scene, camera);

      // Project 3D Hotspot Coordinates every 2 frames
      frameCounter++;
      if (frameCounter % 2 === 0 && container) {
        const width = container.clientWidth;
        const height = container.clientHeight;
        const nextProj: ProjectedHotspot[] = WATCH_HOTSPOTS.map((h) => {
          const worldVec = new THREE.Vector3(...h.position);
          worldVec.applyMatrix4(watchRig.root.matrixWorld);
          const projected = worldVec.clone().project(camera);
          const x = (projected.x * 0.5 + 0.5) * width;
          const y = (-(projected.y * 0.5) + 0.5) * height;
          const camDir = new THREE.Vector3().subVectors(camera.position, worldVec).normalize();
          const normal = worldVec.clone().normalize();
          const facing = normal.dot(camDir) > -0.25;
          return {
            id: h.id,
            x,
            y,
            visible: facing && projected.z < 1,
          };
        });
        setProjectedHotspots(nextProj);
      }
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      controls.dispose();
      watchRig.dispose();
      envTexture.dispose();
      pmremGenerator.dispose();
      renderer.dispose();
    };
  }, []);

  const handleSelectHotspot = (hotspot: HotspotInfo) => {
    soundEngine.playCrownClick(1.15);
    if (activeHotspot?.id === hotspot.id) {
      setActiveHotspot(null);
      desiredCamPos.current = new THREE.Vector3(0, 0.15, 5.1);
      desiredTarget.current = new THREE.Vector3(0, 0, 0);
      if (controlsRef.current) controlsRef.current.autoRotate = true;
      return;
    }
    setIsExploded(false);
    setIsMacroMode(false);
    setActiveHotspot(hotspot);
    if (controlsRef.current) controlsRef.current.autoRotate = false;
    if (watchRigRef.current) {
      watchRigRef.current.root.rotation.set(0, 0, 0);
    }
    desiredCamPos.current = new THREE.Vector3(...hotspot.cameraPos);
    desiredTarget.current = new THREE.Vector3(...hotspot.cameraTarget);
  };

  const handleResetView = () => {
    soundEngine.playCrownClick(0.95);
    setActiveHotspot(null);
    setIsExploded(false);
    setIsMacroMode(false);
    if (watchRigRef.current) {
      watchRigRef.current.root.rotation.set(0.12, -0.28, 0.0);
    }
    desiredCamPos.current = new THREE.Vector3(0, 0.15, 5.1);
    desiredTarget.current = new THREE.Vector3(0, 0, 0);
    if (controlsRef.current) {
      controlsRef.current.autoRotate = true;
    }
  };

  const handlePresetAngle = (pos: [number, number, number], target: [number, number, number]) => {
    soundEngine.playCrownClick(1.05);
    setActiveHotspot(null);
    if (controlsRef.current) controlsRef.current.autoRotate = false;
    if (watchRigRef.current) watchRigRef.current.root.rotation.set(0, 0, 0);
    desiredCamPos.current = new THREE.Vector3(...pos);
    desiredTarget.current = new THREE.Vector3(...target);
  };

  return (
    <section
      id="atelier-viewer"
      aria-label="Interactive 3D Horological Observatory"
      className="relative w-full min-h-screen bg-[#14202B] text-[#F4EFE6] py-16 lg:py-24 overflow-hidden border-y border-[#C9A96A]/30"
    >
      {/* Subtle Radial Studio Spotlight Backdrop */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 46%, rgba(31, 58, 50, 0.55) 0%, rgba(20, 32, 43, 0.92) 58%, #0E1720 100%)',
        }}
      />

      <div className="relative z-10 max-w-[1440px] mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#C9A96A]/25">
          <div>
            <div className="flex items-center gap-3 text-[#C9A96A] mb-2">
              <span className="font-display text-sm tracking-[0.28em]">III</span>
              <span className="w-8 h-[1px] bg-[#C9A96A]/50" />
              <span className="label-eyebrow text-[#C9A96A]">
                L’OBSERVATOIRE HORLOGER • INTERACTIVE 3D CALIBRE
              </span>
            </div>
            <h2 className="heading-section text-[#F4EFE6]">
              The Heritage S1, Examined in the Round.
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs tracking-[0.18em] uppercase text-[#F4EFE6]/75">
            <div className="px-3.5 py-2 border border-[#C9A96A]/30 bg-[#1A2936]/70 flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-[#C9A96A] animate-pulse" />
              <span>REAL-TIME SWEEP: {currentTimeStr}</span>
            </div>
            <button
              type="button"
              onClick={handleResetView}
              className="px-4 py-2 border border-[#C9A96A]/45 text-[#C9A96A] hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors duration-500 cursor-pointer"
            >
              Reset Observatory View
            </button>
          </div>
        </div>

        {/* Main 3D Stage + Telemetry Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-8 items-start">
          {/* Left Column: Camera Angles, Light Study & Inspection Modes */}
          <div className="lg:col-span-3 space-y-6 order-2 lg:order-1">
            {/* Light Study Control */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="label-eyebrow text-[#C9A96A]">01 • Light Study Rig</span>
                <span className="font-display text-lg text-[#F4EFE6]">{lightAngle}° Azimuth</span>
              </div>
              <p className="text-xs text-[#F4EFE6]/65 leading-relaxed mb-4">
                Sweep the key studio lamp across the 904L satin lugs, ceramic bezel, and domed sapphire crystal.
              </p>
              <input
                type="range"
                min={0}
                max={360}
                value={lightAngle}
                aria-label="Key light azimuth angle"
                onChange={(e) => {
                  setLightAngle(Number(e.target.value));
                }}
                className="w-full aldervane-slider"
              />
              <div className="flex justify-between text-[10px] tracking-[0.2em] uppercase text-[#C9A96A]/70 mt-2">
                <span>Dawn 0°</span>
                <span>Zenith 180°</span>
                <span>Dusk 360°</span>
              </div>
            </div>

            {/* Horological Inspection Modes */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm space-y-3">
              <span className="label-eyebrow text-[#C9A96A] block mb-1">
                02 • Horological Dissection
              </span>

              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.2);
                  setActiveHotspot(null);
                  setIsMacroMode(false);
                  setIsExploded((prev) => !prev);
                }}
                aria-pressed={isExploded}
                className={`w-full py-3 px-4 border text-left flex items-center justify-between transition-all duration-500 cursor-pointer ${
                  isExploded
                    ? 'border-[#C9A96A] bg-[#C9A96A]/20 text-[#F4EFE6]'
                    : 'border-[#C9A96A]/30 text-[#F4EFE6]/80 hover:border-[#C9A96A]/70'
                }`}
              >
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] font-medium">
                    Exploded Calibre View
                  </div>
                  <div className="text-[11px] text-[#F4EFE6]/60 mt-0.5">
                    Separate 6 horological strata along Z-axis
                  </div>
                </div>
                <span className="font-display text-lg text-[#C9A96A]">
                  {isExploded ? 'Active' : 'Inspect'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.1);
                  setActiveHotspot(null);
                  setIsExploded(false);
                  setIsMacroMode((prev) => !prev);
                }}
                aria-pressed={isMacroMode}
                className={`w-full py-3 px-4 border text-left flex items-center justify-between transition-all duration-500 cursor-pointer ${
                  isMacroMode
                    ? 'border-[#C9A96A] bg-[#C9A96A]/20 text-[#F4EFE6]'
                    : 'border-[#C9A96A]/30 text-[#F4EFE6]/80 hover:border-[#C9A96A]/70'
                }`}
              >
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] font-medium">
                    10× Jeweler’s Loupe Mode
                  </div>
                  <div className="text-[11px] text-[#F4EFE6]/60 mt-0.5">
                    Macro surface finishing & guilloché inspection
                  </div>
                </div>
                <span className="font-display text-lg text-[#C9A96A]">
                  {isMacroMode ? 'Active' : 'Magnify'}
                </span>
              </button>

              {/* Camera Presets */}
              <div className="pt-2 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handlePresetAngle([0, 0.1, 4.8], [0, 0, 0])}
                  className="py-2 px-2 border border-[#C9A96A]/25 text-[10px] uppercase tracking-[0.18em] text-[#F4EFE6]/80 hover:border-[#C9A96A] cursor-pointer"
                >
                  Dial Face
                </button>
                <button
                  type="button"
                  onClick={() => handlePresetAngle([4.4, 0.6, 2.2], [0.5, 0, 0])}
                  className="py-2 px-2 border border-[#C9A96A]/25 text-[10px] uppercase tracking-[0.18em] text-[#F4EFE6]/80 hover:border-[#C9A96A] cursor-pointer"
                >
                  Crown Side
                </button>
                <button
                  type="button"
                  onClick={() => handlePresetAngle([0.2, 0.3, -4.9], [0, 0, 0])}
                  className="py-2 px-2 border border-[#C9A96A]/25 text-[10px] uppercase tracking-[0.18em] text-[#F4EFE6]/80 hover:border-[#C9A96A] cursor-pointer"
                >
                  Caseback
                </button>
              </div>
            </div>

            {/* Hotspot Index List */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <span className="label-eyebrow text-[#C9A96A] block mb-3">
                03 • Architectural Annotations
              </span>
              <div className="space-y-2">
                {WATCH_HOTSPOTS.map((spot) => {
                  const isSelected = activeHotspot?.id === spot.id;
                  return (
                    <button
                      key={spot.id}
                      type="button"
                      onClick={() => handleSelectHotspot(spot)}
                      className={`w-full text-left px-3 py-2.5 border transition-all duration-400 flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'border-[#C9A96A] bg-[#C9A96A]/15 text-[#F4EFE6]'
                          : 'border-transparent hover:border-[#C9A96A]/35 text-[#F4EFE6]/75'
                      }`}
                    >
                      <span className="text-xs tracking-[0.12em]">{spot.title}</span>
                      <span className="font-display text-sm text-[#C9A96A]">{spot.number}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Center Column: Interactive Three.js WebGL Stage */}
          <div className="lg:col-span-6 order-1 lg:order-2 relative">
            <div
              className="relative w-full h-[500px] sm:h-[600px] lg:h-[660px] border border-[#C9A96A]/30 bg-gradient-to-b from-[#182936]/55 via-[#111C26]/75 to-[#0D161E]/90 overflow-hidden"
              onMouseMove={(e) => {
                if (!isMacroMode) return;
                const rect = e.currentTarget.getBoundingClientRect();
                setLoupePos({
                  x: ((e.clientX - rect.left) / rect.width) * 100,
                  y: ((e.clientY - rect.top) / rect.height) * 100,
                  active: true,
                });
              }}
              onMouseLeave={() => setLoupePos((p) => ({ ...p, active: false }))}
            >
              {/* Ornamental Corner Filigrees */}
              <div className="pointer-events-none absolute top-3 left-3 w-5 h-5 border-t border-l border-[#C9A96A]/60" />
              <div className="pointer-events-none absolute top-3 right-3 w-5 h-5 border-t border-r border-[#C9A96A]/60" />
              <div className="pointer-events-none absolute bottom-3 left-3 w-5 h-5 border-b border-l border-[#C9A96A]/60" />
              <div className="pointer-events-none absolute bottom-3 right-3 w-5 h-5 border-b border-r border-[#C9A96A]/60" />

              {webglSupported ? (
                <div
                  ref={containerRef}
                  className="w-full h-full cursor-grab active:cursor-grabbing"
                  role="img"
                  aria-label="Interactive 3D model of The Aldervane Heritage S1 smart chronometer. Drag to rotate, scroll to zoom."
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                  <p className="font-display text-2xl text-[#C9A96A] mb-2">
                    Archival Plate Viewing Mode
                  </p>
                  <p className="text-sm text-[#F4EFE6]/75 max-w-md">
                    WebGL hardware acceleration is unavailable on this terminal. Please enable WebGL to inspect the real-time 3D Calibre AV-01.
                  </p>
                </div>
              )}

              {!isLoaded && webglSupported && (
                <div className=" inset-0 absolute flex flex-col items-center justify-center bg-[#14202B]/90 z-20">
                  <div className="w-16 h-[1px] bg-[#C9A96A] animate-pulse mb-3" />
                  <span className="label-eyebrow text-[#C9A96A]">
                    Assembling Calibre AV-01 Geometry…
                  </span>
                </div>
              )}

              {/* 3D Projected Hotspot Dots */}
              {!isExploded &&
                !isMacroMode &&
                projectedHotspots.map((proj) => {
                  const spotData = WATCH_HOTSPOTS.find((h) => h.id === proj.id);
                  if (!spotData || !proj.visible) return null;
                  const isSelected = activeHotspot?.id === spotData.id;
                  return (
                    <button
                      key={spotData.id}
                      type="button"
                      onClick={() => handleSelectHotspot(spotData)}
                      style={{
                        left: `${proj.x}px`,
                        top: `${proj.y}px`,
                      }}
                      aria-label={`Inspect ${spotData.title}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group cursor-pointer focus:outline-none"
                    >
                      <span className="relative flex items-center justify-center w-7 h-7">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C9A96A] opacity-55" />
                        <span
                          className={`relative inline-flex items-center justify-center w-6 h-6 rounded-full border text-[10px] font-medium transition-transform duration-300 group-hover:scale-125 ${
                            isSelected
                              ? 'bg-[#C9A96A] text-[#14202B] border-[#F4EFE6]'
                              : 'bg-[#14202B]/90 text-[#C9A96A] border-[#C9A96A]'
                          }`}
                        >
                          {spotData.number}
                        </span>
                      </span>
                    </button>
                  );
                })}

              {/* Exploded View Horological Leader Lines Overlay */}
              {isExploded && (
                <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between py-10 px-6">
                  {EXPLODED_STRATA_LABELS.map((layer, index) => (
                    <div
                      key={layer.roman}
                      className={`flex items-center gap-3 ${
                        index % 2 === 0 ? 'justify-start' : 'justify-end'
                      }`}
                    >
                      {index % 2 === 0 ? (
                        <>
                          <div className="bg-[#0E1720]/90 border border-[#C9A96A]/50 px-3 py-1.5 backdrop-blur-sm max-w-[230px]">
                            <div className="text-[10px] tracking-[0.2em] text-[#C9A96A] uppercase">
                              Stratum {layer.roman}
                            </div>
                            <div className="font-display text-sm text-[#F4EFE6]">{layer.name}</div>
                            <div className="text-[10px] text-[#F4EFE6]/60">{layer.detail}</div>
                          </div>
                          <div className="w-12 sm:w-20 h-[1px] bg-[#C9A96A]/70 relative">
                            <span className="absolute right-0 -top-1 w-2 h-2 rounded-full bg-[#C9A96A]" />
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="w-12 sm:w-20 h-[1px] bg-[#C9A96A]/70 relative">
                            <span className="absolute left-0 -top-1 w-2 h-2 rounded-full bg-[#C9A96A]" />
                          </div>
                          <div className="bg-[#0E1720]/90 border border-[#C9A96A]/50 px-3 py-1.5 backdrop-blur-sm text-right max-w-[230px]">
                            <div className="text-[10px] tracking-[0.2em] text-[#C9A96A] uppercase">
                              Stratum {layer.roman}
                            </div>
                            <div className="font-display text-sm text-[#F4EFE6]">{layer.name}</div>
                            <div className="text-[10px] text-[#F4EFE6]/60">{layer.detail}</div>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Macro Jeweler's Loupe Reticle Overlay */}
              {isMacroMode && (
                <div
                  className="pointer-events-none absolute z-20 w-48 h-48 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#C9A96A] shadow-[0_0_50px_rgba(0,0,0,0.85)] flex flex-col items-center justify-between p-3 transition-opacity duration-300"
                  style={{
                    left: `${loupePos.x}%`,
                    top: `${loupePos.y}%`,
                    opacity: loupePos.active ? 1 : 0.75,
                    background:
                      'radial-gradient(circle, rgba(201,169,106,0.08) 0%, rgba(20,32,43,0.45) 100%)',
                  }}
                >
                  <span className="text-[9px] tracking-[0.22em] uppercase text-[#C9A96A] bg-[#0E1720]/85 px-2 py-0.5">
                    LOUPE 10× • ANGLAGE
                  </span>
                  <div className="w-4 h-4 relative">
                    <span className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-[#C9A96A]/70" />
                    <span className="absolute top-1/2 left-0 right-0 h-[1px] bg-[#C9A96A]/70" />
                  </div>
                  <span className="text-[9px] tracking-[0.18em] text-[#F4EFE6] bg-[#0E1720]/85 px-2 py-0.5">
                    Ra 0.02 μm • Genève
                  </span>
                </div>
              )}

              {/* Active Hotspot Caption Card */}
              {activeHotspot && (
                <div className="absolute bottom-5 left-5 right-5 sm:left-6 sm:right-auto sm:max-w-md z-30 bg-[#0E1720]/95 border border-[#C9A96A] p-5 backdrop-blur-md shadow-2xl">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="label-eyebrow text-[#C9A96A]">
                      ANNOTATION {activeHotspot.number} • {activeHotspot.subtitle}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveHotspot(null)}
                      className="text-xs text-[#C9A96A] hover:underline uppercase tracking-widest cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                  <h3 className="font-display text-2xl text-[#F4EFE6] mb-2">
                    {activeHotspot.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#F4EFE6]/80 leading-relaxed">
                    {activeHotspot.description}
                  </p>
                </div>
              )}

              {/* Bottom Stage Helper Bar */}
              <div className="pointer-events-none absolute bottom-3 right-4 z-10 hidden sm:flex items-center gap-3 text-[10px] tracking-[0.2em] uppercase text-[#C9A96A]/80">
                <span>Drag to Orbit</span>
                <span>•</span>
                <span>Scroll to Zoom</span>
                <span>•</span>
                <span>Click Nodes to Inspect</span>
              </div>
            </div>
          </div>

          {/* Right Column: Live Habillage & Material Swatches */}
          <div className="lg:col-span-3 space-y-5 order-3">
            {/* Case Material */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="label-eyebrow text-[#C9A96A]">Case Metallurgy</span>
                <span className="text-xs text-[#F4EFE6]/70">
                  {CASE_OPTIONS[config.caseId].name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {(Object.keys(CASE_OPTIONS) as Array<WatchConfig['caseId']>).map((key) => {
                  const opt = CASE_OPTIONS[key];
                  const active = config.caseId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.0);
                        onChangeConfig((prev) => ({ ...prev, caseId: key }));
                      }}
                      className={`p-2.5 border text-left transition-all cursor-pointer ${
                        active
                          ? 'border-[#C9A96A] bg-[#C9A96A]/15'
                          : 'border-[#C9A96A]/25 hover:border-[#C9A96A]/60'
                      }`}
                    >
                      <span
                        className="block w-5 h-5 rounded-full border border-white/30 mb-2"
                        style={{ backgroundColor: opt.colorHex }}
                      />
                      <span className="block text-[11px] font-medium text-[#F4EFE6] leading-tight">
                        {opt.name.split(' ')[1]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bezel Ceramic */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="label-eyebrow text-[#C9A96A]">Ceramic Bezel</span>
                <span className="text-xs text-[#F4EFE6]/70">
                  {BEZEL_OPTIONS[config.bezelId].name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {(Object.keys(BEZEL_OPTIONS) as Array<WatchConfig['bezelId']>).map((key) => {
                  const opt = BEZEL_OPTIONS[key];
                  const active = config.bezelId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.08);
                        onChangeConfig((prev) => ({ ...prev, bezelId: key }));
                      }}
                      className={`p-2.5 border text-left transition-all cursor-pointer ${
                        active
                          ? 'border-[#C9A96A] bg-[#C9A96A]/15'
                          : 'border-[#C9A96A]/25 hover:border-[#C9A96A]/60'
                      }`}
                    >
                      <span
                        className="block w-5 h-5 rounded-full border border-[#C9A96A]/50 mb-2"
                        style={{ backgroundColor: opt.colorHex }}
                      />
                      <span className="block text-[11px] font-medium text-[#F4EFE6] capitalize">
                        {key}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Grand Feu Enamel Dial */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="label-eyebrow text-[#C9A96A]">Grand Feu Dial</span>
                <span className="text-xs text-[#F4EFE6]/70">
                  {DIAL_OPTIONS[config.dialId].name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {(Object.keys(DIAL_OPTIONS) as Array<WatchConfig['dialId']>).map((key) => {
                  const opt = DIAL_OPTIONS[key];
                  const active = config.dialId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.12);
                        onChangeConfig((prev) => ({ ...prev, dialId: key }));
                      }}
                      className={`p-2.5 border text-left transition-all cursor-pointer ${
                        active
                          ? 'border-[#C9A96A] bg-[#C9A96A]/15'
                          : 'border-[#C9A96A]/25 hover:border-[#C9A96A]/60'
                      }`}
                    >
                      <span
                        className="block w-5 h-5 rounded-full border border-[#C9A96A]/50 mb-2"
                        style={{ backgroundColor: opt.colorHex }}
                      />
                      <span className="block text-[11px] font-medium text-[#F4EFE6] capitalize">
                        {key}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Leather & Alligator Habillage */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="label-eyebrow text-[#C9A96A]">Artisanal Strap</span>
                <span className="text-xs text-[#F4EFE6]/70">
                  {STRAP_OPTIONS[config.strapId].name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {(Object.keys(STRAP_OPTIONS) as Array<WatchConfig['strapId']>).map((key) => {
                  const opt = STRAP_OPTIONS[key];
                  const active = config.strapId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(0.92);
                        onChangeConfig((prev) => ({ ...prev, strapId: key }));
                      }}
                      className={`p-2.5 border text-left transition-all cursor-pointer ${
                        active
                          ? 'border-[#C9A96A] bg-[#C9A96A]/15'
                          : 'border-[#C9A96A]/25 hover:border-[#C9A96A]/60'
                      }`}
                    >
                      <span
                        className="block w-5 h-5 rounded-full border border-[#C9A96A]/50 mb-2"
                        style={{ backgroundColor: opt.colorHex }}
                      />
                      <span className="block text-[11px] font-medium text-[#F4EFE6] capitalize">
                        {key}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active 6 o'clock Aperture Complication Switcher */}
            <div className="p-5 border border-[#C9A96A]/25 bg-[#0E1720]/75 backdrop-blur-sm">
              <span className="label-eyebrow text-[#C9A96A] block mb-2">
                6 O’Clock Sapphire Aperture
              </span>
              <div className="flex flex-wrap gap-1.5">
                {COMPLICATIONS.map((comp) => {
                  const active = config.complicationId === comp.id;
                  return (
                    <button
                      key={comp.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.22);
                        onChangeConfig((prev) => ({ ...prev, complicationId: comp.id }));
                      }}
                      className={`px-2.5 py-1.5 text-[10px] uppercase tracking-[0.16em] border transition-colors cursor-pointer ${
                        active
                          ? 'border-[#C9A96A] bg-[#C9A96A] text-[#14202B] font-medium'
                          : 'border-[#C9A96A]/30 text-[#F4EFE6]/75 hover:border-[#C9A96A]'
                      }`}
                    >
                      {comp.roman}. {comp.id}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
