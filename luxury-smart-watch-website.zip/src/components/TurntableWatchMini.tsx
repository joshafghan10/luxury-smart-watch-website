import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { createProceduralWatch, WatchRig } from '../three/WatchBuilder';
import { WatchConfig } from '../data/aldervaneData';

interface TurntableWatchMiniProps {
  config: WatchConfig;
  targetRotation: [number, number, number];
  targetCameraPos?: [number, number, number];
  scale?: number;
  explodeAmount?: number;
  className?: string;
}

export const TurntableWatchMini: React.FC<TurntableWatchMiniProps> = ({
  config,
  targetRotation,
  targetCameraPos = [0, 0.1, 4.9],
  scale = 1,
  explodeAmount = 0,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rigRef = useRef<WatchRig | null>(null);
  const rotRef = useRef<[number, number, number]>(targetRotation);
  const camRef = useRef<[number, number, number]>(targetCameraPos);
  const scaleRef = useRef<number>(scale);
  const explodeRef = useRef<number>(explodeAmount);

  useEffect(() => {
    rotRef.current = targetRotation;
  }, [targetRotation]);

  useEffect(() => {
    camRef.current = targetCameraPos;
  }, [targetCameraPos]);

  useEffect(() => {
    scaleRef.current = scale;
  }, [scale]);

  useEffect(() => {
    explodeRef.current = explodeAmount;
  }, [explodeAmount]);

  useEffect(() => {
    if (rigRef.current) {
      rigRef.current.updateConfig(config);
    }
  }, [config]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    const camera = new THREE.PerspectiveCamera(
      36,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(...camRef.current);

    const ambient = new THREE.AmbientLight('#F4EFE6', 0.75);
    scene.add(ambient);

    const keyLight = new THREE.DirectionalLight('#FFF7E8', 3.4);
    keyLight.position.set(4, 5, 5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight('#C9A96A', 2.4);
    rimLight.position.set(-4, -2, -4);
    scene.add(rimLight);

    const rig = createProceduralWatch(config);
    rig.root.rotation.set(...rotRef.current);
    scene.add(rig.root);
    rigRef.current = rig;

    let isVisible = true;
    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
      },
      { threshold: 0.02 }
    );
    observer.observe(container);

    const clock = new THREE.Clock();
    let rafId = 0;

    const animate = () => {
      rafId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const elapsed = clock.getElapsedTime();
      rig.updateClockAndPhysics(elapsed, explodeRef.current);

      // Smoothly interpolate watch rotation, scale, and camera position
      rig.root.rotation.x = THREE.MathUtils.lerp(
        rig.root.rotation.x,
        rotRef.current[0] + Math.sin(elapsed * 0.6) * 0.03,
        0.07
      );
      rig.root.rotation.y = THREE.MathUtils.lerp(
        rig.root.rotation.y,
        rotRef.current[1] + Math.cos(elapsed * 0.5) * 0.04,
        0.07
      );
      rig.root.rotation.z = THREE.MathUtils.lerp(
        rig.root.rotation.z,
        rotRef.current[2],
        0.07
      );

      const s = THREE.MathUtils.lerp(rig.root.scale.x, scaleRef.current, 0.08);
      rig.root.scale.setScalar(s);

      camera.position.x = THREE.MathUtils.lerp(camera.position.x, camRef.current[0], 0.07);
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, camRef.current[1], 0.07);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, camRef.current[2], 0.07);
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      rig.dispose();
      envTex.dispose();
      pmrem.dispose();
      renderer.dispose();
    };
  }, []);

  return <div ref={mountRef} className={`w-full h-full ${className}`} />;
};
