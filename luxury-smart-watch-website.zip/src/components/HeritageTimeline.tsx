import React, { useRef, useState } from 'react';
import { HERITAGE_TIMELINE, TimelineEra } from '../data/aldervaneData';
import { OrnamentalDivider } from './CrestSvg';
import { soundEngine } from '../utils/soundEngine';

const EraIllustration: React.FC<{ type: TimelineEra['illustrationType'] }> = ({ type }) => {
  switch (type) {
    case 'escapement':
      return (
        <svg viewBox="0 0 200 130" className="w-full h-32">
          <circle
            cx="100"
            cy="65"
            r="46"
            fill="none"
            stroke="#C9A96A"
            strokeWidth="1.2"
            strokeDasharray="4 3"
          />
          <circle cx="100" cy="65" r="32" fill="none" stroke="#C9A96A" strokeWidth="0.9" />
          {Array.from({ length: 12 }).map((_, i) => {
            const a = (i / 12) * Math.PI * 2;
            return (
              <line
                key={i}
                x1={100 + Math.cos(a) * 32}
                y1={65 + Math.sin(a) * 32}
                x2={100 + Math.cos(a) * 48}
                y2={65 + Math.sin(a) * 48}
                stroke="#C9A96A"
                strokeWidth="1.1"
              />
            );
          })}
          <path d="M72 65H128M100 37V93" stroke="#C9A96A" strokeWidth="1" />
          <text x="100" y="122" textAnchor="middle" fill="#C9A96A" fontSize="7.5" letterSpacing="2">
            FIG. I • DUPLEX ESCAPEMENT 1794
          </text>
        </svg>
      );
    case 'sextant':
      return (
        <svg viewBox="0 0 200 130" className="w-full h-32">
          <path
            d="M55 95 A 55 55 0 0 1 145 95"
            fill="none"
            stroke="#C9A96A"
            strokeWidth="1.5"
          />
          <line x1="100" y1="22" x2="62" y2="95" stroke="#C9A96A" strokeWidth="1.2" />
          <line x1="100" y1="22" x2="138" y2="95" stroke="#C9A96A" strokeWidth="1.2" />
          <line x1="100" y1="22" x2="112" y2="98" stroke="#DFC690" strokeWidth="1.6" />
          <circle cx="100" cy="22" r="5" fill="#1F3A32" stroke="#C9A96A" strokeWidth="1.4" />
          <text x="100" y="122" textAnchor="middle" fill="#C9A96A" fontSize="7.5" letterSpacing="2">
            FIG. II • GREENWICH MARINE TRIALS
          </text>
        </svg>
      );
    case 'polar':
      return (
        <svg viewBox="0 0 200 130" className="w-full h-32">
          <circle cx="100" cy="60" r="42" fill="none" stroke="#C9A96A" strokeWidth="1.1" />
          <polygon
            points="100,20 107,53 140,60 107,67 100,100 93,67 60,60 93,53"
            fill="rgba(201,169,106,0.18)"
            stroke="#C9A96A"
            strokeWidth="1.2"
          />
          <circle cx="100" cy="60" r="4" fill="#C9A96A" />
          <text x="100" y="122" textAnchor="middle" fill="#C9A96A" fontSize="7.5" letterSpacing="2">
            FIG. III • 78° SOUTH MERIDIAN
          </text>
        </svg>
      );
    case 'manifesto':
      return (
        <svg viewBox="0 0 200 130" className="w-full h-32">
          <rect
            x="58"
            y="16"
            width="84"
            height="86"
            fill="rgba(201,169,106,0.08)"
            stroke="#C9A96A"
            strokeWidth="1.2"
          />
          <line x1="70" y1="34" x2="130" y2="34" stroke="#C9A96A" strokeWidth="1" />
          <line x1="70" y1="46" x2="130" y2="46" stroke="#C9A96A" strokeWidth="0.8" />
          <line x1="70" y1="58" x2="122" y2="58" stroke="#C9A96A" strokeWidth="0.8" />
          <circle cx="116" cy="82" r="11" fill="#5A2A2E" stroke="#C9A96A" strokeWidth="1.2" />
          <text x="100" y="122" textAnchor="middle" fill="#C9A96A" fontSize="7.5" letterSpacing="2">
            FIG. IV • ARCHIVAL FOLIO VII (1969)
          </text>
        </svg>
      );
    case 'calibre':
    default:
      return (
        <svg viewBox="0 0 200 130" className="w-full h-32">
          <circle cx="100" cy="60" r="44" fill="none" stroke="#C9A96A" strokeWidth="1.5" />
          <circle
            cx="100"
            cy="60"
            r="34"
            fill="none"
            stroke="#C9A96A"
            strokeWidth="0.9"
            strokeDasharray="3 2"
          />
          <circle cx="100" cy="76" r="12" fill="rgba(201,169,106,0.2)" stroke="#C9A96A" strokeWidth="1.2" />
          <line x1="100" y1="60" x2="100" y2="32" stroke="#C9A96A" strokeWidth="1.6" />
          <line x1="100" y1="60" x2="122" y2="60" stroke="#C9A96A" strokeWidth="1.2" />
          <text x="100" y="122" textAnchor="middle" fill="#C9A96A" fontSize="7.5" letterSpacing="2">
            FIG. V • CALIBRE AV-01 HYBRIDE
          </text>
        </svg>
      );
  }
};

export const HeritageTimeline: React.FC = () => {
  const scrollTrackRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const scrollToIndex = (idx: number) => {
    const clamped = Math.max(0, Math.min(HERITAGE_TIMELINE.length - 1, idx));
    soundEngine.playCrownClick(1.0 + clamped * 0.04);
    setActiveIndex(clamped);

    const track = scrollTrackRef.current;
    if (!track) return;
    const card = track.children[clamped] as HTMLElement | undefined;
    if (card) {
      track.scrollTo({
        left: card.offsetLeft - 32,
        behavior: 'smooth',
      });
    }
  };

  const handleScroll = () => {
    const track = scrollTrackRef.current;
    if (!track) return;
    const maxScroll = track.scrollWidth - track.clientWidth;
    if (maxScroll <= 0) return;
    const progress = track.scrollLeft / maxScroll;
    const idx = Math.round(progress * (HERITAGE_TIMELINE.length - 1));
    if (idx !== activeIndex) {
      setActiveIndex(idx);
    }
  };

  return (
    <section
      id="heritage"
      className="py-24 lg:py-36 bg-[#1F3A32] text-[#F4EFE6] border-y border-[#C9A96A]/35 overflow-hidden"
    >
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">
        {/* Header & Era Year Stepper */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14">
          <div>
            <div className="flex items-center gap-3 text-[#C9A96A] mb-3">
              <span className="font-display text-sm tracking-[0.28em]">VII</span>
              <span className="w-8 h-[1px] bg-[#C9A96A]/55" />
              <span className="label-eyebrow text-[#C9A96A]">
                CHRONIQUE DE LA MAISON • 1794 — TODAY
              </span>
            </div>
            <h2 className="heading-section text-[#F4EFE6]">
              Two centuries on the Quai des Bergues.
            </h2>
          </div>

          {/* Interactive Year Nodes */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            {HERITAGE_TIMELINE.map((era, idx) => {
              const isCurrent = activeIndex === idx;
              return (
                <button
                  key={era.year}
                  type="button"
                  onClick={() => scrollToIndex(idx)}
                  className={`px-4 py-2 border font-display text-lg tracking-wider transition-all cursor-pointer ${
                    isCurrent
                      ? 'border-[#C9A96A] bg-[#C9A96A] text-[#14202B] font-semibold'
                      : 'border-[#C9A96A]/35 text-[#F4EFE6]/80 hover:border-[#C9A96A]'
                  }`}
                >
                  {era.year}
                </button>
              );
            })}
          </div>
        </div>

        {/* Animated SVG Connecting Thread */}
        <div className="relative mb-8">
          <div className="w-full h-[1px] bg-[#C9A96A]/25" />
          <div
            className="h-[2px] bg-[#C9A96A] -mt-[1.5px] transition-all duration-500"
            style={{
              width: `${((activeIndex + 1) / HERITAGE_TIMELINE.length) * 100}%`,
            }}
          />
        </div>

        {/* Horizontal Scrollable Archival Folio Cards */}
        <div
          ref={scrollTrackRef}
          onScroll={handleScroll}
          className="flex gap-8 overflow-x-auto pb-8 pt-2 snap-x snap-mandatory scrollbar-thin"
        >
          {HERITAGE_TIMELINE.map((era, idx) => {
            const isSelected = activeIndex === idx;
            return (
              <article
                key={era.year}
                onClick={() => setActiveIndex(idx)}
                className={`snap-start shrink-0 w-[86vw] sm:w-[460px] md:w-[520px] border p-8 md:p-10 transition-all duration-500 flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'border-[#C9A96A] bg-[#14202B]/90 shadow-2xl'
                    : 'border-[#C9A96A]/30 bg-[#14202B]/55 opacity-80 hover:opacity-100'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between border-b border-[#C9A96A]/25 pb-4 mb-6">
                    <span className="font-display text-5xl md:text-6xl text-[#C9A96A] font-light">
                      {era.year}
                    </span>
                    <span className="text-xs uppercase tracking-[0.2em] text-[#F4EFE6]/70">
                      {era.location}
                    </span>
                  </div>

                  {/* Era Hand-Drawn SVG Plate */}
                  <div className="mb-6 py-3 border border-[#C9A96A]/20 bg-[#0E1720]/70">
                    <EraIllustration type={era.illustrationType} />
                  </div>

                  <div className="label-eyebrow text-[#C9A96A] mb-2">{era.eraTitle}</div>
                  <h3 className="font-display text-2xl md:text-3xl text-[#F4EFE6] mb-3 leading-snug">
                    {era.headline}
                  </h3>
                  <p className="text-sm text-[#F4EFE6]/80 leading-relaxed font-light">
                    {era.narrative}
                  </p>
                </div>

                <div className="pt-5 mt-6 border-t border-[#C9A96A]/20 flex items-center justify-between text-[11px] tracking-[0.14em] text-[#C9A96A]">
                  <span>{era.artifactName}</span>
                  <span>ARCHIVE NO. 0{idx + 1}</span>
                </div>
              </article>
            );
          })}
        </div>

        {/* Bottom Prev / Next Controls */}
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs uppercase tracking-[0.2em] text-[#F4EFE6]/60">
            Scroll horizontally or select a century above
          </span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => scrollToIndex(activeIndex - 1)}
              disabled={activeIndex === 0}
              className="px-4 py-2 border border-[#C9A96A]/45 text-xs uppercase tracking-[0.2em] disabled:opacity-30 hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
            >
              ← Earlier Era
            </button>
            <button
              type="button"
              onClick={() => scrollToIndex(activeIndex + 1)}
              disabled={activeIndex === HERITAGE_TIMELINE.length - 1}
              className="px-4 py-2 border border-[#C9A96A]/45 text-xs uppercase tracking-[0.2em] disabled:opacity-30 hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
            >
              Next Era →
            </button>
          </div>
        </div>

        <OrnamentalDivider className="mt-12" />
      </div>
    </section>
  );
};
