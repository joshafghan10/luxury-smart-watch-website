import React from 'react';

export const AldervaneCrest: React.FC<{
  className?: string;
  size?: number;
  monochrome?: boolean;
}> = ({ className = '', size = 72 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Maison Aldervane Geneva 1794 Crest"
    >
      {/* Outer Compass & Escapement Halo */}
      <circle
        cx="60"
        cy="56"
        r="46"
        stroke="#C9A96A"
        strokeWidth="0.75"
        strokeDasharray="2 3"
        opacity="0.65"
      />
      <circle
        cx="60"
        cy="56"
        r="41"
        stroke="#C9A96A"
        strokeWidth="0.6"
        opacity="0.4"
      />

      {/* Left Laurel Branch */}
      <path
        d="M52 96C34 90 21 74 21 53C21 36 30 22 44 15"
        stroke="#C9A96A"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <path d="M23 64C18 61 17 55 21 52C25 56 25 61 23 64Z" fill="#C9A96A" opacity="0.75" />
      <path d="M22 50C18 46 19 40 24 38C26 43 25 47 22 50Z" fill="#C9A96A" opacity="0.75" />
      <path d="M26 36C24 31 27 25 32 25C32 30 30 34 26 36Z" fill="#C9A96A" opacity="0.75" />
      <path d="M35 24C34 19 38 15 43 16C42 20 39 23 35 24Z" fill="#C9A96A" opacity="0.75" />
      <path d="M29 77C23 75 21 69 25 65C29 69 30 73 29 77Z" fill="#C9A96A" opacity="0.75" />
      <path d="M39 88C33 88 30 82 33 78C37 81 39 84 39 88Z" fill="#C9A96A" opacity="0.75" />

      {/* Right Laurel Branch */}
      <path
        d="M68 96C86 90 99 74 99 53C99 36 90 22 76 15"
        stroke="#C9A96A"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <path d="M97 64C102 61 103 55 99 52C95 56 95 61 97 64Z" fill="#C9A96A" opacity="0.75" />
      <path d="M98 50C102 46 101 40 96 38C94 43 95 47 98 50Z" fill="#C9A96A" opacity="0.75" />
      <path d="M94 36C96 31 93 25 88 25C88 30 90 34 94 36Z" fill="#C9A96A" opacity="0.75" />
      <path d="M85 24C86 19 82 15 77 16C78 20 81 23 85 24Z" fill="#C9A96A" opacity="0.75" />
      <path d="M91 77C97 75 99 69 95 65C91 69 90 73 91 77Z" fill="#C9A96A" opacity="0.75" />
      <path d="M81 88C87 88 90 82 87 78C83 81 81 84 81 88Z" fill="#C9A96A" opacity="0.75" />

      {/* Sovereign Crown Finial at 12 o'clock */}
      <path
        d="M50 18L53 11L60 16L67 11L70 18H50Z"
        stroke="#C9A96A"
        strokeWidth="1.1"
        fill="rgba(201,169,106,0.15)"
      />
      <circle cx="53" cy="9.5" r="1.2" fill="#C9A96A" />
      <circle cx="60" cy="8.5" r="1.5" fill="#C9A96A" />
      <circle cx="67" cy="9.5" r="1.2" fill="#C9A96A" />

      {/* Geneva Heraldic Shield */}
      <path
        d="M38 24H82V54C82 71 72 82 60 88C48 82 38 71 38 54V24Z"
        stroke="#C9A96A"
        strokeWidth="1.4"
        fill="rgba(20, 32, 43, 0.35)"
      />
      <path
        d="M41.5 27.5H78.5V53.5C78.5 68 70 78 60 83.5C50 78 41.5 68 41.5 53.5V27.5Z"
        stroke="#C9A96A"
        strokeWidth="0.6"
        opacity="0.65"
      />

      {/* Subtle Escapement Cross Inside Shield */}
      <line x1="60" y1="28" x2="60" y2="83" stroke="#C9A96A" strokeWidth="0.5" opacity="0.4" />
      <line x1="42" y1="52" x2="78" y2="52" stroke="#C9A96A" strokeWidth="0.5" opacity="0.4" />
      <circle cx="60" cy="52" r="14" stroke="#C9A96A" strokeWidth="0.7" opacity="0.45" />

      {/* Interlocked M & A Cipher */}
      <path
        d="M47 63V41L54.5 55L60 44L65.5 55L73 41V63"
        stroke="#C9A96A"
        strokeWidth="1.65"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M52 63L60 37L68 63"
        stroke="#C9A96A"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line x1="54.5" y1="56" x2="65.5" y2="56" stroke="#C9A96A" strokeWidth="1.1" />

      {/* Lower Ribbon & 1794 */}
      <path
        d="M34 99C43 95 77 95 86 99L82 108C73 104 47 104 38 108L34 99Z"
        stroke="#C9A96A"
        strokeWidth="0.9"
        fill="rgba(20, 32, 43, 0.5)"
      />
      <text
        x="60"
        y="104.5"
        textAnchor="middle"
        fill="#C9A96A"
        fontSize="6.8"
        fontFamily="Cormorant Garamond, serif"
        letterSpacing="2.2"
        fontWeight="600"
      >
        1794
      </text>
    </svg>
  );
};

export const WaxSealBadge: React.FC<{
  label?: string;
  sublabel?: string;
  size?: number;
  className?: string;
}> = ({ label = 'MAISON ALDERVANE', sublabel = 'GENÈVE • 1794', size = 92, className = '' }) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-xl">
        <defs>
          <radialGradient id="waxGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#853D43" />
            <stop offset="55%" stopColor="#5A2A2E" />
            <stop offset="100%" stopColor="#351518" />
          </radialGradient>
        </defs>
        {/* Organic Wax Outer Rim */}
        <path
          d="M60 4C74 4 82 9 93 16C104 23 114 34 115 48C116 62 113 76 105 88C97 100 86 111 72 114C58 117 44 114 31 107C18 100 8 88 5 74C2 60 5 44 13 31C21 18 33 8 47 5C51 4 56 4 60 4Z"
          fill="url(#waxGrad)"
          stroke="#C9A96A"
          strokeWidth="0.8"
          strokeOpacity="0.5"
        />
        {/* Inner Recessed Stamp Ring */}
        <circle
          cx="60"
          cy="60"
          r="41"
          fill="none"
          stroke="#C9A96A"
          strokeWidth="1.2"
          strokeOpacity="0.75"
        />
        <circle
          cx="60"
          cy="60"
          r="37"
          fill="none"
          stroke="#C9A96A"
          strokeWidth="0.6"
          strokeDasharray="1.5 2.5"
          strokeOpacity="0.65"
        />
        {/* Center Monogram */}
        <path
          d="M46 68V49L54 61L60 51L66 61L74 49V68"
          stroke="#DFC690"
          strokeWidth="1.8"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <text
          x="60"
          y="36"
          textAnchor="middle"
          fill="#DFC690"
          fontSize="5.4"
          fontFamily="Jost, sans-serif"
          letterSpacing="1.6"
        >
          {label}
        </text>
        <text
          x="60"
          y="85"
          textAnchor="middle"
          fill="#C9A96A"
          fontSize="5.8"
          fontFamily="Cormorant Garamond, serif"
          letterSpacing="1.8"
        >
          {sublabel}
        </text>
      </svg>
    </div>
  );
};

export const OrnamentalDivider: React.FC<{
  roman?: string;
  className?: string;
}> = ({ roman, className = '' }) => {
  return (
    <div className={`flex items-center justify-center gap-4 w-full py-2 ${className}`} aria-hidden="true">
      <div className="h-[1px] flex-1 max-w-[180px] bg-gradient-to-r from-transparent to-[#C9A96A]/55" />
      <div className="flex items-center gap-2 text-[#C9A96A]">
        <span className="w-1.5 h-1.5 rotate-45 border border-[#C9A96A]" />
        {roman ? (
          <span className="font-display text-xs tracking-[0.28em] px-1 text-[#C9A96A]">
            {roman}
          </span>
        ) : (
          <span className="w-2 h-2 rotate-45 bg-[#C9A96A]/80" />
        )}
        <span className="w-1.5 h-1.5 rotate-45 border border-[#C9A96A]" />
      </div>
      <div className="h-[1px] flex-1 max-w-[180px] bg-gradient-to-l from-transparent to-[#C9A96A]/55" />
    </div>
  );
};
