import React, { useRef, useState } from 'react';
import {
  BASE_PRICE_CHF,
  BEZEL_OPTIONS,
  BOUTIQUE_SALONS,
  CASE_OPTIONS,
  COMPLICATIONS,
  DIAL_OPTIONS,
  PRESS_QUOTES,
  SPECIFICATIONS,
  STRAP_OPTIONS,
  WatchConfig,
} from '../data/aldervaneData';
import { AldervaneCrest, OrnamentalDivider, WaxSealBadge } from './CrestSvg';
import { soundEngine } from '../utils/soundEngine';

interface SpecsAndPressSectionProps {
  config: WatchConfig;
}

export const SpecsAndPressSection: React.FC<SpecsAndPressSectionProps> = ({ config }) => {
  const [openSpecs, setOpenSpecs] = useState<Record<string, boolean>>({
    case: true,
    calibre: true,
    complications: false,
    'dial-strap': false,
  });

  // Press carousel drag state
  const carouselRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  // Private Viewing Form State
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [salon, setSalon] = useState('Geneva — 14 Quai des Bergues');
  const [preferredDate, setPreferredDate] = useState('');
  const [correspondenceNote, setCorrespondenceNote] = useState('');
  const [errors, setErrors] = useState<{ name?: string; email?: string }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showDossierModal, setShowDossierModal] = useState(false);

  const toggleSpec = (id: string) => {
    soundEngine.playCrownClick(1.04);
    setOpenSpecs((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const totalPrice =
    BASE_PRICE_CHF +
    CASE_OPTIONS[config.caseId].priceDelta +
    BEZEL_OPTIONS[config.bezelId].priceDelta +
    DIAL_OPTIONS[config.dialId].priceDelta +
    STRAP_OPTIONS[config.strapId].priceDelta +
    (COMPLICATIONS.find((c) => c.id === config.complicationId)?.priceDelta || 0) +
    (config.engravingText.trim().length > 0 ? 350 : 0);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: { name?: string; email?: string } = {};
    if (fullName.trim().length < 2) {
      nextErrors.name = 'Please enter your full name or title.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = 'Please provide a valid correspondence address.';
    }
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length === 0) {
      soundEngine.playCourierCadence([0, 220]);
      setIsSubmitted(true);
    }
  };

  return (
    <>
      {/* =========================================================
          SECTION XI: TECHNICAL SPECIFICATIONS (COLLAPSIBLE TABLE)
         ========================================================= */}
      <section
        id="specifications"
        className="py-24 lg:py-32 px-6 md:px-12 max-w-[1240px] mx-auto border-t border-[#C9A96A]/25"
      >
        <div className="text-center max-w-2xl mx-auto mb-16">
          <OrnamentalDivider roman="IX" className="mb-4" />
          <p className="label-eyebrow text-[#C9A96A] mb-3">
            DOSSIER TECHNIQUE • OBSERVATORY CERTIFICATION
          </p>
          <h2 className="heading-section">Specifications of the Heritage S1.</h2>
        </div>

        <div className="divide-y divide-[#C9A96A]/30 border-y border-[#C9A96A]/40">
          {SPECIFICATIONS.map((cat) => {
            const isOpen = !!openSpecs[cat.id];
            return (
              <div key={cat.id} className="py-6">
                <button
                  type="button"
                  onClick={() => toggleSpec(cat.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between text-left py-2 cursor-pointer group"
                >
                  <div className="flex items-baseline gap-4">
                    <span className="font-display text-xl text-[#C9A96A] w-8">
                      {cat.roman}.
                    </span>
                    <h3 className="font-display text-2xl md:text-3xl group-hover:text-[#C9A96A] transition-colors">
                      {cat.title}
                    </h3>
                  </div>
                  <span className="font-display text-2xl text-[#C9A96A] px-3">
                    {isOpen ? '−' : '+'}
                  </span>
                </button>

                {isOpen && (
                  <div className="mt-6 pl-0 md:pl-12 grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 pb-2">
                    {cat.items.map((item) => (
                      <div
                        key={item.label}
                        className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#C9A96A]/20 pb-3 gap-1"
                      >
                        <span className="text-xs uppercase tracking-[0.18em] opacity-65">
                          {item.label}
                        </span>
                        <span className="font-display text-lg sm:text-right">
                          {item.value}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* =========================================================
          SECTION XII: PRESS & TESTIMONIAL CAROUSEL
         ========================================================= */}
      <section className="py-24 bg-[var(--card-surface)] border-y border-[#C9A96A]/25 overflow-hidden">
        <div className="max-w-[1440px] mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <span className="label-eyebrow text-[#C9A96A] block mb-2">
                X • LA CRITIQUE HORLOGÈRE
              </span>
              <h2 className="heading-section">Word from the salons.</h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(0.95);
                  carouselRef.current?.scrollBy({ left: -420, behavior: 'smooth' });
                }}
                aria-label="Previous press quote"
                className="px-4 py-2 border border-[#C9A96A]/45 text-xs uppercase tracking-[0.2em] hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
              >
                ← Prev
              </button>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.05);
                  carouselRef.current?.scrollBy({ left: 420, behavior: 'smooth' });
                }}
                aria-label="Next press quote"
                className="px-4 py-2 border border-[#C9A96A]/45 text-xs uppercase tracking-[0.2em] hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
              >
                Next →
              </button>
            </div>
          </div>

          <div
            ref={carouselRef}
            onMouseDown={(e) => {
              if (!carouselRef.current) return;
              setIsDragging(true);
              setStartX(e.pageX - carouselRef.current.offsetLeft);
              setScrollLeft(carouselRef.current.scrollLeft);
            }}
            onMouseLeave={() => setIsDragging(false)}
            onMouseUp={() => setIsDragging(false)}
            onMouseMove={(e) => {
              if (!isDragging || !carouselRef.current) return;
              e.preventDefault();
              const x = e.pageX - carouselRef.current.offsetLeft;
              const walk = (x - startX) * 1.4;
              carouselRef.current.scrollLeft = scrollLeft - walk;
            }}
            className="flex gap-8 overflow-x-auto pb-6 cursor-grab active:cursor-grabbing select-none snap-x"
          >
            {PRESS_QUOTES.map((item) => (
              <blockquote
                key={item.publication}
                className="snap-start shrink-0 w-[85vw] sm:w-[460px] border border-[#C9A96A]/35 bg-[var(--bg-primary)] p-8 md:p-10 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.22em] text-[#C9A96A] mb-6">
                    <span>{item.publication}</span>
                    <span>{item.city}</span>
                  </div>
                  <p className="font-display italic text-xl md:text-2xl leading-relaxed mb-8">
                    {item.quote}
                  </p>
                </div>
                <footer className="pt-4 border-t border-[#C9A96A]/20 text-xs">
                  <div className="font-medium tracking-wider uppercase">{item.author}</div>
                  <div className="opacity-60 mt-0.5">{item.issue}</div>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION XIII: PRIVATE VIEWING APPOINTMENT FORM
         ========================================================= */}
      <section
        id="private-viewing"
        className="py-24 lg:py-36 px-6 md:px-12 max-w-[1120px] mx-auto"
      >
        <div className="border border-[#C9A96A]/50 bg-[#14202B] text-[#F4EFE6] p-8 sm:p-12 md:p-16 relative overflow-hidden shadow-2xl">
          {/* Corner Filigrees */}
          <div className="pointer-events-none absolute top-4 left-4 w-6 h-6 border-t border-l border-[#C9A96A]/65" />
          <div className="pointer-events-none absolute top-4 right-4 w-6 h-6 border-t border-r border-[#C9A96A]/65" />
          <div className="pointer-events-none absolute bottom-4 left-4 w-6 h-6 border-b border-l border-[#C9A96A]/65" />
          <div className="pointer-events-none absolute bottom-4 right-4 w-6 h-6 border-b border-r border-[#C9A96A]/65" />

          <div className="text-center max-w-2xl mx-auto mb-12">
            <OrnamentalDivider roman="XI" className="mb-4" />
            <p className="label-eyebrow text-[#C9A96A] mb-2">
              AUDIENCE PRIVÉE • BY INVITATION
            </p>
            <h2 className="heading-section text-[#F4EFE6] mb-3">
              Request a Private Salon Viewing
            </h2>
            <p className="text-sm md:text-base text-[#F4EFE6]/75 font-light leading-relaxed">
              We do not maintain a digital checkout cart. Leave your card with our Master of Salons to inspect your configured Heritage S1 over vintage Armagnac or Darjeeling in Geneva, London, New York, or Tokyo.
            </p>
          </div>

          {/* Pre-filled Bespoke Configuration Summary Bar */}
          <div className="mb-10 p-5 border border-[#C9A96A]/35 bg-[#0E1720]/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] tracking-[0.22em] uppercase text-[#C9A96A] block">
                ATTACHED COMMISSION DOSSIER • NO. {String(config.editionNumber).padStart(4, '0')} / 1794
              </span>
              <p className="font-display text-lg text-[#F4EFE6] mt-0.5">
                {CASE_OPTIONS[config.caseId].name} • {BEZEL_OPTIONS[config.bezelId].name} •{' '}
                {DIAL_OPTIONS[config.dialId].name} • {STRAP_OPTIONS[config.strapId].name}
              </p>
              <p className="text-xs text-[#C9A96A]/85 mt-0.5">
                Caseback Engraving: “{config.engravingText.trim() || 'TIME, INHERITED'}” ({config.engravingStyle} burin)
              </p>
            </div>
            <div className="text-left md:text-right shrink-0">
              <span className="text-[10px] tracking-[0.2em] uppercase text-[#F4EFE6]/60 block">
                RESERVED ALLOCATION
              </span>
              <span className="font-display text-2xl text-[#C9A96A]">
                CHF {totalPrice.toLocaleString('en-CH')}
              </span>
            </div>
          </div>

          {!isSubmitted ? (
            <form onSubmit={handleFormSubmit} noValidate className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Floating Label Input: Full Name */}
                <div className="relative">
                  <input
                    id="viewing-name"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder=" "
                    className="peer w-full bg-transparent border-b border-[#C9A96A]/45 py-3 text-[#F4EFE6] focus:border-[#C9A96A] focus:outline-none font-display text-xl"
                  />
                  <label
                    htmlFor="viewing-name"
                    className="absolute left-0 -top-3.5 text-[10px] uppercase tracking-[0.22em] text-[#C9A96A] transition-all peer-placeholder-shown:top-3.5 peer-placeholder-shown:text-xs peer-placeholder-shown:text-[#F4EFE6]/55 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:text-[#C9A96A]"
                  >
                    Your Name & Style (e.g., M. Henri de Vane) *
                  </label>
                  {errors.name && (
                    <p className="text-xs text-[#E5989B] mt-1.5">{errors.name}</p>
                  )}
                </div>

                {/* Floating Label Input: Private Email */}
                <div className="relative">
                  <input
                    id="viewing-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder=" "
                    className="peer w-full bg-transparent border-b border-[#C9A96A]/45 py-3 text-[#F4EFE6] focus:border-[#C9A96A] focus:outline-none font-display text-xl"
                  />
                  <label
                    htmlFor="viewing-email"
                    className="absolute left-0 -top-3.5 text-[10px] uppercase tracking-[0.22em] text-[#C9A96A] transition-all peer-placeholder-shown:top-3.5 peer-placeholder-shown:text-xs peer-placeholder-shown:text-[#F4EFE6]/55 peer-focus:-top-3.5 peer-focus:text-[10px] peer-focus:text-[#C9A96A]"
                  >
                    Private Correspondence Address (Email) *
                  </label>
                  {errors.email && (
                    <p className="text-xs text-[#E5989B] mt-1.5">{errors.email}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Salon Selection */}
                <div>
                  <label
                    htmlFor="viewing-salon"
                    className="block text-[10px] uppercase tracking-[0.22em] text-[#C9A96A] mb-2"
                  >
                    Preferred Sanctuary Salon
                  </label>
                  <select
                    id="viewing-salon"
                    value={salon}
                    onChange={(e) => setSalon(e.target.value)}
                    className="w-full bg-[#0E1720] border-b border-[#C9A96A]/45 py-3 px-2 text-[#F4EFE6] focus:border-[#C9A96A] focus:outline-none font-display text-lg"
                  >
                    <option value="Geneva — 14 Quai des Bergues">
                      Geneva — 14 Quai des Bergues (Maison Mère)
                    </option>
                    <option value="London — 94 Mount Street, Mayfair">
                      London — 94 Mount Street, Mayfair
                    </option>
                    <option value="New York — 781 Madison Avenue">
                      New York — 781 Madison Avenue
                    </option>
                    <option value="Tokyo — Ginza Namiki-dori">
                      Tokyo — Ginza Namiki-dori Sanctuary
                    </option>
                  </select>
                </div>

                {/* Preferred Season or Date */}
                <div className="relative">
                  <input
                    id="viewing-date"
                    type="text"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    placeholder=" "
                    className="peer w-full bg-transparent border-b border-[#C9A96A]/45 py-3 mt-4 text-[#F4EFE6] focus:border-[#C9A96A] focus:outline-none font-display text-xl"
                  />
                  <label
                    htmlFor="viewing-date"
                    className="absolute left-0 top-0 text-[10px] uppercase tracking-[0.22em] text-[#C9A96A]"
                  >
                    Preferred Week or Month (Optional)
                  </label>
                </div>
              </div>

              {/* Personal Note */}
              <div className="relative">
                <textarea
                  id="viewing-note"
                  rows={2}
                  value={correspondenceNote}
                  onChange={(e) => setCorrespondenceNote(e.target.value)}
                  placeholder="Specify wrist circumference, strap requests, or private courier instructions…"
                  className="w-full bg-transparent border-b border-[#C9A96A]/45 py-3 text-[#F4EFE6] placeholder:text-[#F4EFE6]/35 focus:border-[#C9A96A] focus:outline-none font-display text-lg"
                />
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-6">
                <p className="text-xs text-[#F4EFE6]/60 max-w-md">
                  Your dispatch is encrypted and read solely by the Director of Private Clients in Geneva.
                </p>
                <button
                  type="submit"
                  className="wax-seal-btn px-8 py-4 border border-[#C9A96A] text-xs uppercase tracking-[0.24em] text-[#F4EFE6] flex items-center gap-3 cursor-pointer"
                >
                  <span>Seal & Dispatch Invitation Request</span>
                </button>
              </div>
            </form>
          ) : (
            /* Wax Seal Stamp Confirmation Animation */
            <div className="py-10 text-center space-y-6 animate-fadeIn">
              <div className="flex justify-center">
                <WaxSealBadge
                  label="SEALED IN GENEVA"
                  sublabel={`NO. ${String(config.editionNumber).padStart(4, '0')}`}
                  size={118}
                />
              </div>
              <div className="space-y-2 max-w-xl mx-auto">
                <span className="label-eyebrow text-[#C9A96A]">
                  DISPATCH RECORDED • QUAI DES BERGUES
                </span>
                <h3 className="font-display text-3xl text-[#F4EFE6]">
                  Thank you, {fullName}.
                </h3>
                <p className="text-sm text-[#F4EFE6]/80 leading-relaxed">
                  Our Master of Salons at <strong className="text-[#C9A96A]">{salon}</strong> has reserved Edition No. {String(config.editionNumber).padStart(4, '0')} / 1794 for your inspection. A wax-sealed parchment invitation and private dossier have been dispatched to {email}.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsSubmitted(false)}
                className="text-xs uppercase tracking-[0.2em] text-[#C9A96A] underline cursor-pointer"
              >
                Amend Dispatch Details
              </button>
            </div>
          )}
        </div>
      </section>

      {/* =========================================================
          SECTION XIV: HERITAGE FOOTER & BOUTIQUES
         ========================================================= */}
      <footer className="bg-[#0E1720] text-[#F4EFE6] border-t border-[#C9A96A]/35 pt-20 pb-14 px-6 md:px-12">
        <div className="max-w-[1440px] mx-auto">
          {/* Crest & Closing Motto */}
          <div className="flex flex-col items-center text-center mb-16">
            <AldervaneCrest size={92} className="mb-5" />
            <p className="label-eyebrow text-[#C9A96A] mb-2">
              MAISON ALDERVANE • GENÈVE • FONDÉE EN 1794
            </p>
            <h2 className="font-display italic text-3xl sm:text-4xl md:text-5xl text-[#F4EFE6] font-light mt-2">
              “Wear it. Then pass it on.”
            </h2>
          </div>

          {/* 4 Global Sanctuary Salons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 py-12 border-y border-[#C9A96A]/25">
            {BOUTIQUE_SALONS.map((b) => (
              <div key={b.city} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="label-eyebrow text-[#C9A96A]">{b.city}</span>
                  <span className="text-[10px] text-[#F4EFE6]/45 font-mono">
                    {b.coordinates}
                  </span>
                </div>
                <div className="font-display text-xl text-[#F4EFE6]">{b.title}</div>
                <div className="text-xs text-[#F4EFE6]/70">{b.address}</div>
                <div className="text-[11px] text-[#C9A96A]/80 pt-1">{b.hours}</div>
              </div>
            ))}
          </div>

          {/* Colophon & Technical Architecture Drawer Trigger */}
          <div className="pt-10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#F4EFE6]/55">
            <div>
              © 1794–2026 Maison Aldervane Horlogerie S.A., Genève. All rights reserved.
            </div>
            <div className="flex flex-wrap items-center gap-6">
              <a href="#atelier-viewer" className="hover:text-[#C9A96A] transition-colors">
                3D Observatory
              </a>
              <a href="#complications" className="hover:text-[#C9A96A] transition-colors">
                Complications
              </a>
              <a href="#configurator" className="hover:text-[#C9A96A] transition-colors">
                Commission Studio
              </a>
              <button
                type="button"
                onClick={() => setShowDossierModal(true)}
                className="text-[#C9A96A] underline hover:text-[#DFC690] cursor-pointer"
              >
                Atelier Engineering & Customization Notes
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* Architectural Rationale & Customization Guide Modal */}
      {showDossierModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
          onClick={() => setShowDossierModal(false)}
        >
          <div
            className="bg-[#14202B] border border-[#C9A96A] text-[#F4EFE6] max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-10 space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#C9A96A]/30 pb-4">
              <div>
                <span className="label-eyebrow text-[#C9A96A]">
                  ARCHITECTURAL COLOPHON
                </span>
                <h3 className="font-display text-2xl text-[#F4EFE6]">
                  Design Rationale & Customization Notes
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowDossierModal(false)}
                className="px-3 py-1 border border-[#C9A96A]/50 text-xs uppercase tracking-widest text-[#C9A96A] cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-[#F4EFE6]/80 leading-relaxed">
              <h4 className="text-xs uppercase tracking-[0.2em] text-[#C9A96A]">
                1. Design Rationale
              </h4>
              <p>
                Maison Aldervane eschews the neon glassmorphism of consumer electronics in favor of candlelit parchment (`#F4EFE6`), British racing green (`#1F3A32`), deep slate (`#14202B`), and hairline champagne gold (`#C9A96A`). Typography pairs light-weight <em>Cormorant Garamond</em> with tracked uppercase <em>Jost</em> labels, while motion relies on long `cubic-bezier(0.22, 1, 0.36, 1)` and `power3.out` curves.
              </p>

              <h4 className="text-xs uppercase tracking-[0.2em] text-[#C9A96A] pt-2">
                2. How to Customize (.GLB, Palette & Copy)
              </h4>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>
                  <strong>Swapping in a bespoke .GLB model:</strong> In <code>src/three/WatchBuilder.ts</code>, you can load an external <code>GLTFLoader</code> asset and attach its sub-meshes into the six <code>strata</code> groups (<code>crystalGroup</code>, <code>bezelHandsGroup</code>, <code>dialGroup</code>, <code>caseStrapGroup</code>, <code>movementGroup</code>, <code>casebackGroup</code>) to preserve Exploded View and real-time hand rotation.
                </li>
                <li>
                  <strong>Modifying the palette:</strong> Edit the CSS custom properties in <code>src/index.css</code> (<code>--ivory</code>, <code>--forest</code>, <code>--midnight</code>, <code>--champagne</code>, <code>--burgundy</code>) and material hex definitions in <code>src/data/aldervaneData.ts</code>.
                </li>
                <li>
                  <strong>Editing copy & pricing:</strong> All complications, timeline chapters, specifications, and Swiss Franc pricing deltas live in <code>src/data/aldervaneData.ts</code>.
                </li>
              </ul>

              <h4 className="text-xs uppercase tracking-[0.2em] text-[#C9A96A] pt-2">
                3. Optional Upgrades for Production
              </h4>
              <p>
                Connect WebXR/QuickLook AR for iOS wrist try-on, add custom KTX2 compressed studio HDRI maps from a Geneva watchmaking bench, and integrate encrypted WebSockets for live salon concierge availability.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
