import React, { useState } from 'react';
import { COMPLICATIONS, WatchConfig } from '../data/aldervaneData';
import { OrnamentalDivider } from './CrestSvg';
import { soundEngine } from '../utils/soundEngine';

interface ComplicationsSectionProps {
  activeComplication: WatchConfig['complicationId'];
  onSelectComplication: (id: WatchConfig['complicationId']) => void;
}

const WAYPOINTS = [
  { name: 'Zermatt High Refuge', azimuth: 312, label: '312° NW', dist: '1.4 NM' },
  { name: 'Portofino Cala Mooring', azimuth: 164, label: '164° SSE', dist: '0.8 NM' },
  { name: 'Quai des Bergues Salon', azimuth: 48, label: '048° NE', dist: '2.1 NM' },
];

export const ComplicationsSection: React.FC<ComplicationsSectionProps> = ({
  activeComplication,
  onSelectComplication,
}) => {
  const [expandedId, setExpandedId] = useState<WatchConfig['complicationId']>('pulse');
  const [courierTapActive, setCourierTapActive] = useState<string | null>(null);
  const [waypointIndex, setWaypointIndex] = useState(0);

  const handleExpand = (id: WatchConfig['complicationId']) => {
    soundEngine.playCrownClick(1.05);
    setExpandedId(id);
    onSelectComplication(id);
  };

  const triggerCourierDemo = (label: string, delays: number[]) => {
    setCourierTapActive(label);
    soundEngine.playCourierCadence(delays);
    window.setTimeout(() => {
      setCourierTapActive(null);
    }, 950);
  };

  return (
    <section
      id="complications"
      className="relative py-24 lg:py-36 px-6 md:px-12 max-w-[1440px] mx-auto"
    >
      <div className="text-center max-w-3xl mx-auto mb-16">
        <OrnamentalDivider roman="V" className="mb-4" />
        <p className="label-eyebrow text-[#C9A96A] mb-3">
          LES COMPLICATIONS SILENCIEUSES • CALIBRE AV-01
        </p>
        <h2 className="heading-section mb-5">
          Intelligence without the vulgarity of a screen.
        </h2>
        <p className="text-base md:text-lg opacity-75 font-light leading-relaxed">
          In Geneva, we do not speak of “features” or “notifications.” Each modern capability has been translated into the grammar of eighteenth-century mechanical horology—summoned only when asked, silent when uncalled for.
        </p>
      </div>

      {/* Horizontal Expanding Accordion Panels */}
      <div className="flex flex-col lg:flex-row gap-3 min-h-[540px] w-full">
        {COMPLICATIONS.map((comp) => {
          const isExpanded = expandedId === comp.id;
          const isSyncedToWatch = activeComplication === comp.id;

          return (
            <div
              key={comp.id}
              onClick={() => handleExpand(comp.id)}
              onMouseEnter={() => {
                if (window.innerWidth >= 1024 && expandedId !== comp.id) {
                  setExpandedId(comp.id);
                }
              }}
              role="button"
              tabIndex={0}
              aria-expanded={isExpanded}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleExpand(comp.id);
                }
              }}
              className={`relative border transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] overflow-hidden flex flex-col justify-between cursor-pointer ${
                isExpanded
                  ? 'lg:flex-[4.2] bg-[#1F3A32] text-[#F4EFE6] border-[#C9A96A] p-7 md:p-10 shadow-2xl'
                  : 'lg:flex-[1] bg-[var(--card-surface)] border-[#C9A96A]/35 hover:border-[#C9A96A]/75 p-6'
              }`}
            >
              {/* Top Roman Numeral & Title Bar */}
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className="font-display text-2xl md:text-3xl text-[#C9A96A]">
                    {comp.roman}
                  </span>
                  {isExpanded && (
                    <span className="text-[10px] tracking-[0.24em] uppercase px-2.5 py-1 border border-[#C9A96A]/45 text-[#C9A96A]">
                      {comp.modernEquivalent}
                    </span>
                  )}
                </div>

                {isSyncedToWatch && (
                  <span className="text-[10px] tracking-[0.2em] uppercase text-[#C9A96A] flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C9A96A]" />
                    {isExpanded ? 'Active on 3D Dial' : ''}
                  </span>
                )}
              </div>

              {/* Collapsed Vertical Spine Title (Desktop) */}
              {!isExpanded && (
                <div className="my-auto py-8 lg:py-0 flex lg:flex-col items-center justify-between h-full">
                  <div className="lg:[writing-mode:vertical-rl] lg:rotate-180 font-display text-2xl tracking-wide whitespace-nowrap">
                    {comp.name}
                  </div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C9A96A] mt-4">
                    Inspect →
                  </span>
                </div>
              )}

              {/* Expanded Content & Live Animated Horological Demo */}
              {isExpanded && (
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 mt-6 items-center">
                  <div className="xl:col-span-7 space-y-4">
                    <h3 className="font-display text-3xl md:text-4xl text-[#F4EFE6] font-normal">
                      {comp.name}
                    </h3>
                    <p className="font-display italic text-xl text-[#C9A96A]">
                      “{comp.tagline}”
                    </p>
                    <p className="text-sm md:text-base text-[#F4EFE6]/85 leading-relaxed font-light">
                      {comp.description}
                    </p>
                    <div className="pt-3 border-t border-[#C9A96A]/25 text-xs text-[#C9A96A]/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <span>Atelier Note: {comp.atelierNote}</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          soundEngine.playCrownClick(1.2);
                          onSelectComplication(comp.id);
                        }}
                        className="px-4 py-2 border border-[#C9A96A] bg-[#C9A96A]/15 hover:bg-[#C9A96A] hover:text-[#14202B] uppercase tracking-[0.18em] text-[10px] transition-colors shrink-0 cursor-pointer"
                      >
                        {isSyncedToWatch ? 'Displayed on 3D Watch' : 'Display on 3D Watch'}
                      </button>
                    </div>
                  </div>

                  {/* Interactive Horological Complication Simulator Box */}
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="xl:col-span-5 bg-[#14202B]/90 border border-[#C9A96A]/45 p-5 flex flex-col items-center justify-between min-h-[270px]"
                  >
                    <div className="w-full flex items-center justify-between text-[10px] tracking-[0.2em] uppercase text-[#C9A96A] border-b border-[#C9A96A]/20 pb-2">
                      <span>{comp.dialLabel}</span>
                      <span>CALIBRE AV-01</span>
                    </div>

                    {/* DEMO I: THE PULSE COMPLICATION */}
                    {comp.id === 'pulse' && (
                      <div className="my-auto w-full py-4 text-center space-y-3">
                        <svg viewBox="0 0 220 95" className="w-full h-24 mx-auto">
                          {/* Retrograde Arc */}
                          <path
                            d="M 25 80 A 85 85 0 0 1 195 80"
                            fill="none"
                            stroke="rgba(201,169,106,0.35)"
                            strokeWidth="2"
                            strokeDasharray="3 3"
                          />
                          <text x="22" y="92" fill="#C9A96A" fontSize="8">
                            40
                          </text>
                          <text x="104" y="14" fill="#C9A96A" fontSize="8">
                            80
                          </text>
                          <text x="184" y="92" fill="#C9A96A" fontSize="8">
                            140
                          </text>
                          {/* Animated Arterial Pulse Trace */}
                          <path
                            d="M 35 62 L 70 62 L 82 52 L 90 70 L 98 28 L 107 74 L 115 56 L 126 62 L 185 62"
                            fill="none"
                            stroke="#C9A96A"
                            strokeWidth="1.6"
                          />
                          <circle cx="98" cy="28" r="3.5" fill="#C9A96A" className="animate-ping" />
                          <circle cx="98" cy="28" r="3" fill="#F4EFE6" />
                        </svg>
                        <div className="font-display text-2xl text-[#F4EFE6]">
                          62 Pulsations / Min
                        </div>
                        <p className="text-[11px] text-[#F4EFE6]/65">
                          Optical Sapphire PPG • Sinus Rhythm Equilibrium
                        </p>
                      </div>
                    )}

                    {/* DEMO II: THE DISCREET COURIER (Interactive Haptic Tester) */}
                    {comp.id === 'courier' && (
                      <div className="my-auto w-full py-3 text-center space-y-3">
                        <div className="relative w-20 h-20 mx-auto rounded-full border border-[#C9A96A]/50 flex items-center justify-center">
                          <div
                            className={`w-12 h-12 rounded-full border-2 border-[#C9A96A] flex items-center justify-center transition-transform duration-150 ${
                              courierTapActive ? 'scale-125 bg-[#C9A96A]/30' : 'scale-100'
                            }`}
                          >
                            <span className="font-display text-xs text-[#C9A96A]">18K ROTOR</span>
                          </div>
                          {courierTapActive && (
                            <span className="absolute inset-0 rounded-full border border-[#C9A96A] animate-ping" />
                          )}
                        </div>
                        <div className="text-xs text-[#F4EFE6]/80">
                          {courierTapActive
                            ? `Transmitting: ${courierTapActive}`
                            : 'Click to test acoustic-haptic wrist cadence:'}
                        </div>
                        <div className="grid grid-cols-3 gap-1.5 pt-1">
                          <button
                            type="button"
                            onClick={() => triggerCourierDemo('Family (II Taps)', [0, 190])}
                            className="py-1.5 px-2 border border-[#C9A96A]/45 text-[10px] uppercase tracking-wider hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
                          >
                            II • Family
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              triggerCourierDemo('Estate (III Taps)', [0, 160, 320])
                            }
                            className="py-1.5 px-2 border border-[#C9A96A]/45 text-[10px] uppercase tracking-wider hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
                          >
                            III • Estate
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              triggerCourierDemo('Counsel (I-II)', [0, 340, 490])
                            }
                            className="py-1.5 px-2 border border-[#C9A96A]/45 text-[10px] uppercase tracking-wider hover:bg-[#C9A96A] hover:text-[#14202B] transition-colors cursor-pointer"
                          >
                            I–II • Counsel
                          </button>
                        </div>
                      </div>
                    )}

                    {/* DEMO III: THE NIGHT WATCH */}
                    {comp.id === 'night' && (
                      <div className="my-auto w-full py-3 text-center space-y-3">
                        <svg viewBox="0 0 180 90" className="w-40 h-20 mx-auto">
                          <circle
                            cx="90"
                            cy="45"
                            r="36"
                            stroke="#C9A96A"
                            strokeWidth="1.2"
                            fill="rgba(20,32,43,0.9)"
                          />
                          {/* Crescent Moon & Stars */}
                          <path
                            d="M84 26C76 30 74 41 79 49C84 57 94 59 102 55C93 56 85 49 85 39C85 33 88 28 84 26Z"
                            fill="#C9A96A"
                          />
                          <circle cx="106" cy="32" r="1.3" fill="#F4EFE6" />
                          <circle cx="112" cy="42" r="1" fill="#C9A96A" />
                          <circle cx="70" cy="34" r="1" fill="#C9A96A" />
                        </svg>
                        <div className="font-display text-2xl text-[#F4EFE6]">
                          Readiness XCIV / C
                        </div>
                        <p className="text-[11px] text-[#F4EFE6]/65">
                          7h 48m Repose • Valet Tray Barometer Calibrated
                        </p>
                      </div>
                    )}

                    {/* DEMO IV: THE NAVIGATOR'S REGISTER */}
                    {comp.id === 'navigator' && (
                      <div className="my-auto w-full py-3 text-center space-y-2.5">
                        <div className="relative w-20 h-20 mx-auto rounded-full border border-[#C9A96A]/60 flex items-center justify-center">
                          <span className="absolute top-1 text-[8px] text-[#C9A96A]">N</span>
                          <span className="absolute bottom-1 text-[8px] text-[#C9A96A]/60">S</span>
                          <span className="absolute right-1.5 text-[8px] text-[#C9A96A]/60">E</span>
                          <span className="absolute left-1.5 text-[8px] text-[#C9A96A]/60">W</span>
                          <div
                            className="w-1 h-14 transition-transform duration-700 ease-out flex flex-col items-center"
                            style={{
                              transform: `rotate(${WAYPOINTS[waypointIndex].azimuth}deg)`,
                            }}
                          >
                            <div className="w-0 h-0 border-l-[4px] border-r-[4px] border-b-[24px] border-l-transparent border-r-transparent border-b-[#C9A96A]" />
                            <div className="w-[2px] h-6 bg-[#F4EFE6]/40" />
                          </div>
                        </div>
                        <div className="font-display text-lg text-[#F4EFE6]">
                          {WAYPOINTS[waypointIndex].label} • {WAYPOINTS[waypointIndex].dist}
                        </div>
                        <div className="flex justify-center gap-1.5">
                          {WAYPOINTS.map((wp, idx) => (
                            <button
                              key={wp.name}
                              type="button"
                              onClick={() => {
                                soundEngine.playCrownClick(1.1);
                                setWaypointIndex(idx);
                              }}
                              className={`px-2 py-1 text-[9px] uppercase tracking-wider border cursor-pointer ${
                                waypointIndex === idx
                                  ? 'border-[#C9A96A] bg-[#C9A96A] text-[#14202B]'
                                  : 'border-[#C9A96A]/35 text-[#F4EFE6]/75'
                              }`}
                            >
                              {wp.name.split(' ')[0]}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* DEMO V: THE 14-DAY RESERVE */}
                    {comp.id === 'reserve' && (
                      <div className="my-auto w-full py-3 text-center space-y-3">
                        <div className="w-full space-y-1.5">
                          <div className="flex justify-between text-[10px] tracking-widest text-[#C9A96A]">
                            <span>TWIN BARREL + SOLAR</span>
                            <span>100% (XIV JOURS)</span>
                          </div>
                          <div className="w-full h-2.5 border border-[#C9A96A]/50 p-0.5 flex gap-0.5">
                            {Array.from({ length: 14 }).map((_, i) => (
                              <span
                                key={i}
                                className="flex-1 bg-[#C9A96A] transition-opacity duration-500"
                              />
                            ))}
                          </div>
                        </div>
                        <div className="font-display text-2xl text-[#F4EFE6]">
                          14 Days Telemetry • 60 Days Time
                        </div>
                        <p className="text-[11px] text-[#F4EFE6]/65">
                          Micro-perforated railway track harvests 420 lux ambient light
                        </p>
                      </div>
                    )}

                    <div className="w-full pt-2 border-t border-[#C9A96A]/20 flex justify-between text-[10px] tracking-[0.18em] text-[#F4EFE6]/60">
                      <span>READING: {comp.dialReading}</span>
                      <span>{comp.dialSubtext}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
