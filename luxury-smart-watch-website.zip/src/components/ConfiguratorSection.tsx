import React, { useEffect, useState } from 'react';
import {
  BASE_PRICE_CHF,
  CASE_OPTIONS,
  BEZEL_OPTIONS,
  DIAL_OPTIONS,
  STRAP_OPTIONS,
  COMPLICATIONS,
  WatchConfig,
} from '../data/aldervaneData';
import { TurntableWatchMini } from './TurntableWatchMini';
import { OrnamentalDivider } from './CrestSvg';
import { soundEngine } from '../utils/soundEngine';

interface ConfiguratorSectionProps {
  config: WatchConfig;
  onChangeConfig: (updater: (prev: WatchConfig) => WatchConfig) => void;
  onProceedToViewing: () => void;
}

export const ConfiguratorSection: React.FC<ConfiguratorSectionProps> = ({
  config,
  onChangeConfig,
  onProceedToViewing,
}) => {
  const [viewSide, setViewSide] = useState<'dial' | 'caseback'>('dial');
  const [displayedPrice, setDisplayedPrice] = useState(BASE_PRICE_CHF);

  const targetPrice =
    BASE_PRICE_CHF +
    CASE_OPTIONS[config.caseId].priceDelta +
    BEZEL_OPTIONS[config.bezelId].priceDelta +
    DIAL_OPTIONS[config.dialId].priceDelta +
    STRAP_OPTIONS[config.strapId].priceDelta +
    (COMPLICATIONS.find((c) => c.id === config.complicationId)?.priceDelta || 0) +
    (config.engravingText.trim().length > 0 ? 350 : 0);

  // Smooth rolling Swiss Franc counter animation
  useEffect(() => {
    let raf = 0;
    const step = () => {
      setDisplayedPrice((prev) => {
        const diff = targetPrice - prev;
        if (Math.abs(diff) < 15) return targetPrice;
        return Math.round(prev + diff * 0.18);
      });
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [targetPrice]);

  const activeComp =
    COMPLICATIONS.find((c) => c.id === config.complicationId) || COMPLICATIONS[0];

  return (
    <section
      id="configurator"
      className="py-24 lg:py-36 px-6 md:px-12 max-w-[1440px] mx-auto"
    >
      <div className="text-center max-w-3xl mx-auto mb-16">
        <OrnamentalDivider roman="VIII" className="mb-4" />
        <p className="label-eyebrow text-[#C9A96A] mb-3">
          LE CABINET DE COMMISSION • BESPOKE CONFIGURATOR & ENGRAVING
        </p>
        <h2 className="heading-section mb-4">
          Compose your family’s reference.
        </h2>
        <p className="text-base md:text-lg opacity-75 font-light leading-relaxed">
          Each Heritage S1 is assembled to order in Geneva and registered in our parchment ledger under your family name and chosen serial number.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left: 3D/2D Hybrid Preview & Caseback Engraving Visualizer */}
        <div className="lg:col-span-6 border border-[#C9A96A]/40 bg-[#14202B] text-[#F4EFE6] p-6 sm:p-8 sticky top-24">
          {/* Top Bar: Toggle Front Dial vs Caseback Engraving */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#C9A96A]/25 pb-4 mb-6">
            <div>
              <span className="text-[10px] tracking-[0.22em] uppercase text-[#C9A96A] block">
                REFERENCE AV-S1 • EDITION NO. {String(config.editionNumber).padStart(4, '0')} / 1794
              </span>
              <span className="font-display text-xl text-[#F4EFE6]">
                {CASE_OPTIONS[config.caseId].name} • {DIAL_OPTIONS[config.dialId].name}
              </span>
            </div>

            <div className="flex border border-[#C9A96A]/45">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.0);
                  setViewSide('dial');
                }}
                className={`px-3.5 py-1.5 text-[10px] uppercase tracking-[0.18em] transition-colors cursor-pointer ${
                  viewSide === 'dial'
                    ? 'bg-[#C9A96A] text-[#14202B] font-medium'
                    : 'text-[#F4EFE6]/75 hover:text-[#F4EFE6]'
                }`}
              >
                Dial Aperture
              </button>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playCrownClick(1.15);
                  setViewSide('caseback');
                }}
                className={`px-3.5 py-1.5 text-[10px] uppercase tracking-[0.18em] transition-colors cursor-pointer ${
                  viewSide === 'caseback'
                    ? 'bg-[#C9A96A] text-[#14202B] font-medium'
                    : 'text-[#F4EFE6]/75 hover:text-[#F4EFE6]'
                }`}
              >
                Caseback Engraving
              </button>
            </div>
          </div>

          {/* 3D Live Turntable + Lapidary Caseback Ring Overlay */}
          <div className="relative h-[400px] sm:h-[440px] w-full flex items-center justify-center overflow-hidden">
            <TurntableWatchMini
              config={config}
              targetRotation={
                viewSide === 'dial' ? [0.08, -0.18, 0] : [0.06, Math.PI + 0.15, 0]
              }
              targetCameraPos={viewSide === 'dial' ? [0, 0.05, 4.5] : [0, 0.05, 4.35]}
              scale={1.06}
            />

            {/* High-precision vector engraving ring overlay when inspecting Caseback */}
            {viewSide === 'caseback' && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <svg viewBox="0 0 320 320" className="w-[300px] h-[300px] sm:w-[340px] sm:h-[340px]">
                  <defs>
                    <path
                      id="topEngraveArc"
                      d="M 42,160 A 118,118 0 1,1 278,160"
                    />
                    <path
                      id="bottomEngraveArc"
                      d="M 278,160 A 118,118 0 1,1 42,160"
                    />
                  </defs>
                  <circle
                    cx="160"
                    cy="160"
                    r="132"
                    fill="none"
                    stroke="rgba(201,169,106,0.45)"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                  />
                  <text
                    fill="#DFC690"
                    fontSize={config.engravingStyle === 'script' ? '13' : '11.5'}
                    fontStyle={config.engravingStyle === 'script' ? 'italic' : 'normal'}
                    fontFamily="Cormorant Garamond, Georgia, serif"
                    letterSpacing="3.2"
                  >
                    <textPath href="#topEngraveArc" startOffset="50%" textAnchor="middle">
                      {config.engravingText.trim() || 'TIME, INHERITED • GENÈVE 1794'}
                    </textPath>
                  </text>
                  <text
                    fill="rgba(201,169,106,0.75)"
                    fontSize="9.5"
                    fontFamily="Jost, sans-serif"
                    letterSpacing="2.4"
                  >
                    <textPath href="#bottomEngraveArc" startOffset="50%" textAnchor="middle">
                      {`NO. ${String(config.editionNumber).padStart(4, '0')} / 1794 • CALIBRE AV-01`}
                    </textPath>
                  </text>
                </svg>
              </div>
            )}
          </div>

          {/* Live Valuation & Summary Footer */}
          <div className="pt-5 mt-4 border-t border-[#C9A96A]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] tracking-[0.22em] uppercase text-[#C9A96A] block">
                ATELIER VALUATION (TAXES INCL.)
              </span>
              <div className="font-display text-3xl sm:text-4xl text-[#F4EFE6]">
                CHF {displayedPrice.toLocaleString('en-CH')}
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                soundEngine.playCrownClick(1.2);
                onProceedToViewing();
              }}
              className="wax-seal-btn px-6 py-3.5 text-xs uppercase tracking-[0.22em] text-[#F4EFE6] border border-[#C9A96A]/60 cursor-pointer"
            >
              Reserve This Commission →
            </button>
          </div>
        </div>

        {/* Right: Bespoke Configuration Controls & Engraving Input */}
        <div className="lg:col-span-6 space-y-7">
          {/* Step 1: Case Metallurgy */}
          <div className="p-6 border border-[#C9A96A]/35 bg-[var(--card-surface)]">
            <div className="flex justify-between items-baseline mb-4">
              <span className="label-eyebrow text-[#C9A96A]">I • Case Metallurgy</span>
              <span className="text-xs opacity-70">{CASE_OPTIONS[config.caseId].subtitle}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(Object.keys(CASE_OPTIONS) as Array<WatchConfig['caseId']>).map((key) => {
                const opt = CASE_OPTIONS[key];
                const selected = config.caseId === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      soundEngine.playCrownClick(1.0);
                      onChangeConfig((prev) => ({ ...prev, caseId: key }));
                    }}
                    className={`p-4 border text-left transition-all cursor-pointer ${
                      selected
                        ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                        : 'border-[#C9A96A]/30 hover:border-[#C9A96A]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className="w-5 h-5 rounded-full border border-[#C9A96A]"
                        style={{ backgroundColor: opt.colorHex }}
                      />
                      <span className="text-[10px] tracking-widest text-[#C9A96A]">
                        {opt.priceDelta === 0
                          ? 'INCLUDED'
                          : `+CHF ${opt.priceDelta.toLocaleString()}`}
                      </span>
                    </div>
                    <div className="font-display text-lg leading-tight">{opt.name}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Bezel & Dial Habillage */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="p-6 border border-[#C9A96A]/35 bg-[var(--card-surface)]">
              <span className="label-eyebrow text-[#C9A96A] block mb-3">
                II • Bezel Ring
              </span>
              <div className="space-y-2.5">
                {(Object.keys(BEZEL_OPTIONS) as Array<WatchConfig['bezelId']>).map((key) => {
                  const opt = BEZEL_OPTIONS[key];
                  const selected = config.bezelId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.06);
                        onChangeConfig((prev) => ({ ...prev, bezelId: key }));
                      }}
                      className={`w-full p-3 border flex items-center justify-between text-left transition-all cursor-pointer ${
                        selected
                          ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                          : 'border-[#C9A96A]/30 hover:border-[#C9A96A]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className="w-4 h-4 rounded-full border border-[#C9A96A]"
                          style={{ backgroundColor: opt.colorHex }}
                        />
                        <span className="text-xs font-medium">{opt.name}</span>
                      </div>
                      <span className="text-[10px] text-[#C9A96A]">
                        {opt.priceDelta === 0 ? 'STD' : `+${opt.priceDelta}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border border-[#C9A96A]/35 bg-[var(--card-surface)]">
              <span className="label-eyebrow text-[#C9A96A] block mb-3">
                III • Grand Feu Dial
              </span>
              <div className="space-y-2.5">
                {(Object.keys(DIAL_OPTIONS) as Array<WatchConfig['dialId']>).map((key) => {
                  const opt = DIAL_OPTIONS[key];
                  const selected = config.dialId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.1);
                        setViewSide('dial');
                        onChangeConfig((prev) => ({ ...prev, dialId: key }));
                      }}
                      className={`w-full p-3 border flex items-center justify-between text-left transition-all cursor-pointer ${
                        selected
                          ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                          : 'border-[#C9A96A]/30 hover:border-[#C9A96A]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className="w-4 h-4 rounded-full border border-[#C9A96A]"
                          style={{ backgroundColor: opt.colorHex }}
                        />
                        <span className="text-xs font-medium">{opt.name}</span>
                      </div>
                      <span className="text-[10px] text-[#C9A96A]">
                        {opt.priceDelta === 0 ? 'STD' : `+${opt.priceDelta}`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Step 3: Primary Aperture Complication & Strap */}
          <div className="p-6 border border-[#C9A96A]/35 bg-[var(--card-surface)] space-y-5">
            <div>
              <div className="flex justify-between items-baseline mb-3">
                <span className="label-eyebrow text-[#C9A96A]">
                  IV • Primary 6 O’Clock Complication Calibration
                </span>
                <span className="text-xs text-[#C9A96A]">{activeComp.dialReading}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {COMPLICATIONS.map((comp) => {
                  const selected = config.complicationId === comp.id;
                  return (
                    <button
                      key={comp.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(1.14);
                        setViewSide('dial');
                        onChangeConfig((prev) => ({ ...prev, complicationId: comp.id }));
                      }}
                      className={`p-2.5 border text-center transition-all cursor-pointer ${
                        selected
                          ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                          : 'border-[#C9A96A]/30 hover:border-[#C9A96A]'
                      }`}
                    >
                      <div className="font-display text-base text-[#C9A96A]">{comp.roman}</div>
                      <div className="text-[10px] uppercase tracking-wider mt-0.5 capitalize">
                        {comp.id}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-[#C9A96A]/20">
              <span className="label-eyebrow text-[#C9A96A] block mb-3">
                V • Hand-Stitched Strap
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {(Object.keys(STRAP_OPTIONS) as Array<WatchConfig['strapId']>).map((key) => {
                  const opt = STRAP_OPTIONS[key];
                  const selected = config.strapId === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        soundEngine.playCrownClick(0.95);
                        onChangeConfig((prev) => ({ ...prev, strapId: key }));
                      }}
                      className={`p-3 border text-left transition-all cursor-pointer ${
                        selected
                          ? 'border-[#C9A96A] bg-[#1F3A32] text-[#F4EFE6]'
                          : 'border-[#C9A96A]/30 hover:border-[#C9A96A]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span
                          className="w-4 h-4 rounded-full border border-[#C9A96A]"
                          style={{ backgroundColor: opt.colorHex }}
                        />
                        <span className="text-[10px] text-[#C9A96A]">
                          {opt.priceDelta === 0 ? 'STD' : `+CHF ${opt.priceDelta}`}
                        </span>
                      </div>
                      <div className="text-xs font-medium">{opt.name}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Step 4: Lapidary Caseback Engraving & Serial Number */}
          <div className="p-6 border border-[#C9A96A]/50 bg-[var(--card-surface)] space-y-4">
            <div className="flex items-center justify-between">
              <span className="label-eyebrow text-[#C9A96A]">
                VI • Bespoke Caseback Engraving (+CHF 350)
              </span>
              <button
                type="button"
                onClick={() => setViewSide('caseback')}
                className="text-[10px] uppercase tracking-[0.2em] text-[#C9A96A] underline cursor-pointer"
              >
                Inspect Caseback →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-8">
                <label
                  htmlFor="engraving-input"
                  className="block text-[10px] uppercase tracking-[0.2em] opacity-70 mb-1.5"
                >
                  Family Motto, Initials or Date (Max 26 Characters)
                </label>
                <input
                  id="engraving-input"
                  type="text"
                  maxLength={26}
                  value={config.engravingText}
                  placeholder="H.A. — TIME, INHERITED"
                  onFocus={() => setViewSide('caseback')}
                  onChange={(e) => {
                    setViewSide('caseback');
                    onChangeConfig((prev) => ({
                      ...prev,
                      engravingText: e.target.value,
                    }));
                  }}
                  className="w-full px-3.5 py-2.5 bg-transparent border border-[#C9A96A]/55 focus:border-[#C9A96A] focus:outline-none font-display text-lg tracking-wider"
                />
              </div>

              <div className="sm:col-span-4">
                <label
                  htmlFor="edition-number-input"
                  className="block text-[10px] uppercase tracking-[0.2em] opacity-70 mb-1.5"
                >
                  Edition No. (1–1794)
                </label>
                <input
                  id="edition-number-input"
                  type="number"
                  min={1}
                  max={1794}
                  value={config.editionNumber}
                  onChange={(e) => {
                    const val = Math.max(1, Math.min(1794, Number(e.target.value) || 1));
                    onChangeConfig((prev) => ({ ...prev, editionNumber: val }));
                  }}
                  className="w-full px-3.5 py-2.5 bg-transparent border border-[#C9A96A]/55 focus:border-[#C9A96A] focus:outline-none font-display text-lg tracking-wider"
                />
              </div>
            </div>

            <div className="flex items-center gap-4 pt-1">
              <span className="text-[10px] uppercase tracking-[0.2em] opacity-70">
                Burin Hand-Style:
              </span>
              {(['roman', 'script'] as const).map((style) => (
                <button
                  key={style}
                  type="button"
                  onClick={() => {
                    soundEngine.playCrownClick(1.08);
                    setViewSide('caseback');
                    onChangeConfig((prev) => ({ ...prev, engravingStyle: style }));
                  }}
                  className={`px-3 py-1 text-xs border transition-colors cursor-pointer ${
                    config.engravingStyle === style
                      ? 'border-[#C9A96A] bg-[#C9A96A] text-[#14202B] font-medium'
                      : 'border-[#C9A96A]/35 opacity-75'
                  }`}
                >
                  {style === 'roman' ? 'Roman Lapidary Capitals' : 'Geneva Copperplate Script'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
