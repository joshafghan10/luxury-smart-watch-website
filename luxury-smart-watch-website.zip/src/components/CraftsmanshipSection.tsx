import React, { useState } from 'react';
import { OrnamentalDivider } from './CrestSvg';
import { soundEngine } from '../utils/soundEngine';

const GEAR_CALLOUTS = [
  {
    id: 'escapement',
    title: 'Free-Sprung Balance & Silicon Escapement',
    spec: '28,800 vph (4 Hz) • Breguet Overcoil',
    note: 'Oscillates on diamond-capped ruby shock absorbers; impervious to magnetic fields up to 15,000 Gauss.',
  },
  {
    id: 'barrel',
    title: 'Twin Mainspring & Kinetic Micro-Rotor',
    spec: 'Tungsten 22k Segment • Bidirectional Winding',
    note: 'Feeds both the mechanical going train and the solid-state micro-generator.',
  },
  {
    id: 'stator',
    title: 'Serviceable Biometric Stator Ring',
    spec: 'Modular Cassette • Dual-Wavelength PPG',
    note: 'Mounted on four blued-steel pillars; replaceable by our watchmakers in 2045 without altering the dial or bridges.',
  },
];

export const CraftsmanshipSection: React.FC = () => {
  const [wristMm, setWristMm] = useState(175);
  const [selectedGearId, setSelectedGearId] = useState('escapement');
  const [gearSpeedMultiplier, setGearSpeedMultiplier] = useState(1.0);

  // Calculate lug-to-wrist ratio for 39.5mm case (46.8mm lug-to-lug)
  // Average flat wrist top width ~ wristCircumference * 0.325
  const wristTopWidthMm = +(wristMm * 0.325).toFixed(1);
  const lugCoveragePct = Math.min(96, Math.round((46.8 / wristTopWidthMm) * 100));

  const fitVerdict =
    lugCoveragePct > 86
      ? 'Commanding Presence • Recommended with Curved Short Strap (105/65 mm)'
      : lugCoveragePct >= 74
      ? 'Golden Ratio Proportion • Classic Geneva Dress Fit (115/75 mm)'
      : 'Discreet Vintage Proportion • Effortless Under Double Cuff (125/80 mm)';

  return (
    <section
      id="atelier"
      className="py-24 lg:py-36 px-6 md:px-12 max-w-[1440px] mx-auto border-t border-[#C9A96A]/25"
    >
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-20">
        <OrnamentalDivider roman="VI" className="mb-4" />
        <p className="label-eyebrow text-[#C9A96A] mb-3">
          L’ATELIER DE HAUTE HORLOGERIE • METALLURGY & HABILLAGE
        </p>
        <h2 className="heading-section mb-5">
          Finished for the loupe, even where no eye can see.
        </h2>
        <p className="text-base md:text-lg opacity-75 font-light leading-relaxed">
          Every bridge inside Calibre AV-01 receives forty hours of hand-chamfering with gentian wood and diamond paste before the dial is ever fitted.
        </p>
      </div>

      {/* 3 Macro Finishing Cards with Procedural SVG Micro-Textures */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
        {/* Card 1: Brushed 904L & Hand Anglage */}
        <div className="border border-[#C9A96A]/35 bg-[var(--card-surface)] p-7 flex flex-col justify-between group">
          <div>
            <div className="h-48 w-full mb-6 border border-[#C9A96A]/25 bg-[#14202B] relative overflow-hidden flex items-center justify-center">
              <svg viewBox="0 0 300 180" className="w-full h-full">
                <defs>
                  <linearGradient id="steelBrush" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#2B3640" />
                    <stop offset="48%" stopColor="#9DA5AB" />
                    <stop offset="52%" stopColor="#FFF6E5" />
                    <stop offset="100%" stopColor="#222B33" />
                  </linearGradient>
                </defs>
                <rect width="300" height="180" fill="#121C26" />
                {Array.from({ length: 36 }).map((_, i) => (
                  <line
                    key={i}
                    x1="0"
                    y1={i * 5}
                    x2="300"
                    y2={i * 5 + 14}
                    stroke="rgba(255,255,255,0.08)"
                    strokeWidth="1"
                  />
                ))}
                {/* Mirror-beveled 45-degree lug chamfer */}
                <polygon
                  points="40,145 140,35 265,35 165,145"
                  fill="url(#steelBrush)"
                  stroke="#C9A96A"
                  strokeWidth="1.2"
                />
                <line x1="140" y1="35" x2="165" y2="145" stroke="#C9A96A" strokeWidth="1.5" />
              </svg>
              <span className="absolute bottom-2.5 right-3 text-[10px] tracking-[0.2em] uppercase text-[#C9A96A] bg-[#0E1720]/85 px-2.5 py-1">
                45° Mirror Anglage
              </span>
            </div>
            <span className="label-eyebrow text-[#C9A96A]">I • Case & Bridges</span>
            <h3 className="font-display text-2xl mt-1 mb-2">
              Gentian-Wood Polished Chamfers
            </h3>
            <p className="text-sm opacity-75 leading-relaxed font-light">
              Satin-brushed flanks contrast with 45-degree mirror-polished bevels that catch candle and morning light along a single uninterrupted razor edge.
            </p>
          </div>
          <div className="pt-4 mt-6 border-t border-[#C9A96A]/20 flex justify-between text-xs tracking-wider opacity-70">
            <span>ROUGHNESS: Ra 0.015 μm</span>
            <span>ALLOY: 904L / 18K</span>
          </div>
        </div>

        {/* Card 2: Grand Feu & E-Ink Micro-Capsules */}
        <div className="border border-[#C9A96A]/35 bg-[var(--card-surface)] p-7 flex flex-col justify-between group">
          <div>
            <div className="h-48 w-full mb-6 border border-[#C9A96A]/25 bg-[#1F3A32] relative overflow-hidden flex items-center justify-center">
              <svg viewBox="0 0 300 180" className="w-full h-full">
                <rect width="300" height="180" fill="#182E27" />
                {/* Guilloche Rosette Waves */}
                {Array.from({ length: 14 }).map((_, i) => (
                  <circle
                    key={i}
                    cx="150"
                    cy="90"
                    r={12 + i * 10}
                    fill="none"
                    stroke="rgba(201,169,106,0.28)"
                    strokeWidth="0.9"
                    strokeDasharray={i % 2 === 0 ? '4 2' : 'none'}
                  />
                ))}
                <circle
                  cx="150"
                  cy="90"
                  r="42"
                  fill="#F4EFE6"
                  stroke="#C9A96A"
                  strokeWidth="2"
                />
                <text
                  x="150"
                  y="86"
                  textAnchor="middle"
                  fill="#1A1A18"
                  fontSize="11"
                  fontFamily="Cormorant Garamond, serif"
                  fontWeight="600"
                >
                  62 BPM
                </text>
                <text
                  x="150"
                  y="100"
                  textAnchor="middle"
                  fill="#5A2A2E"
                  fontSize="6.5"
                  fontFamily="Jost, sans-serif"
                  letterSpacing="1.5"
                >
                  GRAND FEU + E-INK
                </text>
              </svg>
              <span className="absolute bottom-2.5 right-3 text-[10px] tracking-[0.2em] uppercase text-[#C9A96A] bg-[#0E1720]/85 px-2.5 py-1">
                820°C Kiln Fired
              </span>
            </div>
            <span className="label-eyebrow text-[#C9A96A]">II • The Dial Face</span>
            <h3 className="font-display text-2xl mt-1 mb-2">
              Vitreous Enamel & Paper-Ink Aperture
            </h3>
            <p className="text-sm opacity-75 leading-relaxed font-light">
              Silica and metal oxides are dusted onto a rose-engine turned silver plate and fired seven times. Within the six o’clock well sits our zero-glow electrophoretic capsule layer.
            </p>
          </div>
          <div className="pt-4 mt-6 border-t border-[#C9A96A]/20 flex justify-between text-xs tracking-wider opacity-70">
            <span>BACKLIGHT: 0.0 NITS</span>
            <span>CONTRAST: PAPER-GRADE</span>
          </div>
        </div>

        {/* Card 3: Sintered Ceramic & Sapphire */}
        <div className="border border-[#C9A96A]/35 bg-[var(--card-surface)] p-7 flex flex-col justify-between group">
          <div>
            <div className="h-48 w-full mb-6 border border-[#C9A96A]/25 bg-[#14202B] relative overflow-hidden flex items-center justify-center">
              <svg viewBox="0 0 300 180" className="w-full h-full">
                <rect width="300" height="180" fill="#101922" />
                {/* Refractive Sapphire Dome Arc */}
                <path
                  d="M 30 130 Q 150 35 270 130"
                  fill="rgba(201,169,106,0.08)"
                  stroke="#C9A96A"
                  strokeWidth="2"
                />
                <path
                  d="M 45 135 Q 150 52 255 135"
                  fill="none"
                  stroke="rgba(244,239,230,0.45)"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                />
                <line x1="85" y1="30" x2="135" y2="95" stroke="#C9A96A" strokeWidth="1" />
                <line x1="135" y1="95" x2="170" y2="145" stroke="#DFC690" strokeWidth="1.2" />
                <text
                  x="150"
                  y="155"
                  textAnchor="middle"
                  fill="#C9A96A"
                  fontSize="8"
                  fontFamily="Jost, sans-serif"
                  letterSpacing="2"
                >
                  REFRACTIVE INDEX n = 1.770
                </text>
              </svg>
              <span className="absolute bottom-2.5 right-3 text-[10px] tracking-[0.2em] uppercase text-[#C9A96A] bg-[#0E1720]/85 px-2.5 py-1">
                1,850 Vickers ZrO2
              </span>
            </div>
            <span className="label-eyebrow text-[#C9A96A]">III • Crystal & Bezel</span>
            <h3 className="font-display text-2xl mt-1 mb-2">
              Kyropoulos Sapphire & Zirconia Ceramic
            </h3>
            <p className="text-sm opacity-75 leading-relaxed font-light">
              Grown from a single crystalline boules over fourteen days, the box-domed crystal magnifies the chapter ring like a vintage acrylic dome while remaining scratch-proof short of diamond.
            </p>
          </div>
          <div className="pt-4 mt-6 border-t border-[#C9A96A]/20 flex justify-between text-xs tracking-wider opacity-70">
            <span>MOHS HARDNESS: 9.0</span>
            <span>AR COATING: 7-LAYER</span>
          </div>
        </div>
      </div>

      {/* Interactive Calibre AV-01 Cutaway & Wrist Presence Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        {/* Left: Interactive Movement Gear Train Simulator */}
        <div className="lg:col-span-7 border border-[#C9A96A]/40 bg-[#14202B] text-[#F4EFE6] p-8 md:p-10 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#C9A96A]/25 pb-5">
            <div>
              <span className="label-eyebrow text-[#C9A96A]">
                INTERACTIVE KINEMATIC DIAGRAM
              </span>
              <h3 className="font-display text-3xl text-[#F4EFE6] mt-1">
                Calibre AV-01 Going Train & Stator
              </h3>
            </div>
            <div className="text-right">
              <div className="font-display text-2xl text-[#C9A96A]">
                {Math.round(28800 * gearSpeedMultiplier).toLocaleString()} vph
              </div>
              <div className="text-[10px] tracking-[0.2em] uppercase text-[#F4EFE6]/60">
                Amplitude {Math.round(275 + gearSpeedMultiplier * 18)}° • Beat 0.0 ms
              </div>
            </div>
          </div>

          {/* Animated SVG Gear Train */}
          <div className="relative my-8 flex items-center justify-center min-h-[280px]">
            <style>{`
              @keyframes spinClockwise {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
              }
              @keyframes spinCounter {
                from { transform: rotate(360deg); }
                to { transform: rotate(0deg); }
              }
              @keyframes oscillateBalance {
                0%, 100% { transform: rotate(-38deg); }
                50% { transform: rotate(38deg); }
              }
            `}</style>
            <svg viewBox="0 0 460 250" className="w-full max-w-[480px] h-auto">
              {/* Outer Biometric Sapphire Stator Ring */}
              <circle
                cx="230"
                cy="125"
                r="112"
                fill="none"
                stroke={selectedGearId === 'stator' ? '#C9A96A' : 'rgba(201,169,106,0.35)'}
                strokeWidth={selectedGearId === 'stator' ? '3' : '1.5'}
                strokeDasharray="6 4"
              />
              <circle
                cx="230"
                cy="125"
                r="98"
                fill="rgba(31, 58, 50, 0.25)"
                stroke="rgba(201,169,106,0.25)"
                strokeWidth="1"
              />

              {/* Twin Mainspring Barrel (Left) */}
              <g
                onClick={() => {
                  soundEngine.playCrownClick(0.95);
                  setSelectedGearId('barrel');
                }}
                className="cursor-pointer"
                style={{
                  transformOrigin: '165px 115px',
                  animation: `spinClockwise ${16 / gearSpeedMultiplier}s linear infinite`,
                }}
              >
                <circle
                  cx="165"
                  cy="115"
                  r="46"
                  fill="rgba(201,169,106,0.14)"
                  stroke="#C9A96A"
                  strokeWidth="2"
                  strokeDasharray="5 3"
                />
                <circle cx="165" cy="115" r="32" fill="none" stroke="#C9A96A" strokeWidth="1" />
                <line x1="119" y1="115" x2="211" y2="115" stroke="#C9A96A" strokeWidth="1.2" />
                <line x1="165" y1="69" x2="165" y2="161" stroke="#C9A96A" strokeWidth="1.2" />
                <circle cx="165" cy="115" r="6" fill="#9E1B32" stroke="#C9A96A" strokeWidth="1.5" />
              </g>

              {/* Center & Fourth Wheel (Top Right) */}
              <g
                style={{
                  transformOrigin: '245px 88px',
                  animation: `spinCounter ${7 / gearSpeedMultiplier}s linear infinite`,
                }}
              >
                <circle
                  cx="245"
                  cy="88"
                  r="34"
                  fill="rgba(201,169,106,0.1)"
                  stroke="#DFC690"
                  strokeWidth="1.8"
                  strokeDasharray="4 2.5"
                />
                <line x1="211" y1="88" x2="279" y2="88" stroke="#DFC690" strokeWidth="1" />
                <line x1="245" y1="54" x2="245" y2="122" stroke="#DFC690" strokeWidth="1" />
                <circle cx="245" cy="88" r="5" fill="#9E1B32" />
              </g>

              {/* Free-Sprung Balance Wheel at 6 o'clock (Bottom Right) */}
              <g
                onClick={() => {
                  soundEngine.playCrownClick(1.15);
                  setSelectedGearId('escapement');
                }}
                className="cursor-pointer"
                style={{
                  transformOrigin: '285px 158px',
                  animation: `oscillateBalance ${0.45 / gearSpeedMultiplier}s ease-in-out infinite`,
                }}
              >
                <circle
                  cx="285"
                  cy="158"
                  r="36"
                  fill="rgba(201,169,106,0.2)"
                  stroke="#C9A96A"
                  strokeWidth="2.6"
                />
                <line x1="249" y1="158" x2="321" y2="158" stroke="#C9A96A" strokeWidth="2" />
                <line x1="285" y1="122" x2="285" y2="194" stroke="#C9A96A" strokeWidth="2" />
                {/* Micro-timing gold weights */}
                <circle cx="285" cy="122" r="3" fill="#F4EFE6" />
                <circle cx="285" cy="194" r="3" fill="#F4EFE6" />
                <circle cx="249" cy="158" r="3" fill="#F4EFE6" />
                <circle cx="321" cy="158" r="3" fill="#F4EFE6" />
                <circle cx="285" cy="158" r="6" fill="#9E1B32" stroke="#F4EFE6" strokeWidth="1" />
              </g>

              {/* Leader Labels inside Diagram */}
              <text x="20" y="34" fill="#C9A96A" fontSize="9" letterSpacing="2">
                CALIBRE AV-01 • 39 RUBIS
              </text>
              <text x="20" y="232" fill="rgba(244,239,230,0.6)" fontSize="8.5" letterSpacing="1.5">
                CLICK GEARS OR ADJUST TORQUE BELOW
              </text>
            </svg>
          </div>

          {/* Interactive Organ Selector & Mainspring Torque Scrubber */}
          <div className="space-y-5 pt-4 border-t border-[#C9A96A]/25">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {GEAR_CALLOUTS.map((g) => {
                const active = selectedGearId === g.id;
                return (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playCrownClick(1.05);
                      setSelectedGearId(g.id);
                    }}
                    className={`p-3 border text-left transition-colors cursor-pointer ${
                      active
                        ? 'border-[#C9A96A] bg-[#C9A96A]/20'
                        : 'border-[#C9A96A]/25 hover:border-[#C9A96A]/60'
                    }`}
                  >
                    <div className="text-xs font-medium text-[#F4EFE6]">{g.title}</div>
                    <div className="text-[10px] text-[#C9A96A] mt-0.5">{g.spec}</div>
                  </button>
                );
              })}
            </div>

            <div className="p-4 bg-[#0E1720]/80 border border-[#C9A96A]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <p className="text-xs text-[#F4EFE6]/80 leading-relaxed max-w-md">
                {GEAR_CALLOUTS.find((g) => g.id === selectedGearId)?.note}
              </p>
              <div className="min-w-[180px]">
                <div className="flex justify-between text-[10px] uppercase tracking-widest text-[#C9A96A] mb-1">
                  <span>Barrel Torque</span>
                  <span>{Math.round(gearSpeedMultiplier * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={2.0}
                  step={0.1}
                  value={gearSpeedMultiplier}
                  aria-label="Mainspring barrel torque simulation speed"
                  onChange={(e) => setGearSpeedMultiplier(Number(e.target.value))}
                  className="w-full aldervane-slider"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right: "Wrist Presence" Try-On Simulator */}
        <div className="lg:col-span-5 border border-[#C9A96A]/40 bg-[var(--card-surface)] p-8 md:p-10 flex flex-col justify-between">
          <div>
            <span className="label-eyebrow text-[#C9A96A]">
              BESPOKE PROPORTION STUDIO
            </span>
            <h3 className="font-display text-3xl mt-1 mb-2">
              “Wrist Presence” Try-On
            </h3>
            <p className="text-sm opacity-75 leading-relaxed font-light">
              A gentleman’s timepiece should slip effortlessly beneath a buttoned Sea Island cotton cuff. Adjust your wrist circumference to evaluate the 39.5 mm case and 46.8 mm lug-to-lug silhouette.
            </p>
          </div>

          {/* Stylized Anatomical Wrist & Cuff Silhouette with Proportional Watch */}
          <div className="my-8 py-6 px-4 border border-[#C9A96A]/30 bg-[#14202B] text-[#F4EFE6] relative flex flex-col items-center justify-center min-h-[260px]">
            <div className="text-[10px] tracking-[0.22em] uppercase text-[#C9A96A] mb-3">
              WRIST TOP SPAN: {wristTopWidthMm} MM • LUG SPAN: 46.8 MM ({lugCoveragePct}%)
            </div>

            <div className="relative w-full h-40 flex items-center justify-center">
              {/* Wrist Silhouette Bar (scales with wristMm) */}
              <div
                className="h-24 rounded-sm border-y-2 border-[#C9A96A]/45 bg-gradient-to-r from-[#1E2E3D] via-[#2B3F52] to-[#1E2E3D] flex items-center justify-center relative transition-all duration-300"
                style={{
                  width: `${Math.min(92, Math.max(54, (wristMm / 215) * 88))}%`,
                  height: `${Math.round(74 + ((wristMm - 145) / 70) * 38)}px`,
                }}
              >
                {/* French Shirt Cuff Left Edge */}
                <div className="absolute left-0 top-[-8px] bottom-[-8px] w-12 bg-[#F4EFE6] border-r-2 border-[#C9A96A] flex items-center justify-center shadow-lg">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#C9A96A] border border-[#14202B]" />
                </div>

                {/* Strap Top & Bottom */}
                <div className="w-11 h-[138%] bg-[#5B3420] border-x border-[#C9A96A]/60 absolute" />

                {/* Proportional 39.5mm Watch Head */}
                <div className="relative z-10 w-24 h-24 rounded-full border-[3px] border-[#C9A96A] bg-[#1F3A32] shadow-2xl flex flex-col items-center justify-center">
                  <span className="text-[7px] tracking-[0.18em] text-[#C9A96A]">ALDERVANE</span>
                  <span className="font-display text-sm text-[#F4EFE6]">39.5 mm</span>
                  <span className="text-[7px] text-[#F4EFE6]/70">10.4 mm Thin</span>
                </div>
              </div>
            </div>

            <div className="text-xs text-center text-[#F4EFE6]/85 font-display italic mt-2">
              {fitVerdict}
            </div>
          </div>

          {/* Wrist Circumference Slider */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-[0.2em]">Wrist Circumference</span>
              <span className="font-display text-2xl text-[#C9A96A]">
                {wristMm} mm ({(wristMm / 25.4).toFixed(1)}″)
              </span>
            </div>
            <input
              type="range"
              min={145}
              max={215}
              value={wristMm}
              aria-label="Wrist circumference in millimeters"
              onChange={(e) => {
                setWristMm(Number(e.target.value));
              }}
              className="w-full aldervane-slider"
            />
            <div className="flex justify-between text-[10px] uppercase tracking-[0.18em] opacity-60">
              <span>145 mm (Slender)</span>
              <span>175 mm (Classic)</span>
              <span>215 mm (Broad)</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
